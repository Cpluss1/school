<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;

class Contact_Info extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-contact-info';
    }

    public function get_title() {
        return esc_html__( 'Bisy Contact Info', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Bisy Contact settings', 'bisy-essential'),
            ]
        );
         
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bisy-essential' ),
					'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
				],
			]
        );
        
        $this->add_control(
			'heading_title', [
				'label' => esc_html__( 'Heading Title', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( ' Title' , 'bisy-essential' ),
				'label_block' => true,
			]
        );
        
        $this->add_control(
			'heading_content', [
				'label' => esc_html__( 'Heading Content', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( ' Title' , 'bisy-essential' ),
				'label_block' => true,
			]
        );
        
      

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'bisy-essential' ),
				'label_block' => true,
			]
		);
     
		$repeater->add_control(
			'list_content', [
				'label'      => esc_html__( 'Content', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXTAREA,
				'default'    => esc_html__( '744 New York Ave, Brooklyn, Kings,
                New York 10224' , 'bisy-essential' ),
                'description'    => esc_html__( 'Use \n for new line break' , 'bisy-essential' ),
				'show_label' => true,
			]
        );
      
		$repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
		);
  
       
        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Counter List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 

 
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Main Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               
            
                'selectors' => [
                     '{{WRAPPER}} .contact--info-area' => 'text-align: {{VALUE}};',
                     

				],
			]
        );//Responsive control end

         
        $this->add_responsive_control(
			'contact_align', [
				'label'   => esc_html__( 'Contact Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               
            
                'selectors' => [
                     '{{WRAPPER}} .single-info' => 'text-align: {{VALUE}};',
                     

				],
			]
        );//Responsive control end
        $this->end_controls_section();

        // Heading   
		$this->start_controls_section(
			'section_heading_title_style', [
				'label' => esc_html__( 'Heading Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'heading_title_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .contact--info-area h3' => 'color: {{VALUE}};',
                        ],
                    ]
                );
             
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'heading_title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .contact--info-area h3 ',
                    ]
                );

                $this->add_responsive_control(
                    'heading_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .contact--info-area h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

             // Heading  content  
		$this->start_controls_section(
			'section_heading_content_style', [
				'label' => esc_html__( 'Heading Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'heading_content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .contact--info-area .content' => 'color: {{VALUE}};',
                        ],
                    ]
                );
             
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'heading_content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .contact--info-area .content',
                    ]
                );

                $this->add_responsive_control(
                    'heading_content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .contact--info-area .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'heading_content_border',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .contact--info-area .content',
                    ]
                );

        $this->end_controls_section();
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .single-info h5' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                 
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .single-info h5',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .single-info h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .single-info p' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
             
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_contact_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .single-info p',
                    ]
                );

                
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .single-info p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .single-info p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
        // ICON
        $this->start_controls_section('_item_icon_box_style',
            [
            'label' => esc_html__( 'Icon', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                $this->add_control(
                    'icon_box_color', [

                        'label'     => esc_html__( 'Icon Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .single-info p i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .single-info p svg path' => 'fill: {{VALUE}};',
                        
                        ],
                    ]
                );

                $this->add_control(
                    'icon_box_hv_color', [

                        'label'     => esc_html__( 'Icon Hover Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .single-info:hover p i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .single-info p:hover svg path' => 'fill: {{VALUE}};',
                        
                        
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'icon_box_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .single-info p i',
                    ]
                );
        
        
                $this->add_responsive_control(
                    'icon_box_n_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .single-info p i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
       
        $this->end_controls_section();
        $this->start_controls_section('appscred_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .single-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .single-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );   

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => '_item_section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .single-info',
                    ]
            );
            $this->add_control(
                'itembakcground__heading1',
                [
                    'label' => esc_html__( 'Background hover', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => '_item__hvv_section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .single-info:hover',
                    ]
            );
            //
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'item__content_box_border',
                    'label' => esc_html__( 'Border', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .single-info',
                ]
            );
           
        $this->end_controls_section();

       
        $this->start_controls_section('appscred_main_section',
                [
                'label' => esc_html__( 'Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
                   
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
		$list     = $settings['list'];
    ?>
        <?php if($settings['style'] == 'style1'): ?>
                
                 <div class="contact--info-area main-section">

                    <?php if($settings['heading_title'] !=''): ?>
                            <h3> <?php echo esc_html($settings['heading_title']); ?> </h3>
                    <?php endif; ?>
                    <?php if($settings['heading_title'] !=''): ?>
                        <p class="content">
                            <?php echo esc_html($settings['heading_content']); ?>
                        </p>
                    <?php endif; ?>
                    <?php foreach($list as $item): ?> 
                        <div class="single-info">
                             <?php if( $item['list_title'] !='' ): ?>
                                <h5> <?php echo esc_html( $item['list_title'] ); ?> </h5>
                             <?php endif; ?>
                            <p>
                                <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php echo str_replace(['\n'],['<br/>'], $item['list_content']); ?>
                            </p>
                        </div>
                    <?php endforeach; ?>  
                           
                </div>  

        <?php endif; ?>
  
    <?php  

    }
    
    protected function _content_template() { }
}