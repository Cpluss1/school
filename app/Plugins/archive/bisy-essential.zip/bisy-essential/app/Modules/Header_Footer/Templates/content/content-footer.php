<footer id="quomodo-footer-builder" class="quomodo-site-header-builder">
	<div class="builder-footer-inner">
		<?php the_content(); ?>
	</div>
</footer>
