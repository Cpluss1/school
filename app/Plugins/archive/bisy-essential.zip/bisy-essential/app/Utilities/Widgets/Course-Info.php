<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {
  
    //
    // Create a about widget
    //
    CSF::createWidget( 'bisy_essential_course_info', array(
      'title'       => esc_html__('Bisy Course info','bisy-essential'),
      'classname'   => 'about-widget',
      'description' => esc_html__('About Learnpress Course info','bisy-essential'),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   => esc_html__('Title','bisy-essential'),
        ),
  
        array(
          'id'      => 'enable_button',
          'type'    => 'switcher',
          'title'   => esc_html__('Enable Button','bisy-essential'),
        ),
  
  
      )
    ) );
     
    if( ! function_exists( 'bisy_essential_course_info' ) ) {
      function bisy_essential_course_info( $args, $instance ) {

        if( !is_singular( 'lp_course' ) ){
          return;
        }
        
        echo $args['before_widget'];
       
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        $course       = LP_Global::course();
        $instructor   = $course->get_instructor();
        $sections     = $course->get_sections();
        $lesson_count = $course->count_items( LP_LESSON_CPT );
        $duration     = get_post_meta(get_the_id(),'_lp_duration',true);
        $_lp_external_link_text     = get_post_meta(get_the_id(),'_lp_external_link_text',true);
        $external_link   = $course->get_external_link();

       

        $already_enrolled = learn_press_is_enrolled_course( get_the_id(),get_current_user_id() );
        
        ?>
           
           <div class="info-course">

                <ul>
                    <li><i class="icon_house_alt"></i><span><?php echo esc_html__('Instructor','bisy-essential').':'; ?> </span>  <?php echo esc_html($instructor->get_display_name()); ?></li>
                    <li><i class="icon_document_alt"></i><span><?php echo esc_html__('Lectures','bisy-essential').':'; ?> </span> <?php echo esc_html($lesson_count); ?> </li>
                    <li><i class="icon_clock_alt"></i><span><?php echo esc_html__('Duration','bisy-essential').':'; ?> </span> <?php echo $duration > 1 ? sprintf( __( '%d weeks', 'learnpress' ), $lesson_count ) : sprintf( __( '%d week', 'bisy' ), $duration ); ?></li>
                    <li><i class="icon_profile"></i><span><?php echo esc_html__('Enrolled','bisy-essential').':'; ?></span> <?php echo esc_html($course->get_users_enrolled()); ?> students</li>
                    <?php if(bisy_meta_option(get_the_id(),'course_language','english') !=''): ?>
                        <li><i class="icon_cog"></i><span><?php echo esc_html__('Language','bisy-essential').':'; ?></span> <?php echo esc_html(bisy_meta_option(get_the_id(),'course_language','english')); ?></li>
                    <?php endif; ?>
                    <?php if(bisy_meta_option(get_the_id(),'course_deedline') !=''): ?>
                         <li><i class="icon_calendar"></i><span><?php echo esc_html__('Deadline','bisy-essential').':'; ?> </span> <?php echo esc_html( date('d M Y',strtotime( bisy_meta_option( get_the_id(),'course_deedline') )) ); ?></li>
                    <?php endif; ?>
                </ul>
                <?php if($instance['enable_button']): ?>
                  
                  <?php if( $course->get_external_link() ): ?>
                    <a href="<?php echo esc_url($external_link); ?>" class="bisylms-btn"> <?php echo $_lp_external_link_text?$_lp_external_link_text:esc_html__('Enroll Now','bisy-essential'); ?> </a>
                  <?php else: ?>

                    <?php get_template_part("learnpress/single-course/buttons"); ?>

                  <?php endif ?>
                <?php endif; ?>

            </div>
            

        <?php
  
        echo $args['after_widget'];
  
      }
    }
  
  }
  