<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

class Instructor_Slider extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-instructor-slider';
    }

    public function get_title() {
        return esc_html__( 'Instructor Slider', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-user";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() { 

    
    do_action( 'bisy_section_slider_tab', $this , $this->get_name()); 
    $this->start_controls_section('section_tab',
         [
            'label' => esc_html__('Instructor', 'bisy-essential'),
         ]
      );

     
            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
               'image',
               [
                  'label'   => esc_html__( 'Choose image', 'bisy-essential' ),
                  'type'    => \Elementor\Controls_Manager::MEDIA,
                  
               ]
            );
         
            $repeater->add_control(
               'title',
               [
                  'label'       => esc_html__( 'Name', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'designation',
               [
                  'label'       => esc_html__( 'Designation', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'url',
               [
                  'label'       => esc_html__( 'Profile Link', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'social_link_1',
               [
                  'label'       => esc_html__( 'Social Link 1', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'social_icon_1',
               [
                  'label' => esc_html__( 'Social Icon 1', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::ICONS,
                  'default' => [
                     'value' => 'social_facebook',
                     'library' => 'solid',
                  ],
               ]
            );

            $repeater->add_control(
               'social_link_2',
               [
                  'label'       => esc_html__( 'Social Link 2', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'social_icon_2',
               [
                  'label' => esc_html__( 'Social Icon 2', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::ICONS,
                  'default' => [
                     'value' => 'social_twitter',
                     'library' => 'solid',
                  ],
               ]
            );

            $repeater->add_control(
               'social_link_3',
               [
                  'label'       => esc_html__( 'Social Link 3', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'social_icon_3',
               [
                  'label' => esc_html__( 'Social Icon 3', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::ICONS,
                  'default' => [
                     'value' => 'social_vimeo',
                     'library' => 'solid',
                  ],
               ]
            );

            $repeater->add_control(
               'social_link_4',
               [
                  'label'       => esc_html__( 'Social Link 4', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'social_icon_4',
               [
                  'label' => esc_html__( 'Social Icon 4', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::ICONS,
                  'default' => [
                     'value' => 'social_tumblr',
                     'library' => 'solid',
                  ],
               ]
            );

            $repeater->add_control(
               'social_link_5',
               [
                  'label'       => esc_html__( 'Social Link 5', 'bisy-essential' ),
                  'type'        => \Elementor\Controls_Manager::TEXT,
                  
               ]
            );

            $repeater->add_control(
               'social_icon_5',
               [
                  'label' => esc_html__( 'Social Icon 5', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::ICONS,
                  'default' => [
                     'value' => 'fab fa-linkdin',
                     'library' => 'solid',
                  ],
               ]
            );
         
      
            $this->add_control(
               'list',
               [
                  'label'       => esc_html__( 'Instuctors List', 'plugin-domain' ),
                  'type'        => \Elementor\Controls_Manager::REPEATER,
                  'fields'      => $repeater->get_controls(),
                  'title_field' => '{{{ title }}}',
               ]
            );

      $this->end_controls_section();

      $this->start_controls_section(
			'section_name_style', [
				'label' => esc_html__( 'Instructor Name', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'name_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .teacher-meta h5 a' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'name_typho',
                        'label'    => esc_html__( 'Fonts', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .teacher-meta h5 a',
                    ]
                );
                

              
                $this->add_responsive_control(
                    'name_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .teacher-meta h5 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'name_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .teacher-meta h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_designation_style', [
				'label' => esc_html__( 'Instructor Designation', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'designation_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .teacher-meta p' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'designation_typho',
                        'label'    => esc_html__( 'Fonts', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .teacher-meta p',
                    ]
                );
                

              
                $this->add_responsive_control(
                    'designation_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .teacher-meta p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'designation_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .teacher-meta p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_social_style', [
				'label' => esc_html__( 'Social', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'social_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .teacher-social a' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );

                $this->add_control(
                  'social_bg_color', [

                      'label'     => esc_html__( 'Background Color', 'bisy-essential' ),
                      'type'      => Controls_Manager::COLOR,
                      'selectors' => [
                        '{{WRAPPER}} .teacher-social a' => 'background: {{VALUE}};',
                     
                      ],
                  ]
              );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'social_typho',
                        'label'    => esc_html__( 'Fonts', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .teacher-social a i',
                    ]
                );
                

                $this->add_responsive_control(
                    'social_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .teacher-social' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();
      
      $this->start_controls_section(
			'section_images_style', [
				'label' => esc_html__( 'Image', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      );

        // quote icon
         $this->add_responsive_control('image_quote_margin_n',
            [
               'label'      => esc_html__( 'Image Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%' ],

               'selectors' => [
                  '{{WRAPPER}} .teacher-thumb img' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
                 
               ],
            ]
         );

        
         $this->add_responsive_control(
            'quote_img_borders_radius',
            [
               'label'      => esc_html__( 'Border radius', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors' => [
                  
                  '{{WRAPPER}} .teacher-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                 
                  
               ],
            ]
         );

        
      $this->end_controls_section(); 

      $this->start_controls_section('bisy_style_slider_nav',
         [
            'label' => esc_html__( 'Navigation', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );

               $this->add_responsive_control(
                  'owl_nav_top_position',
                  [
                     'label'      => esc_html__( 'Position Top', 'bisy-essential' ),
                     'type'       => Controls_Manager::SLIDER,
                     'size_units' => [ 'px' ,'%' ],
                     'range'      => [
                        'px' => [
                           'min'  => -500,
                           'max'  => 800,
                           'step' => 1,
                        ],
                     
                     ],
                  
                     'selectors' => [
                        '{{WRAPPER}} .owl-dots' => 'top: {{SIZE}}{{UNIT}};',
                     ],
                  ]
               );
               $this->add_responsive_control(
                  'owl_nav_left_position',
                  [
                     'label'      => esc_html__( 'Position Left', 'bisy-essential' ),
                     'type'       => Controls_Manager::SLIDER,
                     'size_units' => [ 'px' ,'%' ],
                     'range'      => [
                        'px' => [
                           'min'  => -500,
                           'max'  => 800,
                           'step' => 1,
                        ],
                     
                     ],
                  
                     'selectors' => [
                        '{{WRAPPER}} .owl-dots' => 'left: {{SIZE}}{{UNIT}};',
                     ],
                  ]
               );
      
            $this->add_control(
               'nav_color',
               [
                  'label'     => esc_html__('Color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'selectors' => [
                     '{{WRAPPER}} .owl-dots button.active' => 'background: {{VALUE}};',
                  
                  ],
               
               ]
            );

            $this->add_control(
                  'nav_hvcolor',
                  [
                     'label'     => esc_html__('Hover color', 'bisy-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'selectors' => [
                        '{{WRAPPER}} .owl-dots button' => 'background: {{VALUE}};',
                     
                     ],
                     
                  ]
            );

       
      $this->end_controls_section();  

      $this->start_controls_section('bisy_main_section_section',
            [
            'label' => esc_html__( 'Item Box', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
      );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'section_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .teacher-item',
               ]
            );
  
            $this->add_responsive_control(
               'box_margin',
               [
                  'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} .teacher-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .teacher-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                  ]
            );

            $this->add_control(
               'border_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} .teacher-item' => 'border-radius: {{VALUE}}px;',
                  ],
               ]
            ); 
            
            $this->add_control(
               'hover_section_background_heading',
               [
                  'label' => esc_html__( 'Hover Background', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::HEADING,
                  'separator' => 'before',
               ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'hover_section_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .teacher-thumb',
               ]
            );

      $this->end_controls_section();
   }
   protected function render(){

     $settings         = $this->get_settings();
     $instructors       = $settings['list'];
     $slider_enable    = $settings['slider_enable'];
     $slide_controls   = bisy_widgets_slider_controls_setttings($settings);
      
  
    ?>
  
      <div class="teachers-slider owl-carousel" data-controls='<?php echo json_encode($slide_controls); ?>'>
         <?php foreach($instructors as $item): ?>
               <div class="teacher-item">
                  <div class="teacher-thumb">
                      <?php if($item['image']['url'] !=''): ?>
                         <img src="<?php echo esc_url($item['image']['url']); ?>" alt="<?php echo esc_attr($item['title']); ?>">
                      <?php endif; ?>
                     <div class="teacher-social">
                           <?php if($item['social_link_1'] !=''): ?> 
                              <a href="<?php echo esc_url($item['social_link_1']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_1'], [ 'aria-hidden' => 'true' ] ); ?>
                              </a>
                           <?php endif; ?>
                           <?php if($item['social_link_2'] !=''): ?> 
                              <a href="<?php echo esc_url($item['social_link_2']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_2'], [ 'aria-hidden' => 'true' ] ); ?>
                              </a>
                           <?php endif; ?>
                           <?php if($item['social_link_3'] !=''): ?> 
                              <a href="<?php echo esc_url($item['social_link_3']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_3'], [ 'aria-hidden' => 'true' ] ); ?>
                              </a>
                           <?php endif; ?>
                           <?php if( $item['social_link_4'] !='' ): ?> 
                              <a href="<?php echo esc_url($item['social_link_4']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_4'], [ 'aria-hidden' => 'true' ] ); ?>
                              </a>
                           <?php endif; ?>
                           <?php if($item['social_link_5'] !=''): ?> 
                              <a href="<?php echo esc_url($item['social_link_5']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_5'], [ 'aria-hidden' => 'true' ] ); ?>
                              </a>
                           <?php endif; ?>
                     </div>
                  </div>
                  <div class="teacher-meta">
                     <h5>
                         <?php if($item['url'] !=''): ?>
                           <a href="<?php echo esc_url($item['url']); ?>"> 
                           <?php endif; ?>
                              <?php echo esc_html($item['title']); ?>
                              <?php if($item['url'] !=''): ?>
                           </a>
                        <?php endif; ?>
                         </h5>
                     <?php if( $item['designation'] !='' ): ?>
                        <p><?php echo esc_html($item['designation']); ?></p>
                     <?php endif; ?>
                  </div>
               </div>
         <?php endforeach; ?>
      </div>
  
     
   <?php  
   }
}  