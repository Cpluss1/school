<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class SignUp extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-signup';
    }

    public function get_title() {
        return esc_html__( 'Signup / Registration', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'far fa-user';
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }
      
    protected function _register_controls() {

        
        $this->start_controls_section(
            'section_copyright_tab',
            [
                'label' => esc_html__('Copyright', 'bisy-essential'),
            ]
        );

        $this->add_control(
            'copyright_show',
            [
                'label'        => esc_html__( 'Show', 'bisy-essential' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'bisy-essential' ),
                'label_off'    => esc_html__( 'Hide', 'bisy-essential' ),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );

        $this->add_control(
            'copyright_text', [
                'label'       => esc_html__( 'Copyright', 'bisy-essential' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Sub content ', 'bisy-essential' ),
                'default'     => esc_html__( 'Welcome back, Start the adventure', 'bisy-essential' ),
            ]
        );
       
        $this->end_controls_section();
        $this->start_controls_section(
            'section_media_tab',
            [
                'label' => esc_html__('Media', 'bisy-essential'),
            ]
        );
            $this->add_control(
                'shape_image',
                [
                    'label'   => esc_html__( 'Choose Shape', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => BISY_ESSENTIAL_IMG.'/shapes/login-shape.png',
                    ],
                ]
            );
            $this->add_responsive_control(
                'shape_border_line_pos_top',
                [
                    'label' => esc_html__( 'Position Bottom', 'bisy-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} .login-area .login-bg .login-shape' => 'bottom: {{SIZE}}{{UNIT}};',
                        
                        
                    ],
                   
                ]
            );
            $this->add_responsive_control(
                'shape_border_line_pos_left',
                [
                    'label' => esc_html__( 'Position Left', 'bisy-essential' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => -500,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    
                    'selectors' => [
                        '{{WRAPPER}} .login-area .login-bg .login-shape' => 'left: {{SIZE}}{{UNIT}};',
                        
                        
                    ],
                   
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Form Heading', 'bisy-essential'),
            ]
        );

            

            $this->add_control(
                'title', [
                    'label'			  => esc_html__( 'Title text', 'bisy-essential' ),
                    'type'			  => Controls_Manager::TEXT,
                    'label_block'	  => true,
                    
                ]
            );

            $this->add_control(
                'sub_title', [
                    'label'			  => esc_html__( 'Sub Title text', 'bisy-essential' ),
                    'type'			  => Controls_Manager::TEXTAREA,
                    'label_block'	  => true,
                    
                ]
            );
            

 
          
        $this->end_controls_section();

        $this->start_controls_section(
            'section_fields',
            [
                'label' => esc_html__('Fields', 'bisy-essential'),
            ]
        );

       

        $this->add_control(
            'name_placeholder', [
                'label'			  => esc_html__( 'Name placeholder', 'bisy-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Your name ', 'bisy-essential' ),
                'default'	     => esc_html__( 'Your name ', 'bisy-essential' ),
            
                
            ]
        );
      
        $this->add_control(
            'username_placeholder', [
                'label'			  => esc_html__( 'Username placeholder', 'bisy-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'username ', 'bisy-essential' ),
                'default'	     => esc_html__( 'Username ', 'bisy-essential' ),
            
                
            ]
        );
        // email

        $this->add_control(
            'email_placeholder', [
                'label'			  => esc_html__( 'Email placeholder', 'bisy-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'email ', 'bisy-essential' ),
                'default'	     => esc_html__( 'Your Email ', 'bisy-essential' ),
            
                
            ]
        );

      

        $this->add_control(
            'password_placeholder', [
                'label'			  => esc_html__( 'Password placeholder', 'bisy-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'password ', 'bisy-essential' ),
                'default'	     => esc_html__( 'password ', 'bisy-essential' ),
            
                
            ]
        );

       
        $this->add_control(
            'submit_text', [
                'label'			  => esc_html__( 'Submit text', 'bisy-essential' ),
                'type'			  => Controls_Manager::TEXT,
                'label_block'	  => true,
                'placeholder'    => esc_html__( 'Submit ', 'bisy-essential' ),
                'default'	     => esc_html__( 'Login to your account ', 'bisy-essential' ),
            
                
            ]
        );
     
        $this->end_controls_section();

        $this->start_controls_section(
            'section_remenber_content',
            [
                'label' => esc_html__('Remenber ', 'bisy-essential'),
            ]
        );

                $this->add_control(
                    'remember_show',
                    [
                        'label'        => esc_html__( 'show', 'bisy-essential' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                        'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                        'return_value' => 'yes',
                        'default'      => 'yes',
                    ]
                );
            
                $this->add_control(
                    'remember_text',
                    [
                        'label'       => esc_html__( 'Title', 'bisy-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXTAREA,
                        'default'     => esc_html__( 'Remember Me', 'bisy-essential' ),
                        'placeholder' => esc_html__( 'Type your title here', 'bisy-essential' ),
                    ]
                );
        
         $this->end_controls_section();

         $this->start_controls_section(
            'section_registration',
            [
                'label' => esc_html__('Login Link', 'bisy-essential'),
            ]
        );

            $this->add_control(
                'reg_link_show',
                [
                    'label'        => esc_html__( 'show', 'bisy-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                    'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );
            $this->add_control(
                'registration_button_title', [
                    'label'       => esc_html__( 'Title text', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'write a text here ', 'bisy-essential' ),
                    'default'     => esc_html__( 'Do you have account?', 'bisy-essential' ),
                ]
            );
            $this->add_control(
                'button_registration',
                [
                    'label'       => esc_html__( 'Link Text', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'SignUp', 'bisy-essential' ),
                    'placeholder' => esc_html__( 'Type your title here', 'bisy-essential' ),
                ]
            );
            
            $this->add_control(
                'registration_link',
                [
                    'label'         => esc_html__( 'Link', 'bisy-essential' ),
                    'type'          => \Elementor\Controls_Manager::URL,
                ]
            );  
        
        $this->end_controls_section();


        $this->start_controls_section(
            'registration_header_arear_style_section',
            [
                'label' => esc_html__( 'Header', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_responsive_control(
                'left_text_align', [
                    'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                        '{{WRAPPER}} .login-title' => 'text-align: {{VALUE}};',

                    ],
                ]
            );//Responsive control end
            
            $this->add_control(
                'headee0_title_color', [

                    'label'		 => esc_html__( 'Title color', 'bisy-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .login-title .title' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_control(
                'headee0_title_normal_color', [

                    'label'		 => esc_html__( 'Bracket words color', 'bisy-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .login-title .title span' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'header_title_typho',
                    'label'    => esc_html__( 'Title Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .login-title .title',
                ]
            );

            
            $this->add_responsive_control(
                'header_ttile_margin',
                [
                    'label'      => esc_html__( 'Title Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .login-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'headee0_content_color', [

                    'label'		 => esc_html__( 'Content color', 'bisy-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .login-title p' => 'color: {{VALUE}};',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'header_content_typho',
                    'label'    => esc_html__( 'Content Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .login-title p',
                ]
            );

            
            $this->add_responsive_control(
                'header_content_margin',
                [
                    'label'      => esc_html__( 'Content Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .login-title p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
      

        $this->end_controls_section();

        $this->start_controls_section(
            'ultimate_remember_style_section',
            [
                'label' => esc_html__( 'Remember', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_responsive_control(
                'remember_btn_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .checkbox_common li label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'remember_box_typography',
                  
                    'selector' => '{{WRAPPER}} .checkbox_common li label',
                    
                ]
            );

            $this->add_control(
                'remember_box_text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .checkbox_common li label'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'remember_box_link_color',
                [
                    'label'     => esc_html__( 'Link Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .checkbox_common li label a'  => 'color:{{VALUE}};',
                    ],
                ]
            );
            $this->add_control(
                'remember_box_check_color',
                [
                    'label'     => esc_html__( 'Check box Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}}  li input[type=checkbox] + label span::before'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_control(
                'remember_box_check_bgcolor',
                [
                    'label'     => esc_html__( 'Check box bgColor', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} li input[type=checkbox]:checked + label span'  => 'background:{{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'remember_box_check_border',
                    'label'    => esc_html__( 'Border', 'bisy-essential' ),
                    'selector' => ' {{WRAPPER}} .checkbox_common li input[type=checkbox] + label span',
                     
                    
                ]
            );
        $this->end_controls_section();
        //
     
        
        /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_input_style_section',
            [
                'label' => esc_html__( 'Input', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'input_box_tabs' );
                $this->start_controls_tab(
                    'input_box_normal_tab',
                    [
                        'label' => esc_html__( 'Normal', 'bisy-essential' ),
                    ]
                );
                    $this->add_responsive_control(
                        'input_box_height',
                        [
                            'label'      => esc_html__( 'Height', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'max' => 150,
                                ],
                            ],
                            'default' => [
                                'size' => 55,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .input'   => 'height:{{SIZE}}{{UNIT}};',
                           
                               
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_width',
                        [
                            'label'      => esc_html__( 'Width', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'default' => [
                                'unit' => '%',
                                'size' => 100,
                            ],
                            'selectors' => [
                                '{{WRAPPER}}  .input'=> 'width:{{SIZE}}{{UNIT}};',
                         
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_box_typography',
                          
                            'selector' => '{{WRAPPER}} .input',
                              
                        ]
                    );

                    $this->add_control(
                        'input_box_text_color',
                        [
                            'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .input'  => 'color:{{VALUE}};',
                              
                        
                            ],
                        ]
                    );

                    $this->add_control(
                        'input_box_bgtext_color',
                        [
                            'label'     => esc_html__( 'Background Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .input'  => 'Background:{{VALUE}} !important;',
                              
                        
                            ],
                        ]
                    );
                   
                    $this->add_control(
                        'input_box_placeholder_color',
                        [
                            'label'     => esc_html__( 'Placeholder Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}}  .input::-webkit-input-placeholder'   => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'            => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'        => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-webkit-input-placeholder'  => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'           => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'       => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-webkit-input-placeholder'    => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input::-moz-placeholder'             => 'color: {{VALUE}};',
                                '{{WRAPPER}}  .input:-ms-input-placeholder'         => 'color: {{VALUE}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_box_border',
                            'label'    => esc_html__( 'Border', 'bisy-essential' ),
                            'selector' => ' {{WRAPPER}} .input',
                             
                            
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_border_radius',
                        [
                            'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                            'type'      => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .input' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                             ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_box_shadow',
                            'selector' => '{{WRAPPER}} .input',   
                            
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}}  .input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                              
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}}  .input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_control(
                        'input_box_transition',
                        [
                            'label'      => esc_html__( 'Transition', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .input'   => 'transition: {{SIZE}}s;',
                           

                            ],
                        ]
                    );
                $this->end_controls_tab();
                $this->start_controls_tab(
                    'input_box_hover_tabs',
                    [
                        'label' => esc_html__( 'Focus', 'bisy-essential' ),
                    ]
                );
                $this->add_control(
                    'input_box_hover_color',
                    [
                        'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .input:focus'  => 'color:{{VALUE}};',
                         
                         
                        ],
                    ]
                );
              
                $this->add_control(
                    'input_box_hover_border_color',
                    [
                        'label'     => esc_html__( 'Border Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .input:focus'   => 'border-color:{{VALUE}};',
                         ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Box_Shadow:: get_type(),
                    [
                        'name'     => 'input_box_hover_shadow',
                        'selector' => '{WRAPPER}} .input:focus',
                          
                    ]
                );
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();


                /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_submit_style_section',
            [
                'label' => esc_html__( 'Submit', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'submit_box_height',
            [
                'label'      => esc_html__( 'Height', 'bisy-essential' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
                'default' => [
                    'size' => 55,
                ],
                'selectors' => [
                    '{{WRAPPER}} .main-btn'=> 'height:{{SIZE}}{{UNIT}};',
               
                   
                ],
            ]
        );
        $this->add_responsive_control(
            'submit_box_width',
            [
                'label'      => esc_html__( 'Width', 'bisy-essential' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .main-btn'=> 'width:{{SIZE}}{{UNIT}};',
             
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'submit_box_typography',
              
                'selector' => '{{WRAPPER}} .main-btn',
                   
            ]
        );
        $this->add_control(
            'submit_box_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-btn'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'gradient_submit__background',
                    'label' => esc_html__( 'Background', 'bisy-essential' ),
                    'types' => [ 'gradient' ],
                    'selector' => '{{WRAPPER}} .main-btn',
                    
                ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'submit_border',
				'label' => esc_html__( 'Border', 'bisy-essential' ),
				'selector' => '{{WRAPPER}} .main-btn',
			]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow:: get_type(),
            [
                'name'     => 'submit_box_shadow',
                'selector' => '{{WRAPPER}} .main-btn',   
                
            ]
        );

        $this->add_responsive_control(
			'submit_btn_margin',
			[
				'label'      => esc_html__( 'Margin', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 
                    'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        
        $this->add_responsive_control(
			'submit_btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 
                    'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
     
        $this->add_responsive_control(
            'submit_btn_borders_radius',
            [
               'label'      => esc_html__( 'Border radius', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors' => [
                  
                  '{{WRAPPER}} .main-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                 
                  
               ],
            ]
         );
        $this->end_controls_section();
      

        $this->start_controls_section(
            'ultimate_login_style_section',
            [
                'label' => esc_html__( ' Login / Footer ', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'registration_text_typography',
                  
                    'selector' => '{{WRAPPER}} .login-form .create-account-link span',
                    
                ]
            );

            $this->add_control(
                'registration_text__text_color',
                [
                    'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .login-form .create-account-link span'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'registration_link_text_typography',
                  
                    'label'    => esc_html__( 'Link typhography', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .login-form .create-account-link span a',
                    
                ]
            );
            $this->add_control(
                'registration_link___text_color',
                [
                    'label'     => esc_html__( 'Link Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .login-form .create-account-link span a'  => 'color:{{VALUE}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'registration_text__margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .login-form .create-account-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'registration_text__password',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 
                        'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .login-form .create-account-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section(); 
        //Copyright
        $this->start_controls_section(
            'ultimate_copyright_style_section',
            [
                'label' => esc_html__( 'Copyright', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'copyright_section_text_typography',
                      
                        'selector' => '{{WRAPPER}} .copyright-item p',
                        
                    ]
                );

                $this->add_control(
                    'copyright_section_text_color',
                    [
                        'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .copyright-item p'  => 'color:{{VALUE}};',
                        ],
                    ]
                );
                $this->add_control(
                    'copyright_section_bracket_text_color',
                    [
                        'label'     => esc_html__( 'Bracket Word Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .copyright-item p span'  => 'color:{{VALUE}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'copyright_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 
                            'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .copyright-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'copyright_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 
                            'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .copyright-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );
        $this->end_controls_section();
        $this->start_controls_section(
			'section_box_style', [
				'label' => esc_html__( 'Box', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
            'full_width',
            [
                'label'        => esc_html__( 'Full width', 'bisy-essential' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                'return_value' => 'yes',
                'default'      => '',
            ]
        );
        $this->add_control(
            'login_right_col_heading',
            [
               'label' => esc_html__( 'Right Column Bg', 'bisy-essential' ),
               'type' => \Elementor\Controls_Manager::HEADING,
               'separator' => 'before',
               
            ]
         );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'right_cil_box_background',
                        'label' => esc_html__( 'Background', 'bisy-essential' ),
                        'types' => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .login-area::before',
                    ]
                );
                
                $this->add_control(
                    'login_left_col_heading',
                    [
                    'label' => esc_html__( 'Left Column', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'left_col_box_background',
                        'label' => esc_html__( 'Background', 'bisy-essential' ),
                        'types' => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .login-area .login-bg',
                    ]
                );

                $this->add_control(
                    'login_lehapeft_col_heading',
                    [
                    'label' => esc_html__( 'Shape One Color', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name' => 'shape_one_box_background',
                        'label' => esc_html__( 'Background', 'bisy-essential' ),
                        'types' => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .login-area .login-bg::before',
                    ]
                );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'box_border',
				'label' => esc_html__( 'Border', 'bisy-essential' ),
				'selector' => '{{WRAPPER}} .login-area',
			]
        );

       
        $this->add_responsive_control(
			'box_padding',
			[
				'label'      => esc_html__( 'Padding', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .login-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        $this->add_responsive_control(
			'box_margin',
			[
				'label'      => esc_html__( 'Margin', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .login-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'alignment_style_section',
            [
                'label' => esc_html__( 'Alignment', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
			'input_align', [
				'label'   => esc_html__( 'Input Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
				
				],
               
            
                'selectors' => [
                     '{{WRAPPER}} .login-form .input-box input ' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
      

        $this->add_responsive_control(
			'submit_btn_align', [
				'label'   => esc_html__( 'Submit button', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
                    'space-between'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				
				],
               
            
                'selectors' => [
                     '{{WRAPPER}} .login-form .input-box button' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end

        $this->add_responsive_control(
			'content_align', [
				'label'   => esc_html__( 'Form Content button', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
                    'space-between'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				
				],
               
            
                'selectors' => [
                     '{{WRAPPER}} .login-form' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();

        $this->start_controls_section(
            'alignment_success_msg_section',
            [
                'label' => esc_html__( 'Success Message', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'success_msg_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
				
				],
               'default' => 'left',
            
                'selectors' => [
                     '{{WRAPPER}} .success' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->add_control(
            'tsuccess__text_color',
            [
                'label'     => esc_html__( 'Message Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .success'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'tsucces_text_typography',
              
                'label'     => esc_html__( 'Message', 'bisy-essential' ),
                'selector' => '{{WRAPPER}} .success',
                   
            ]
        );

        $this->add_control(
            'tsuccess_link_text_color',
            [
                'label'     => esc_html__( 'Link Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .success a'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'tsuccess_typography',
              
                'label'     => esc_html__( 'Link', 'bisy-essential' ),
                'selector' => '{{WRAPPER}} .success a',
                   
            ]
        );
        $this->add_responsive_control(
			'success_margin',
			[
				'label'      => esc_html__( 'Margin', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .success' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'error__msg_section',
            [
                'label' => esc_html__( 'Error Message', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'error_msg_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

                    'left'		 => [
                        
                        'title' => esc_html__( 'Left', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-left',
                    
                    ],
                    'center'	     => [
                        
                        'title' => esc_html__( 'Center', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-center',
                    
                    ],
                    'right'	 => [

                        'title' => esc_html__( 'Right', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-right',
                        
                    ],
				
				],
               'default' => 'left',
            
                'selectors' => [
                     '{{WRAPPER}} .errors' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->add_control(
            'error__text_color',
            [
                'label'     => esc_html__( 'Message Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .errors li'  => 'color:{{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'eror_text_typography',
              
                'label'     => esc_html__( 'Message', 'bisy-essential' ),
                'selector' => '{{WRAPPER}} .errors li',
                   
            ]
        );

       
        $this->add_responsive_control(
			'error_msg_margin',
			[
				'label'      => esc_html__( 'Margin', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .errors' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
        $this->add_responsive_control(
			'error_msg_padding',
			[
				'label'      => esc_html__( 'Padding', 'bisy-essential' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .errors li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );

        $this->end_controls_section();
    } //Register control end


    protected function render( ) { 

		$settings     = $this->get_settings();
		$title        = $settings['title'];
        $title_1      = str_replace(['{', '}'], ['<span>', '</span>'], $title); 
       
       
    ?>
     
       <!--====== LOGIN PART START ======-->

    <section class="login-area singup-area">
        <div class="login-bg">
            <div class="login-shape">
                <?php if($settings['shape_image']['url'] !=''): ?>
                   <img src=" <?php echo esc_url($settings['shape_image']['url']); ?>" alt="<?php echo esc_html($settings['title']); ?>">
                <?php endif; ?>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-<?php echo esc_attr($settings['full_width'] == 'yes'?'12':'6'); ?>">
                    <div class="login-title">
                            <?php

                                $errors = [];
                                if(isset($_SESSION["BISY_reg_msg"])){
                                    $errors = $_SESSION["BISY_reg_msg"];      
                                }       
                                
                            ?>
                            <?php if( count( $errors) ): ?>
                                    <ul class="errors">
                                          <?php foreach($errors as $error): ?>
                                            <li> <?php echo esc_html($error); ?> </li>
                                        <?php endforeach; ?>
                                    </ul>
                            <?php 
                                    unset($_SESSION["bisy_reg_msg"]); 
                                endif; 
                            ?>
                             <?php if(isset($_SESSION['bisy_reg_msg_success'])): ?>
                                <h2 class="success">
                                    <?php echo esc_html($_SESSION['bisy_reg_msg_success']); unset($_SESSION["bisy_reg_msg_success"]); ?> 
                                    <a 
                                                
                                        rel="<?php echo esc_attr($settings['registration_link']['nofollow']?'nofollow':''); ?> " 
                                        target="<?php echo  esc_attr($settings['registration_link']['is_external']?"_blank":"_self"); ?>" 
                                        href="<?php echo esc_url($settings['registration_link']['url']); ?>"
                                    >
                                      <?php echo esc_html__( 'go to login page', 'bisy-essential' ) ?> 
                                    </a> 
                                </h2>
                                
                            <?php endif; ?>
                        <h3 class="title"><?php echo bisy_kses($title_1); ?></h3>

                            <?php if($settings['sub_title'] !=''): ?>
                               <p> <?php echo esc_html($settings['sub_title']); ?> </p>
                            <?php endif; ?>
                    </div>
                    <div class="login-form">
                        <form action="#" method="post">
                            <div class="input-box mt-30">
                                <input type="text" class="input" name="name" placeholder="<?php echo esc_attr($settings['name_placeholder']); ?>">
                            </div>
                            <div class="input-box mt-30">
                                <input type="text" name="username" class="input" placeholder="<?php echo esc_attr($settings['username_placeholder']); ?>">
                            </div>
                            <div class="input-box mt-30">
                                <input type="email" name="email" class="input" placeholder="<?php echo esc_attr($settings['email_placeholder']); ?>">
                            </div>
                            <div class="input-box mt-30">
                                <input type="password" name="password" class="input" placeholder="<?php echo esc_attr($settings['password_placeholder']); ?>">
                                <ul>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                </ul>
                            </div>
                            <input type="hidden" name="bisy_registration_form" />
                            <?php wp_nonce_field('bisy_registration_action'); ?>
                            <div class="input-btns pt-20 pb-20">
                                
                                <?php if($settings['remember_show'] == 'yes'): ?>  
                                        <ul class="checkbox_common checkbox_style5">
                                            <li>
                                                <input type="checkbox" class="form-check" name="rememberme" id="remember-me">
                                                <label for="remember-me"><span></span> <?php echo bisy_kses($settings['remember_text']); ?> </label>
                                            </li>
                                        </ul>
                                <?php endif; ?>
                            </div>
                            
                            <div class="input-box">
                                <button class="main-btn" type="submit"> <?php echo esc_html($settings['submit_text']); ?>  </button>
                            </div>
                           
                            <?php if( $settings['reg_link_show'] =='yes' ): ?> 
                               
                               <div class="create-account-link mt-40">
                                   <span><?php echo esc_html( $settings['registration_button_title'] ) ?>
                                       <a href="<?php echo esc_url( $settings['registration_link']['url'] ); ?>">
                                           <?php echo esc_html( $settings['button_registration'] ); ?> 
                                       </a>
                                   </span>
                               </div>

                           <?php endif; ?>
                        </form>
                    </div>
                   
                    <?php if($settings['copyright_show'] == 'yes'): ?>
                        <div class="copyright-item mt-120 mb-50">
                            <p> 
                                <?php
                                  $copyright = str_replace(['{', '}'], ['<span>', '</span>'], $settings['copyright_text']);
                                  echo bisy_kses( $copyright );
                                
                                ?> 
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

   

    <?php  

    }
    
    protected function _content_template() { }
}