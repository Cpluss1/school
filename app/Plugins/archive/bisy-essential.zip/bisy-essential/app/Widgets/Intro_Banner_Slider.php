<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit;


class Intro_Banner_Slider extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-intro-banner-slider';
    }

    public function get_title() {
        return esc_html__( 'Banner Slider', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fab fa-adversal";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    public static function get_animation_style(){
		return [
			'Zoom_In_Out'        => esc_html__('Zoom_In_Out', 'bisy-essential'),
			'Circle_Large'       => esc_html__('Circle_Large', 'bisy-essential'),
			'Fade_In_Out'        => esc_html__('Fade_In_Out', 'bisy-essential'),
			'littleCircle'       => esc_html__('littleCircle', 'bisy-essential'),
			'bigCircle'          => esc_html__('bigCircle', 'bisy-essential'),
			'Hoop'               => esc_html__('Hoop', 'bisy-essential'),
			'triAngle'           => esc_html__('triAngle', 'bisy-essential'),
			'littleSquare'       => esc_html__('littleSquare', 'bisy-essential'),
			'bigSquare'          => esc_html__('bigSquare', 'bisy-essential'),
			'fadeInRotate'       => esc_html__('fadeInRotate', 'bisy-essential'),
			'fadeInBack'         => esc_html__('fadeInBack', 'bisy-essential'),
			'blurFadeIn'         => esc_html__('blurFadeIn', 'bisy-essential'),
			'blurFadeInOut'      => esc_html__('blurFadeInOut', 'bisy-essential'),
			'ballBounce'         => esc_html__('ballBounce', 'bisy-essential'),
			'zoomBounce'         => esc_html__('zoomBounce', 'bisy-essential'),
			'FramesOne'          => esc_html__('FramesOne', 'bisy-essential'),
			'FramesTwo'          => esc_html__('FramesTwo', 'bisy-essential'),
			'FramesThree'        => esc_html__('FramesThree', 'bisy-essential'),
			'FramesFour'         => esc_html__('FramesFour', 'bisy-essential'),
			'FramesFive'         => esc_html__('FramesFive', 'bisy-essential'),
			'scaleUpOne'         => esc_html__('scaleUpOne', 'bisy-essential'),
			'scaleUpOne'         => esc_html__('scaleUpOne', 'bisy-essential'),
			'scaleUpTwo'         => esc_html__('scaleUpTwo', 'bisy-essential'),
			'scaleUpThree'       => esc_html__('scaleUpThree', 'bisy-essential'),
			'prettyFade'         => esc_html__('prettyFade', 'bisy-essential'),
			'fade_in'            => esc_html__('fade_in', 'bisy-essential'),
			'scaleRight'         => esc_html__('scaleRight', 'bisy-essential'),
			'scaleUpOne'         => esc_html__('scaleUpOne', 'bisy-essential'),
			'bigSpin'            => esc_html__('bigSpin', 'bisy-essential'),
			'rotated'            => esc_html__('rotated', 'bisy-essential'),
			'rotatedHalf'        => esc_html__('rotatedHalf', 'bisy-essential'),
			'rotatedHalfTwo'     => esc_html__('rotatedHalfTwo', 'bisy-essential'),
			'jump'               => esc_html__('jump', 'bisy-essential'),
			'imageBgAnim'        => esc_html__('imageBgAnim', 'bisy-essential'),
			'bgMove'             => esc_html__('bgMove', 'bisy-essential'),
			'gradientBG'         => esc_html__('gradientBG', 'bisy-essential'),
			'rippleOutOne'       => esc_html__('rippleOutOne', 'bisy-essential'),
			'rippleOuTwo'        => esc_html__('rippleOuTwo', 'bisy-essential'),
			'bounce'             => esc_html__('bounce','bisy-essential'),
			'flash'              => esc_html__('flash','bisy-essential'),
			'pulse'              => esc_html__('pulse','bisy-essential'),
			'rubberBand'         => esc_html__('rubberBand','bisy-essential'),
			'shake'              => esc_html__('shake','bisy-essential'),
			'headShake'          => esc_html__('headShake','bisy-essential'),
			'swing'              => esc_html__('swing','bisy-essential'),
			'tada'               => esc_html__('tada','bisy-essential'),
			'wobble'             => esc_html__('wobble','bisy-essential'),
			'jello'              => esc_html__('jello','bisy-essential'),
			'heartBeat'          => esc_html__('heartBeat','bisy-essential'),
			'bounceIn'           => esc_html__('bounceIn','bisy-essential'),
			'bounceInDown'       => esc_html__('bounceInDown','bisy-essential'),
			'bounceInLeft'       => esc_html__('bounceInLeft','bisy-essential'),
			'bounceInRight'      => esc_html__('bounceInRight','bisy-essential'),
			'bounceInUp'         => esc_html__('bounceInUp','bisy-essential'),
			'bounceOut'          => esc_html__('bounceOut','bisy-essential'),
			'bounceOutDown'      => esc_html__('bounceOutDown','bisy-essential'),
			'bounceOutLeft'      => esc_html__('bounceOutLeft','bisy-essential'),
			'bounceOutRight'     => esc_html__('bounceOutRight','bisy-essential'),
			'bounceOutUp'        => esc_html__('bounceOutUp','bisy-essential'),
			'fadeIn'             => esc_html__('fadeIn','bisy-essential'),
			'fadeInDown'         => esc_html__('fadeInDown','bisy-essential'),
			'fadeInDownBig'      => esc_html__('fadeInDownBig','bisy-essential'),
			'fadeInLeft'         => esc_html__('fadeInLeft','bisy-essential'),
			'fadeInLeftBig'      => esc_html__('fadeInLeftBig','bisy-essential'),
			'fadeInRight'        => esc_html__('fadeInRight','bisy-essential'),
			'fadeInRightBig'     => esc_html__('fadeInRightBig','bisy-essential'),
			'fadeInUp'           => esc_html__('fadeInUp','bisy-essential'),
			'fadeInUpBig'        => esc_html__('fadeInUpBig','bisy-essential'),
			'fadeOut'            => esc_html__('fadeOut','bisy-essential'),
			'fadeOutDown'        => esc_html__('fadeOutDown','bisy-essential'),
			'fadeOutDownBig'     => esc_html__('fadeOutDownBig','bisy-essential'),
			'fadeOutLeft'        => esc_html__('fadeOutLeft','bisy-essential'),
			'fadeOutLeftBig'     => esc_html__('fadeOutLeftBig','bisy-essential'),
			'fadeOutRight'       => esc_html__('fadeOutRight','bisy-essential'),
			'fadeOutRightBig'    => esc_html__('fadeOutRightBig','bisy-essential'),
			'fadeOutUp'          => esc_html__('fadeOutUp','bisy-essential'),
			'fadeOutUpBig'       => esc_html__('fadeOutUpBig','bisy-essential'),
			'flip'               => esc_html__('flip','bisy-essential'),
			'flipInX'            => esc_html__('flipInX','bisy-essential'),
			'flipInY'            => esc_html__('flipInY','bisy-essential'),
			'flipOutX'           => esc_html__('flipOutX','bisy-essential'),
			'flipOutY'           => esc_html__('flipOutY','bisy-essential'),
			'lightSpeedIn'       => esc_html__('lightSpeedIn','bisy-essential'),
			'lightSpeedOut'      => esc_html__('lightSpeedOut','bisy-essential'),
			'rotateIn'           => esc_html__('rotateIn','bisy-essential'),
			'rotateInDownLeft'   => esc_html__('rotateInDownLeft','bisy-essential'),
			'rotateInDownRight'  => esc_html__('rotateInDownRight','bisy-essential'),
			'rotateInUpLeft'     => esc_html__('rotateInUpLeft','bisy-essential'),
			'rotateInUpRight'    => esc_html__('rotateInUpRight','bisy-essential'),
			'rotateOut'          => esc_html__('rotateOut','bisy-essential'),
			'rotateOutDownLeft'  => esc_html__('rotateOutDownLeft','bisy-essential'),
			'rotateOutDownRight' => esc_html__('rotateOutDownRight','bisy-essential'),
			'rotateOutUpLeft'    => esc_html__('rotateOutUpLeft','bisy-essential'),
			'rotateOutUpRight'   => esc_html__('rotateOutUpRight','bisy-essential'),
			'hinge'              => esc_html__('hinge','bisy-essential'),
			'jackInTheBox'       => esc_html__('jackInTheBox','bisy-essential'),
			'rollIn'             => esc_html__('rollIn','bisy-essential'),
			'rollOut'            => esc_html__('rollOut','bisy-essential'),
			'zoomIn'             => esc_html__('zoomIn','bisy-essential'),
			'zoomInDown'         => esc_html__('zoomInDown','bisy-essential'),
			'zoomInLeft'         => esc_html__('zoomInLeft','bisy-essential'),
			'zoomInRight'        => esc_html__('zoomInRight','bisy-essential'),
			'zoomInUp'           => esc_html__('zoomInUp','bisy-essential'),
			'zoomOut'            => esc_html__('zoomOut','bisy-essential'),
			'zoomOutDown'        => esc_html__('zoomOutDown','bisy-essential'),
			'zoomOutLeft'        => esc_html__('zoomOutLeft','bisy-essential'),
			'zoomOutRight'       => esc_html__('zoomOutRight','bisy-essential'),
			'zoomOutUp'          => esc_html__('zoomOutUp','bisy-essential'),
			'slideInDown'        => esc_html__('slideInDown','bisy-essential'),
			'slideInLeft'        => esc_html__('slideInLeft','bisy-essential'),
			'slideInRight'       => esc_html__('slideInRight','bisy-essential'),
			'slideInUp'          => esc_html__('slideInUp','bisy-essential'),
			'slideOutDown'       => esc_html__('slideOutDown','bisy-essential'),
			'slideOutLeft'       => esc_html__('slideOutLeft','bisy-essential'),
			'slideOutRight'      => esc_html__('slideOutRight','bisy-essential'),
			'slideOutUp'         => esc_html__('slideOutUp','bisy-essential'),
		];
	}

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );
            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Video Style 1', 'bisy-essential' ),
                        'style2' => esc_html__( 'Video Style 2', 'bisy-essential' ),
                     
                    ],
                ]
            );

        $this->end_controls_section();
        $this->start_controls_section(
            'section_slider_animate_tab',
            [
                'label' => esc_html__('Slider Animation', 'bisy-essential'),
            ]
        );

            $this->add_control(
                'slider_animation_in',
                [
                    'label'   => esc_html__( 'Animate In', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'zoomIn',
                    'options' => self::get_animation_style(),
                ]
            );

            $this->add_control(
                'slider_animation_out',
                [
                    'label'   => esc_html__( 'Animate Out', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'zoomOut',
                    'options' => self::get_animation_style(),
                ]
            );

        $this->end_controls_section();

        do_action( 'bisy_section_slider_tab', $this , $this->get_name()); 
        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__('Slider Banner', 'bisy-essential'),
            ]
        );
      
            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'list_title', [
                    'label'       => esc_html__( 'Title', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    
                    'default'     => esc_html__( 'List Title' , 'bisy-essential' ),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'list_top_title', [
                    'label'      => esc_html__( 'Top Title', 'bisy-essential' ),
                    'type'       => \Elementor\Controls_Manager::TEXT,
                    'default'    => esc_html__( 'List Top Title' , 'bisy-essential' ),
                    'show_label' => true,
                ]
            );
            
            $repeater->add_control(
                'list_button_text', [
                    'label'       => esc_html__( 'Button Text', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    
                ]
            );

            $repeater->add_control(
                'list_button_url', [
                    'label'       => esc_html__( 'Url', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                
                ]
            );

            $repeater->add_control(
                'list_color',
                [
                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
                    ],
                ]
            );
            
            $repeater->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'list_background',
                    'label'    => esc_html__( 'Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
                ]
            );

            $repeater->add_control(
                'column',
                [
                    'label' => esc_html__( 'Column', 'oifolio-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '', 
                    'options' => [
                        '3'    => esc_html__( '3 Column', 'oifolio-essential' ),
                        '6'    => esc_html__( '6 Column', 'oifolio-essential' ),
                        '5'    => esc_html__( '5 Column', 'oifolio-essential' ),
                        '4'    => esc_html__( '4 Column', 'oifolio-essential' ),
                        '7'    => esc_html__( '7 Column', 'oifolio-essential' ),
                        '8'    => esc_html__( '8 Column', 'oifolio-essential' ),
                        '9'    => esc_html__( '9 Column', 'oifolio-essential' ),
                        '10'    => esc_html__( '10 Column', 'oifolio-essential' ),
                        '11'    => esc_html__( '11 Column', 'oifolio-essential' ),
                        '12'   => esc_html__( 'Full width', 'oifolio-essential' ),
                    
                    ],
                ]
            );

            $repeater->add_responsive_control(
                'contents_align', [
                    'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [
    
                   'left'		 => [
                      
                      'title' => esc_html__( 'Left', 'bisy-essential' ),
                      'icon'  => 'fa fa-align-left',
                   
                   ],
                    'center'	     => [
                      
                      'title' => esc_html__( 'Center', 'bisy-essential' ),
                      'icon'  => 'fa fa-align-center',
                   
                   ],
                   'right'	 => [
    
                            'title' => esc_html__( 'Right', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-right',
                      
                        ],
                    'justify'	 => [
    
                            'title' => esc_html__( 'Justified', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-justify',
                      
                        ],
                    ],
                   'default' => 'center',
                
                    'selectors' => [
                         '{{WRAPPER}} {{CURRENT_ITEM}} .slider-content' => 'text-align: {{VALUE}};',
                       
    
                    ],
                ]
            );//Responsive control end

            $this->add_control(
                'list',
                [
                    'label'       => esc_html__( 'Repeater List', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::REPEATER,
                    'fields'      => $repeater->get_controls(),
                    'title_field' => '{{{ list_title }}}',
                ]
            );

        $this->end_controls_section();
   
       
        //Top Title Style Section
        $this->start_controls_section(
            'section_top_title_style', [
                'label' => esc_html__( 'Top Title', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
        );
                $this->add_control(
                    'top_title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .top-title' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'top_title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .top-title',
                    ]
                );
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'top_title_background1',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .top-title',
                    ]
                );
                $this->add_responsive_control(
                    'top_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'top_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                   
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

        
        // button 
        $this->start_controls_section(
			'section_button1_style', [
				'label' => esc_html__( 'CTA Button', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'button_color1', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .bisylms-btn-3' => 'color: {{VALUE}};',
                            
                        ],
                    ]
                );

                $this->add_control(
                    'button_color_hv1', [

                        'label'     => esc_html__( 'Hover color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .bisylms-btn-3:hover' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho1',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .bisylms-btn-3',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding1',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .bisylms-btn-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin1',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .bisylms-btn-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading1',
                    [
                        'label' => esc_html__( 'Background color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background1',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .bisylms-btn-3',
                    ]
                );
                $this->add_control(
                    'button_background_hv_heading1',
                    [
                        'label' => esc_html__( 'Background hover color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_input_section_hv_background1',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .bisylms-btn-3:hover',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius1',
                        [
                            'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .bisylms-btn-3' => 'border-radius: {{VALUE}}px;',
                                
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border1',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .bisylms-btn-3',
                    ]
                );


        $this->end_controls_section();
   
        $this->start_controls_section('BISY_box_section',
            [
            'label' => esc_html__( 'Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
   
                $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .banner__bg,{{WRAPPER}} .banner-5-area.main-section',
                    ]
                );
            
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'slider_height',
                    [
                        'label' => esc_html__( 'Slider Height', 'bisy-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => 100,
                                'max' => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .hero-slider .bg-img' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                       
                    ]
                );

                $this->add_control(
                    'overlay_opacity',
                    [
                        'label' => esc_html__( 'Overlay Opacity', 'bisy-essential' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1,
                                'step' => 0.1,
                            ],
                          
                        ],
                        
                        'selectors' => [
                            '{{WRAPPER}} .overlay2:after' => 'opacity: {{SIZE}};',
                        ],
                       
                    ]
                );

                $this->add_control(
                    'overlay_color', [

                        'label'     => esc_html__( 'Overlay color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .overlay2:after' => 'background: {{VALUE}};',
                       
                        ],
                    ]
                );

     $this->end_controls_section();
     $this->start_controls_section('bisy_style_slider_nav',
        [
           'label' => esc_html__( 'Navigation', 'bisy-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
        
        $this->add_control(
           'nav_color',
           [
              'label'     => esc_html__('Color', 'bisy-essential'),
              'type'      => Controls_Manager::COLOR,
              'selectors' => [
                 '{{WRAPPER}} .owl-nav i' => 'color: {{VALUE}};',
               
              ],
            
           ]
        );

        $this->add_control(
         'nav_hvcolor',
         [
            'label'     => esc_html__('Hover color', 'bisy-essential'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
               '{{WRAPPER}} .owl-nav:hover i' => 'color: {{VALUE}};',
             
            ],
            
         ]
      );

         
        $this->end_controls_section(); 
    } //Register control end
 
    protected function render( ) { 

		$settings       = $this->get_settings();
		$sliders        = $settings['list'];
		$slider_enable  = $settings['slider_enable'];
		$slide_controls = bisy_widgets_slider_controls_setttings($settings);

        $slide_controls['slider_animation_in'] = $settings['slider_animation_in'];
        $slide_controls['slider_animation_out'] = $settings['slider_animation_out'];

    ?>
      
       <!-- Hero Slider Start -->
       <section class="hero-slider-section main-section">
            <div class="hero-slider <?php echo esc_attr($slider_enable == 'yes'?'owl-carousel':''); ?>" data-controls='<?php echo json_encode($slide_controls); ?>'>
                <?php foreach($sliders as $slide): ?>
                    <!-- Single Slider item  -->
                    <div class="single-slide overlay2 bg-img d-flex align-items-center elementor-repeater-item-<?php echo esc_attr($slide['_id']); ?>">
                        <div class="container">
                            <div class="row">
                                <?php 
                                $column = $slide['column']  == ''?'12':$slide['column']; 
                                
                                ?>
                                <div class="col-lg-<?php echo esc_attr($column); ?>">
                                    <div class="slider-content">
                                        <?php if( $slide[ 'list_top_title' ] !='' ): ?>
                                            <div class="sub top-title animated"> <?php echo esc_html($slide['list_top_title']); ?> </div>
                                        <?php endif; ?>
                                        <?php if( $slide[ 'list_title' ] !='' ): ?>
                                            <?php  $title = preg_replace( '|(?<!<br />)\s*\n|', "<br />\n", $slide['list_title']); ?>
                                            <h3 class="animated title">
                                                <?php echo bisy_kses($title); ?>
                                            </h3>
                                        <?php endif; ?>
                                        <?php if($slide['list_button_text']): ?>
                                           <a href="<?php echo esc_url($slide['list_button_url']); ?>" class="animated bisylms-btn-3"> <?php echo esc_html($slide['list_button_text']); ?> </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Slider item  -->
                <?php endforeach; ?>
              
              
            </div>
        </section>
        <!-- Hero Slider End -->
   
    <?php  

    }
    
    protected function _content_template() { }
}