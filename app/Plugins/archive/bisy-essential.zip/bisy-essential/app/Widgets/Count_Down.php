<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Count_Down extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-count-down';
    }

    public function get_title() {
        return esc_html__( 'Bisy Countdown ', 'bisy-essential' );
    }

    public function get_keywords() {
		return [ 'coundown', 'counter', 'count down', 'timer' ];
	}

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Timer settings', 'bisy-essential'),
            ]
        );
         
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bisy-essential' ),
					
				],
			]
        );
        
        $this->add_control(
			'day', [
				'label' => esc_html__( 'Day', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '02',
				'label_block' => true,
			]
        );
        
        $this->add_control(
			'month', [
				'label' => esc_html__( 'Month', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '05',
				'label_block' => true,
			]
        );
        
        $this->add_control(
			'year', [
				'label' => esc_html__( 'Year', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '2021',
				'label_block' => true,
			]
		);
    

        $this->add_responsive_control(
			'content_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .countdown' => 'text-align: {{VALUE}};',
              	],
			]
        );//Responsive control end
        $this->end_controls_section();
       
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .countdown .countdown-section .countdown-period' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .countdown .countdown-section .countdown-period',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                    
                        'selectors'  => [
                            '{{WRAPPER}} .countdown .countdown-section .countdown-period' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Number', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .countdown .countdown-section .countdown-amount' => 'color: {{VALUE}};',
                          
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .countdown .countdown-section .countdown-amount',
                    ]
                );

                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .countdown .countdown-section .countdown-amount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .countdown .countdown-section .countdown-amount' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('bisy_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

                $this->add_responsive_control(
                    '_item_content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .countdown .countdown-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                
                $this->add_responsive_control(
                    '_item_content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .countdown .countdown-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );   

                $this->add_responsive_control(
                    '_item__box_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%' ],
                        'selectors' => [
                            '{{WRAPPER}} .countdown .countdown-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => '_item_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .countdown .countdown-section',
                        ]
                );

        $this->end_controls_section();
        $this->start_controls_section('bisy_inner_main_section',
                [
                'label' => esc_html__( 'Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_responsive_control(
                'main_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .countdown' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            
            $this->add_responsive_control(
                'main_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .countdown' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );   

        $this->end_controls_section();
      

    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();

	    
    ?>
         

         <?php if($settings['style'] == 'style1'): ?>
           <!-- Countdown Start -->
           <div class="countdown clearfix" data-day="<?php echo esc_attr($settings['day']); ?>" data-month="<?php echo esc_attr($settings['month']); ?>" data-year="<?php echo esc_attr($settings['year']); ?>"></div>
           <!-- Countdown End -->
        <?php endif; ?>  
    <?php  

    }
    
    protected function _content_template() { }
}