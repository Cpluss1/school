<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {
  
    //
    // Create a about widget
    //
    CSF::createWidget( 'bisy_essential_about_company', array(
      'title'       => esc_html__('Bisy About Company','bisy-essential'),
      'classname'   => 'about-widget',
      'description' => esc_html__('About Company with logo','bisy-essential'),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   => esc_html__('Title','bisy-essential'),
        ),
  
  
        array(
          'id'      => 'enable_logo',
          'type'    => 'switcher',
          'title'   => esc_html__('Enable Logo','bisy-essential'),
        ),

        array(
            'id'      => 'logo',
            'type'    => 'media',
            'title'   => esc_html__('Logo','bisy-essential'),
            'library' => 'image',
        ),

        array(
            'id'      => 'company_url',
            'type'    => 'text',
            'title'   => esc_html__('Company url','bisy-essential'),
        ),
  
        array(
          'id'      => 'content',
          'type'    => 'textarea',
          'title'   => esc_html__('Content','bisy-essential'),
        ),

        array(
            'id'     => 'social_list',
            'type'   => 'repeater',
            'title'  => esc_html__('Social List','bisy-essential'),
            'fields' => array(
          
                array(
                    'id'    => 'social_icon',
                    'type'  => 'icon',
                    'title' => esc_html__('Icon','bisy-essential'),
                ),
                array(
                    'id'      => 'social_url',
                    'type'    => 'text',
                    'title'   => esc_html__('Url','bisy-essential'),
                  ),
          
            ),
          ),
          
  
      )
    ) );
     
    if( ! function_exists( 'bisy_essential_about_company' ) ) {
      function bisy_essential_about_company( $args, $instance ) {
  
        echo $args['before_widget'];
  
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }

        $class_list = ['facebook'=>'fac','twitter'=>'twi','youtube'=>'you','in'=>'lin'];
     
        ?>
           
                <?php if($instance['enable_logo']): ?>
                   <a href="<?php echo esc_url($instance['company_url']); ?>"><img src=" <?php echo esc_url($instance['logo']['url']); ?> " alt="<?php echo esc_attr(bloginfo( 'name' )); ?>"></a>
                <?php endif; ?>
                <?php if($instance['content'] !=''): ?>
                   <?php echo wpautop($instance['content']); ?>
                <?php endif; ?>
                <?php if(is_array($instance['social_list'])): ?>
                  <div class="ab-social">
                    <?php foreach($instance['social_list'] as $item): ?>
                       <?php $icon_cls = explode('-',$item['social_icon']); ?>
                       <?php $icon_cls = end($icon_cls); ?>
                      <a class="<?php echo esc_attr(isset($class_list[$icon_cls])?$class_list[$icon_cls]:$icon_cls) ?>" href="<?php echo esc_url($item['social_url']); ?>"><i class="<?php echo esc_attr($item['social_icon']); ?>"></i></a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
            

        <?php
  
        echo $args['after_widget'];
  
      }
    }
  
  }
  