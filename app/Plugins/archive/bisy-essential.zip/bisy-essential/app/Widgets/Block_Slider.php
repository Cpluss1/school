<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use BisyEssential\Base\Repository\Base_Modal;
if ( ! defined( 'ABSPATH' ) ) exit;

class Block_Slider extends Widget_Base {

  public $base;

    public function get_name() {
        return 'bisy-post-block-slider';
    }

    public function get_title() {
        return esc_html__( 'Blog Post Block ', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'fa fa-sliders';
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'bisy-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                  'title'      => esc_html__( 'Style 1', 'bisy-essential' ),
                  'imagelarge' => BISY_IMG . '/admin/blog/style-1.png',
                  'imagesmall' => BISY_IMG . '/admin/blog/style-1.png',
                  'width'      => '100%',
               ],

         
           ],

         ]
       ); 
       $this->end_controls_section();
       
      $this->start_controls_section('bisy_blockp_title_section',
        [
           'label'     => esc_html__( 'Heading', 'bisy-essential' ),
          
        ]
       );
            $this->add_control(
               'heading_title',
               [

               'label'       => esc_html__( 'Heading Title', 'bisy-essential' ),
               'type'        => Controls_Manager::TEXT,
               'default'     => esc_html__( ' {Top Slider} heading ', 'bisy-essential' ),
               'description' => esc_html__( 'Use bracket {} for top title', 'bisy-essential' ),
               
               ]
            );
          
            
       $this->end_controls_section();

   
       do_action( 'bisy_section_general_block_slider_tab', $this, $this->get_name() );
       do_action( 'bisy_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'bisy_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'bisy_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'bisy_section_sort_tab', $this , $this->get_name());  
       do_action( 'bisy_section_sticky_tab', $this , $this->get_name());  
       
        // Style
            $this->start_controls_section('bisy_style_heading_section',
            [
               'label'     => esc_html__( 'Heading', 'bisy-essential' ),
               'tab'       => Controls_Manager::TAB_STYLE,
             
            ]
            );
     
      
                  $this->add_control(
                     'block_heading_color',
                     [
                        'label'   => esc_html__('Color', 'bisy-essential'),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '',
                     
                        'selectors' => [
                           '{{WRAPPER}} .sec-title' => 'color: {{VALUE}};',
                        ],
                     ]
                  );

                 
                
                  $this->add_group_control(
                     Group_Control_Typography:: get_type(),
                     [
                        'name'     => 'post_heading_typography',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .sec-title',
                     ]
                  );

                  $this->add_control(
                     'block_heading_top_color',
                     [
                        'label'   => esc_html__('Top Title Color', 'bisy-essential'),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '',
                     
                        'selectors' => [
                           '{{WRAPPER}} .sec-title span' => 'color: {{VALUE}};',
                        ],
                     ]
                  );

                  $this->add_group_control(
                     Group_Control_Typography:: get_type(),
                     [
                        'name'     => 'post_heading_top_typography',
                        'label'    => esc_html__( 'Top Title', 'bisy-essential' ),
                     
                        'selector' => '{{WRAPPER}} .sec-title span',
                     ]
                  );


                  $this->add_responsive_control(
                  'heading_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}} .sec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
                  );
                  $this->add_responsive_control(
                     'heading_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .sec-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
                  );

                  $this->add_responsive_control(
                     'title_align', [
                         'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                         'type'    => Controls_Manager::CHOOSE,
                         'options' => [
     
                     'left'		 => [
                         
                         'title' => esc_html__( 'Left', 'bisy-essential' ),
                         'icon'  => 'fa fa-align-left',
                     
                     ],
                         'center'	     => [
                         
                         'title' => esc_html__( 'Center', 'bisy-essential' ),
                         'icon'  => 'fa fa-align-center',
                     
                     ],
                     'right'	 => [
     
                         'title' => esc_html__( 'Right', 'bisy-essential' ),
                         'icon'  => 'fa fa-align-right',
                         
                     ],
                     
                     'justify'	 => [
     
                        'title' => esc_html__( 'Justified', 'bisy-essential' ),
                        'icon'  => 'fa fa-align-justify',
                        
                             ],
                     ],
                     
                     'default' => 'center',
                     
                     'selectors' => [
                             '{{WRAPPER}} .sec-title'   => 'text-align: {{VALUE}};',
                         ],
                     ]
                 );//Responsive control end

            $this->end_controls_section();

        $this->start_controls_section('bisy_style_title_section',
            [
               'label' => esc_html__( 'Title', 'bisy-essential' ),
               'tab'   => Controls_Manager::TAB_STYLE,
            ]
         );
         
            $this->add_control(
               'block_title_color',
               [
                  'label'   => esc_html__('Color', 'bisy-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .b-post-details h3 a'   => 'color: {{VALUE}};',
                    
                  
                  ],
               ]
            );

            $this->add_control(
               'block_title_hv_color',
               [
                  'label'   => esc_html__('Hover color', 'bisy-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .b-post-details h3 a:hover'       => 'color: {{VALUE}};',
                  ],
               ]
            );

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'post_title_typography',
                  'label'    => esc_html__( 'Typography', 'bisy-essential' ),
               
                  'selector' => '{{WRAPPER}} .b-post-details h3 a',
                 
               ]
            );

            $this->add_responsive_control(
             'title_margin',
             [
                'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                   '{{WRAPPER}} .b-post-details h3'       => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                  
                ],
             ]
            );

            $this->add_responsive_control(
               'title_padding',
               [
                  'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .b-post-details h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                     
                  ],
               ]
            );

      $this->end_controls_section();

      $this->start_controls_section('bisy_style_pcontent_section',
      [
         'label'     => esc_html__( 'Post meta', 'bisy-essential' ),
         'tab'       => Controls_Manager::TAB_STYLE,
        
      ]
     );
         $this->add_control(
               'show_post_meta',
               [
                  'label'     => esc_html__('Show meta', 'bisy-essential'),
                  'type'      => Controls_Manager::SWITCHER,
                  'label_on'  => esc_html__('Yes', 'bisy-essential'),
                  'label_off' => esc_html__('No', 'bisy-essential'),
                  'default'   => 'yes',
                  
               ]
         );

         $this->add_control(
            'post_meta_color',
               [
                  'label'     => esc_html__('Author and date color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  
                  'selectors' => [
                     '{{WRAPPER}} .b-post-details .bp-meta .date' => 'color: {{VALUE}};',
                     '{{WRAPPER}} .b-post-details .bp-meta .author' => 'color: {{VALUE}};',
                     
                 
                  ],
               ]
            ); 
 
            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'      => 'meta_other_typography',
                  'label'     => esc_html__( ' Date and author Typography', 'bisy-essential' ),
            
                  'selector'  => '{{WRAPPER}} .b-post-details .bp-meta .author,{{WRAPPER}} .b-post-details .bp-meta .date',
               
               ]
         );  


         $this->add_control(
            'post_comment_color',
               [
                  'label'     => esc_html__('Comment & Category Color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [

                     '{{WRAPPER}} .b-post-details .bp-meta .comment' => 'color: {{VALUE}};',
                     '{{WRAPPER}} .b-post-details .bp-meta .cat' => 'color: {{VALUE}};',
                  ],
               ]
         ); 

         $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'meta_comment_typography',
                  'label'    => esc_html__( 'Comment Typography', 'bisy-essential' ),
               
                  'selector' => '{{WRAPPER}} .b-post-details .bp-meta .comment,{{WRAPPER}} .b-post-details .bp-meta .cat',
               
                  
               ]
         );

         $this->add_control(
            'post_icon_color',
               [
                  'label'     => esc_html__('Icon Color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .b-post-details .bp-meta i' => 'color: {{VALUE}};',
                  ],
               ]
         ); 

         $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'meta_icon_typography',
                  'label'    => esc_html__( 'Icon Typography', 'bisy-essential' ),
                
                  'selector' => '{{WRAPPER}} .b-post-details .bp-meta i',
               
                  
               ]
         );

            $this->add_responsive_control(
               'post__meta_margin',
               [
                  'label'      => esc_html__( 'Meta Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  
                  'selectors' => [
                     '{{WRAPPER}} .b-post-details .bp-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                  ],
                 
               ]
         );
 

     
     $this->end_controls_section();
 
      $this->start_controls_section('bisy_image_section',
         [
            'label' => esc_html__( 'Image ', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
      $this->add_responsive_control(
         'image_margin',
         [
            'label'      => esc_html__( ' Margin', 'bisy-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .post-item-1 img'     => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
            ],
         ]
         );

         $this->add_responsive_control(
            'box_image_height',
            [
               'label'      => esc_html__( 'Image height', 'bisy-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .post-item-1 img'     => 'height: {{SIZE}}{{UNIT}};',
            
               ],
               
            ]
         );
         
         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image width', 'bisy-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
               'selectors' => [
                  '{{WRAPPER}} .post-item-1 img'     => 'width: {{SIZE}}{{UNIT}};',
          
               ],
              
            ]
         ); 
         $this->add_responsive_control(
            'img_borders__radius',
            [
               'label'      => esc_html__( 'Image Border radius', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                  '{{WRAPPER}} .post-item-1 img'      => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
                  
               ],
            ]
         );

      $this->end_controls_section();

      $this->start_controls_section('bisy_single_box_section',
         [
            'label'     => esc_html__( 'Post box item', 'bisy-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
          
         ]
      );

         $this->add_responsive_control(
            'item_borders_radius',
            [
               'label'      => esc_html__( 'Border radius', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               
               'selectors' => [
                  
                  '{{WRAPPER}} .post-item-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                  
               ],
            ]
         );
  
         $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow:: get_type(),
            [
               'name'     => 'single_post_box_shadow',
               'label'    => esc_html__( 'Box Shadow', 'bisy-essential' ),
               'selector' => '{{WRAPPER}} .post-item-1',
            ]
         );
      
         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'single_box_background',
               'label'    => esc_html__( 'Background', 'bisy-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .post-item-1',
            ]
         );
      
        $this->add_responsive_control(
         'single_box_margin',
         [
            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .post-item-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );

         $this->add_responsive_control(
            'single_box_padding',
            [
               'label'      => esc_html__( 'Padding', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .post-item-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );
        
         $this->add_responsive_control(
            'single_box_hide_last_item',
            [
               'label'   => esc_html__( 'Hide Last Item', 'bisy-essential' ),
               'type'    => \Elementor\Controls_Manager::SELECT,
               'default' => 'block',
               'options' => [
                  'block' => esc_html__( 'Show', 'bisy-essential' ),
                  'none'  => esc_html__( 'Hide', 'bisy-essential' ),
               ],
               'selectors'  => [
                  '{{WRAPPER}} .blog-section .item:last-child' => 'display: {{VALUE}};',
               ],
            ]
         );
         
      $this->end_controls_section();

      $this->start_controls_section('bisy_box_section',
         [
            'label' => esc_html__( 'Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
   
         $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'section_background',
               'label'    => esc_html__( 'Background', 'bisy-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .main-section',
            ]
        );
        


        $this->add_responsive_control(
         'box_margin',
            [
               'label'      => esc_html__( 'Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_responsive_control(
            'box_padding',
            [
               'label'      => esc_html__( 'Padding', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
               ],
            ]
         );

         $this->add_responsive_control(
            'item_borders__radius',
            [
               'label'      => esc_html__( ' Border radius', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px'],
               'selectors'  => [
                  
                 
                  '{{WRAPPER}} .main-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
                  
               ],
          
            ]
         );

         $this->add_control(
            'enable_main_container',
            [
               'label'        => esc_html__( 'Main container', 'bisy-essential' ),
               'type'         => \Elementor\Controls_Manager::SWITCHER,
               'label_on'     => esc_html__( 'Enable', 'bisy-essential' ),
               'label_off'    => esc_html__( 'Disable', 'bisy-essential' ),
               'return_value' => 'yes',
               'default'      => 'yes',
            ]
           );

      $this->end_controls_section();

      
        $this->start_controls_section('bisy_readmore_section',
            [
                  'label'     => esc_html__( 'Readmore', 'bisy-essential' ),
                  'tab'       => Controls_Manager::TAB_STYLE,
            ]
         );

         $this->add_responsive_control(
            'readmore_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}} .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
            );

            $this->add_responsive_control(
                  'readmore_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                        '{{WRAPPER}} .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
            );

            $this->add_group_control(
                  \Elementor\Group_Control_Border:: get_type(),
                  [
                     'name'     => 'readmore_border',
                     'label'    => esc_html__( 'Border', 'bisy-essential' ),
                     'selector' => '{{WRAPPER}} .read-more',
                     
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'readmore_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .read-more',
               ]
            );
            $this->add_control(
            'readmore_color',
               [
                  'label'     => esc_html__('Color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .read-more' => 'color: {{VALUE}};',
               
                  ],
               ]
            ); 

            $this->add_group_control(
               Group_Control_Typography::get_type(),
               [
                     'name'     => 'readmore_typography',
                     'label'    => esc_html__( 'Typography', 'bisy-essential' ),
          
                     'selector' => '{{WRAPPER}} .read-more',
                     
               ]
            );

            $this->add_control(
               'readmore_icon_color',
                  [
                     'label'     => esc_html__('Icon Color', 'bisy-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} .read-more i' => 'color: {{VALUE}};',
                  
                     ],
                  ]
               ); 
   
               $this->add_group_control(
                  Group_Control_Typography::get_type(),
                  [
                        'name'     => 'readmore_icon_typography',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                     
                        'selector' => '{{WRAPPER}} .read-more i',
                        
                  ]
               );

      $this->end_controls_section();

    }
  
    protected function render( ) { 
      
        $settings = $this->get_settings();
        
        $data           = new Base_Modal($settings);
        $query          = $data->get();
        $title          = str_replace(['{','}'],['<span>','</span>'],$settings['heading_title']);
   
        if( !$query ){
          return;  
        }
       
    
     ?>
 
       <!-- Blog Start -->
       <section class="blog-section main-section">
            <?php if( $settings['enable_main_container'] =='yes'): ?>
            <div class="container">
            <?php endif; ?>
               <?php if($title !=''): ?>
                  <div class="row">
                     <div class="col-md-12">
                           <h2 class="sec-title"> <?php echo bisy_kses($title); ?> </h2>
                     </div>
                  </div>
               <?php endif; ?>
                <div class="row">
                    <?php while($query->have_posts()) : $query->the_post(); ?>
                        <div class="col-lg-4 col-md-6 item">
                              <div class="post-item-1">
                                 <?php if(has_post_thumbnail()): ?>
                                 <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_id(),'full')); ?>" alt="<?php the_title_attribute(); ?>">
                                 <?php endif; ?>
                                 <div class="b-post-details">
                                    <?php if( $settings['show_post_meta'] == 'yes' ): ?>
                                       <div class="bp-meta">

                                             <?php if($settings['show_date'] =='yes'): ?>
                                             <a class="date" href="<?php echo esc_url( get_day_link( get_the_time( 'Y' ), get_the_time( 'm' ), get_the_time( 'd' ) ) ); ?>"><i class="icon_clock_alt"></i> 
                                                <?php
                                                   $date_format = 'F d Y'; 
                                                 
                                                   if($settings['date_format'] != ''){
                                                      $date_format = bisy_custom_date_format($settings['date_format']);   
                                                   }
                                                   
                                                   if($settings['custom_date_format'] !=''){
                                                      $date_format = $settings['custom_date_format'];
                                                   }else{

                                                   }
                                                   
                                                   echo get_the_date($date_format);
                                                ?> 
                                             </a>
                                             <?php endif; ?>

                                             <?php if($settings['show_author'] =='yes'): ?>
                                             <a class="author" href="<?php echo esc_url( get_the_author_link() ); ?>"><i class="fa fa-user"></i> <?php echo get_the_author_meta( 'nicename', get_the_author_meta( 'ID' ) ); ?> </a>
                                             <?php endif; ?>

                                             <?php if($settings['show_comment'] == 'yes'): ?>
                                                <a class="comment" href="<?php echo esc_url(get_the_permalink(get_the_id())); ?>"><i class="icon_chat_alt"></i>
                                                
                                                      <?php echo get_comments_number(get_the_id()); ?>
                                                      <?php if(get_comments_number(get_the_id())>0): ?>
                                                         <?php echo esc_html__('Comments','bisy-essential'); ?>
                                                      <?php else: ?>
                                                         <?php echo esc_html__('Comment','bisy-essential'); ?>
                                                      <?php endif; ?>  
                                                
                                                </a>
                                             <?php endif; ?>

                                             <?php if($settings['show_cat'] == 'yes'): ?>

                                                <?php
                                                
                                                   $categories = get_the_category();
                                                   if ( ! empty( $categories ) ) {
                                                      echo '<a class="cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '"><i class="fas fa-folder-open"></i>' . esc_html( $categories[0]->name ) . '</a>';
                                                   }
                                                   
                                                ?>

                                             <?php endif; ?>  
                                       </div>
                                    <?php endif; ?>
                                    <h3><a href="<?php echo esc_url(get_the_permalink(get_the_id())); ?> "> <?php the_title(); ?> </a></h3>
                                    <?php if($settings['show_readmore'] == 'yes'): ?>
                                       <a class="read-more" href="<?php echo esc_url(get_the_permalink(get_the_id())); ?> "><?php echo esc_html__('Read More','bisy-essential'); ?><i class="arrow_right"></i></a>
                                    <?php endif; ?>
                                 </div>
                              </div>
                        </div>
                    <?php endwhile; ?> 
                    <?php wp_reset_postdata(); ?>
                </div>
                <?php if( $settings['enable_main_container'] =='yes' ): ?>
            </div>
           <?php endif; ?>
        </section>
        <!-- Blog End -->
  
      <?php  
    }
    

    
}