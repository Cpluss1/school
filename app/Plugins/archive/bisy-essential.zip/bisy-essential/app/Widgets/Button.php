<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;

class Button extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-button';
    }

    public function get_title() {
        return esc_html__( 'Bisy Button', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'eicon-dual-button';
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

       
        $this->start_controls_section(
            'section_button_tab',
            [
                'label' => esc_html__('Button settings', 'bisy-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label' => esc_html__( 'Style', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1'  => esc_html__( 'Style 1', 'bisy-essential' ),
                        'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
                        'style3' => esc_html__( 'Style 3', 'bisy-essential' ),
                    ],
                ]
            );

            $this->add_control(
                'button_text', [
                    'label'       => esc_html__( 'Button text', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'button_url', [
                    'label'       => esc_html__( 'Button Url', 'bisy-essential' ),
                    'type'        => Controls_Manager::URL,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'icon',
                [
                    'label' => esc_html__( 'Icon', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition'     => [ 
                        'style' => ['style1','style2'] 
                      ],
                    'default' => [
                        'value' => 'icon_loading',
                        'library' => 'solid',
                    ],
                ]
            );
            $this->add_control(
                'icon2',
                [
                    'label' => esc_html__( 'Icon', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition'     => [ 
                        'style' => ['style3'] 
                      ],
                    'default' => [
                        'value' => 'arrow_right',
                        'library' => 'solid',
                    ],
                ]
            );

            $this->add_responsive_control(
                'icon_padding2',
                [
                    'label'      => esc_html__( 'Icon Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-btn img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'title_align', [
                    'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [
    
                   'left'		 => [
                      
                      'title' => esc_html__( 'Left', 'bisy-essential' ),
                      'icon'  => 'fa fa-align-left',
                   
                   ],
                    'center'	     => [
                      
                      'title' => esc_html__( 'Center', 'bisy-essential' ),
                      'icon'  => 'fa fa-align-center',
                   
                   ],
                   'right'	 => [
    
                            'title' => esc_html__( 'Right', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-right',
                      
                        ],
                    'justify'	 => [
    
                            'title' => esc_html__( 'Justified', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-justify',
                      
                        ],
                    ],
                    'selectors' => [
                         '{{WRAPPER}} .btn-container' => 'text-align: {{VALUE}};',
    
                    ],
                ]
            );//Responsive control end
        $this->end_controls_section();
        
        $this->start_controls_section(
			'section_button_style2', [
				'label' => esc_html__( 'Button', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'fea_button_color2', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .main-btn' => 'color: {{VALUE}};',
                      
                        ],
                    ]
                );

                $this->add_control(
                    'fea_button_hv_color2', [

                        'label'     => esc_html__( 'Hover Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .main-btn:hover' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'button_content_typho2',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                     
                        'selector' => '{{WRAPPER}} .main-btn',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding2',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .main-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin2',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .main-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_control(
                    'button_background_heading2',
                    [
                        'label' => esc_html__( 'Background color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_input_section_background2',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-btn',
                    ]
                );
                $this->add_control(
                    'button_background_hv_heading2',
                    [
                        'label' => esc_html__( 'Background hover color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_input_section_hv_background2',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .main-btn:hover',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .main-btn' => 'border-radius: {{VALUE}}px;',
                              
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button2_section_border',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .main-btn',
                    ]
                );

        $this->end_controls_section();
       
       
        
        

    } //Register control end

    protected function render( ) { 

        $settings    = $this->get_settings();
        $button_url  = $settings['button_url'];
        $button_text = $settings['button_text'];
     
    ?>
        <?php if($settings['style'] == 'style1'): ?>          
            <div class="btn-container">   
                <?php  if( $settings['button_text'] !='' ): ?>
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="bisylms-btn-2 main-btn">
                        <?php echo esc_html( $settings['button_text'] ); ?>
                    </a>
                <?php endif; ?>
            </div>
       <?php endif; ?>
       
        <?php if($settings['style'] == 'style2'): ?>          
            <div class="btn-container">   
                <?php  if( $settings['button_text'] !='' ): ?>
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="bisylms-btn load-btn main-btn">
                        <?php echo esc_html( $settings['button_text'] ); ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    </a>
                   
                <?php endif; ?>
            </div>
       <?php endif; ?>

       <?php if($settings['style'] == 'style3'): ?>          
            <div class="btn-container">   
                <?php  if( $settings['button_text'] !='' ): ?>
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="read-more main-btn">
                        <?php echo esc_html( $settings['button_text'] ); ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon2'], [ 'aria-hidden' => 'true' ] ); ?>
                    </a>
                <?php endif; ?>
            </div>
       <?php endif; ?>

     
           
    <?php  

    }
    
    protected function _content_template() { }
}