<?php 

/*
* get default header footer id
* @return bool
*/
function bisy_get_default_template_id( $type= 'header' ){
    
    return false;
 
}

/*
* get default header footer id
* @return bool
*/

if( !function_exists( 'bisy_header_footer_templates') ){
   
    function bisy_header_footer_templates( $type= 'header' ){
        $list = [];
        $args = array(
            'post_type'           => 'qheader-footer',
            'orderby'             => 'id',
            'order'               => 'DESC',
            'posts_per_page'      => -1,
            'ignore_sticky_posts' => 1,
            'meta_query'          => array(
                array(
                    'key'     => '_qhf_template_type',
                    'compare' => 'LIKE',
                    'value'   => $type,
                ),
               
            ),
        );
     
        $data = get_posts($args);
        $list['--'] = esc_html__( 'None', 'bisy-essential' );
        foreach($data as $item){
           $list[$item->ID] = $item->post_title;
        }
        
        return $list;
     }

}


