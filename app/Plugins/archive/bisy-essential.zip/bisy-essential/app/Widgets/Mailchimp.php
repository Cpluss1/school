<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Custom_Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;


class Mailchimp extends Widget_Base {


    public $base;

    public function get_name() {
        return 'appscred-mailchimp';
    }

    public function get_title() {
        return esc_html__( 'MailChimp', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'fas fa-envelope-square';
    }

    public function get_categories() {
        return [ 'appscred-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Mailchimp settings', 'bisy-essential'),
            ]
        );
        
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bisy-essential' ),
					'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
				],
			]
		);

        $this->add_control(
			'icon_hide',
			[
				'label'   => esc_html__( 'Show Icon', 'bisy-essential' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'inline-block',
				'options' => [
					'inline-block' => esc_html__( 'Show', 'bisy-essential' ),
					'none'  => esc_html__( 'None', 'bisy-essential' ),
			
                ],
                'selectors' => [
                    '{{WRAPPER}} i'   => 'display:{{VALUE}};',
              
                ],
			]
		);
     
        $this->end_controls_section();

        $this->start_controls_section(
            'icon_style_section',
            [
                'label' => esc_html__( 'Icon', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'icon_button_color2', [

                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} i' => 'color: {{VALUE}};',
                
                    ],
                ]
            );

            $this->add_control(
                'icon_button_hv_color2', [

                    'label'     => esc_html__( 'Hover Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .main-btn:hover i' => 'color: {{VALUE}};',
                
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'icon_button__typho2',
                    'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .main-btn i',
                ]
            );
            $this->add_responsive_control(
                'icon_button_section_padding2',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-btn i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );
        $this->end_controls_section();
             
      

           /*---------------------------
            INPUT FIELD STYLE TAB START
        ----------------------------*/
        $this->start_controls_section(
            'ultimate_tform_input_style_section',
            [
                'label' => esc_html__( 'Input', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'input_box_tabs' );
                $this->start_controls_tab(
                    'input_box_normal_tab',
                    [
                        'label' => esc_html__( 'Normal', 'bisy-essential' ),
                    ]
                );
                    $this->add_responsive_control(
                        'input_box_height',
                        [
                            'label'      => esc_html__( 'Height', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'max' => 150,
                                ],
                            ],
                          
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'height:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]'  => 'height:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'height:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'height:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'height:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'height:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'height:{{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_width',
                        [
                            'label'      => esc_html__( 'Width', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                          
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'width:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]'  => 'width:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'width:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'width:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'width:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'width:{{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'width:{{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_box_typography',
                          
                            'selector' => '
                                {{WRAPPER}} .mc4wp-form-fields input[type*="text"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="email"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="url"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="number"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="tel"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="date"],
                                {{WRAPPER}} .mc4wp-form-fields .wpcf7-select',
                        ]
                    );
                    $this->add_control(
                        'input_box_text_color',
                        [
                            'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'color:{{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]::placeholder'  => 'color:{{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'color:{{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'color:{{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'color:{{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'color:{{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'color:{{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'input_box_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '
                                {{WRAPPER}} .mc4wp-form-fields input[type*="text"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="email"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="url"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="number"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="tel"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="date"],
                                {{WRAPPER}} .mc4wp-form-fields .wpcf7-select
                            ',
                        ]
                    );
                    $this->add_control(
                        'input_box_placeholder_color',
                        [
                            'label'     => esc_html__( 'Placeholder Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]::-webkit-input-placeholder'   => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]::-moz-placeholder'            => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]:-ms-input-placeholder'        => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]::-webkit-input-placeholder'  => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]::-moz-placeholder'           => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]:-ms-input-placeholder'       => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]::-webkit-input-placeholder'    => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]::-moz-placeholder'             => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]:-ms-input-placeholder'         => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]::-webkit-input-placeholder' => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]::-moz-placeholder'          => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]:-ms-input-placeholder'      => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]::-webkit-input-placeholder'    => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]::-moz-placeholder'             => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]:-ms-input-placeholder'         => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]::-webkit-input-placeholder'   => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]::-moz-placeholder'            => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]:-ms-input-placeholder'        => 'color: {{VALUE}};',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'                                    => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_box_border',
                            'label'    => esc_html__( 'Border', 'bisy-essential' ),
                            'selector' => '
                                {{WRAPPER}} .mc4wp-form-fields input[type*="text"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="email"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="url"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="number"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="tel"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="date"],
                                {{WRAPPER}} .mc4wp-form-fields .wpcf7-select
                            ',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_border_radius',
                        [
                            'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                            'type'      => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]'  => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_box_shadow',
                            'selector' => '
                                {{WRAPPER}} .mc4wp-form-fields input[type*="text"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="email"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="url"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="number"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="tel"],
                                {{WRAPPER}} .mc4wp-form-fields input[type*="date"],
                                {{WRAPPER}} .mc4wp-form-fields .wpcf7-select
                            ',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_control(
                        'input_box_transition',
                        [
                            'label'      => esc_html__( 'Transition', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]'   => 'transition: {{SIZE}}s;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]'  => 'transition: {{SIZE}}s;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]'    => 'transition: {{SIZE}}s;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]' => 'transition: {{SIZE}}s;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]'    => 'transition: {{SIZE}}s;',
                                '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]'   => 'transition: {{SIZE}}s;',
                                '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select'         => 'transition: {{SIZE}}s;',
                            ],
                        ]
                    );
                $this->end_controls_tab();
                $this->start_controls_tab(
                    'input_box_hover_tabs',
                    [
                        'label' => esc_html__( 'Focus', 'bisy-essential' ),
                    ]
                );
                $this->add_control(
                    'input_box_hover_color',
                    [
                        'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]:focus'   => 'color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]:focus'  => 'color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]:focus'    => 'color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]:focus' => 'color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]:focus'    => 'color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]:focus'   => 'color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select:focus'         => 'color:{{VALUE}};',
                        ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Background:: get_type(),
                    [
                        'name'     => 'input_box_hover_backkground',
                        'label'    => esc_html__( 'Focus Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '
                            {{WRAPPER}} .mc4wp-form-fields input[type*="text"]  : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="email"] : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="url"]   : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="number"]: focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="tel"]   : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="date"]  : focus,
                            {{WRAPPER}} .mc4wp-form-fields .wpcf7-select        : focus
                        ',
                    ]
                );
                $this->add_control(
                    'input_box_hover_border_color',
                    [
                        'label'     => esc_html__( 'Border Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="text"]:focus'   => 'border-color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="email"]:focus'  => 'border-color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="url"]:focus'    => 'border-color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="number"]:focus' => 'border-color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="tel"]:focus'    => 'border-color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields input[type*="date"]:focus'   => 'border-color:{{VALUE}};',
                            '{{WRAPPER}} .mc4wp-form-fields .wpcf7-select:focus'         => 'border-color:{{VALUE}};',
                        ],
                    ]
                );
                $this->add_group_control(
                    Group_Control_Box_Shadow:: get_type(),
                    [
                        'name'     => 'input_box_hover_shadow',
                        'selector' => '
                            {{WRAPPER}} .mc4wp-form-fields input[type*="text"]  : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="email"] : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="url"]   : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="number"]: focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="tel"]   : focus,
                            {{WRAPPER}} .mc4wp-form-fields input[type*="date"]  : focus,
                            {{WRAPPER}} .mc4wp-form-fields .wpcf7-select        : focus
                        ',
                    ]
                );
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();
        /*-----------------------------
            INPUT STYLE END
        -------------------------------*/

             /*----------------------------
            BUTTONS TYLE
        ------------------------------*/
        $this->start_controls_section(
            'ultimate_input_submit_style_section',
            [
                'label' => esc_html__( 'Button', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs('submit_style_tabs');
                $this->start_controls_tab(
                    'submit_style_normal_tab',
                    [
                        'label' => esc_html__( 'Normal', 'bisy-essential' ),
                    ]
                );
                    $this->add_responsive_control(
                        'input_submit_width',
                        [
                            'label'      => esc_html__( 'Width', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0,
                                    'max'  => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 200,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'width:{{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_submit_height',
                        [
                            'label'      => esc_html__( 'Height', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'max' => 150,
                                ],
                            ],
                            'default' => [
                                'size' => 55,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'input_submit_typography',
                          
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button',
                        ]
                    );
                    $this->add_control(
                        'input_submit_text_color',
                        [
                            'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'input_submit_background_color',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_submit_border',
                            'label'    => esc_html__( 'Border', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_submit_border_radius',
                        [
                            'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                            'type'      => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_submit_box_shadow',
                            'label'    => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_submit_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_responsive_control(
                        'input_submit_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' => 'before',
                        ]
                    );
                    $this->add_control(
                        'input_submit_transition',
                        [
                            'label'      => esc_html__( 'Transition', 'bisy-essential' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [
                                    'min'  => 0.1,
                                    'max'  => 3,
                                    'step' => 0.1,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => 0.3,
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'transition: {{SIZE}}s;',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'input_submit_floting',
                        [
                            'label'   => esc_html__( 'Button Floating', 'bisy-essential' ),
                            'type'    => Controls_Manager::CHOOSE,
                            'options' => [
                                'left' => [
                                    'title' => esc_html__( 'Left', 'bisy-essential' ),
                                    'icon'  => 'fa fa-align-left',
                                ],
                                'none' => [
                                    'title' => esc_html__( 'None', 'bisy-essential' ),
                                    'icon'  => 'fa fa-align-center',
                                ],
                                'right' => [
                                    'title' => esc_html__( 'Right', 'bisy-essential' ),
                                    'icon'  => 'fa fa-align-right',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button' => 'float: {{VALUE}};',
                            ],
                            'default'   => 'none',
                            'separator' => 'before',
                        ]
                    );
                $this->end_controls_tab();
                $this->start_controls_tab(
                    'submit_style_hover_tab',
                    [
                        'label' => esc_html__( 'Hover', 'bisy-essential' ),
                    ]
                );
                    $this->add_control(
                        'input_submithover_text_color',
                        [
                            'label'     => esc_html__( 'Text Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .mc4wp-form-fields button:hover' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Background:: get_type(),
                        [
                            'name'     => 'input_submithover_background_color',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button:hover',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Border:: get_type(),
                        [
                            'name'     => 'input_submithover_border',
                            'label'    => esc_html__( 'Border', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button:hover',
                        ]
                    );
                    $this->add_group_control(
                        Group_Control_Box_Shadow:: get_type(),
                        [
                            'name'     => 'input_submithover_shadow',
                            'label'    => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .mc4wp-form-fields button:hover',
                        ]
                    );
                $this->end_controls_tab();
            $this->end_controls_tabs();
        $this->end_controls_section();
        /*----------------------------
            BUTTONS TYLE END
        ------------------------------*/
        
        $this->start_controls_section('BISY_main_section_section',
                    [
                    'label' => esc_html__( 'Section', 'bisy-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                    ]
            );

                $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .main-section',
                    ]
                );

                $this->add_responsive_control(
                    'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                        ],
                    ]
                );

                $this->add_responsive_control(
                'box_padding',
                    [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                            ],
                    ]
                );

                $this->add_control(
                    'border_radius',
                        [
                                'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                                'type'  => \Elementor\Controls_Manager::NUMBER,
                                'min'   => 0,
                                'max'   => 200,
                                'step'  => 1,
                                
                                'selectors' => [
                                '{{WRAPPER}} .main-section' => 'border-radius: {{VALUE}}px;',
                        ],
                    ]
                );  

                $this->add_responsive_control(
                    'box_inner_margin',
                    [
                        'label'      => esc_html__( 'Inner Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'condition' => [ 'style' => ['style2'] ],
                        'selectors'  => [
                                '{{WRAPPER}} .performance-content .input-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                        ],
                    ]
                );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
        
        if(!shortcode_exists('mc4wp_form')){
         return;  
        }
        
        $id = get_option('mc4wp_default_form_id','');
        if($id==''){
          return;
        }
      
              
    ?>
        <?php if($settings['style'] == 'style1'): ?>
            <div class="newsletter-area">
                <div class="input-box main-section">
                    <?php echo do_shortcode("[mc4wp_form id=$id]"); ?>  
                </div>
            </div>
        <?php endif; ?>	
        <?php if($settings['style'] == 'style2'): ?>
            <div class="performance-area main-section">
                <div class="performance-content">
                    <div class="input-box">
                        <?php echo do_shortcode("[mc4wp_form id=$id]"); ?>  
                    </div>
                </div>
            </div>
        <?php endif; ?>	
   
    <?php  

    }
    
    protected function _content_template() { }
}