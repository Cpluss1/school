<?php 
/**
 * @package  bisy-essential
 */
namespace BisyEssential\Base;
use BisyEssential\Base\BaseController;

/**
* 
*/
class Enqueue extends BaseController
{
	public function register() {
		// admin
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend' ) );
	}
	
	function enqueue() {
		// enqueue all our scripts
		wp_enqueue_style( 'bisy-essential-style', $this->plugin_url . 'assets/css/backend.css' );
		wp_enqueue_script( 'bisy-essential-script', $this->plugin_url . 'assets/js/backend.js' );
		wp_register_script('upload_media_widget', $this->plugin_url . 'assets/js/upload-media.js', array('jquery'));
		
	}

	function frontend(){
		
		wp_enqueue_script( 'TweenMax', $this->plugin_url . 'assets/js/TweenMax.min.js' );
	}
}