<?php 
namespace BisyEssential\Base\Controls;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use BisyEssential\Base\BaseController;

class Sticky_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('bisy_section_sticky_tab' , array( $this, 'settings_section' ),10,2 );
	}

	public function settings_section( $ele ,$widget) 
	{
        $ele->start_controls_section(
            'section_sticky_source_tab',
            [
                'label' => esc_html__('Sticky / Features ', 'bisy-essential'),
            ]
        );
    
        
        $ele->add_control(
            'sticky_post',
            [
                'label'       => esc_html__('Show Feature post', 'bisy-essential'),
                'type'        => Controls_Manager::SWITCHER,
                'label_on'    => esc_html__('Yes', 'bisy-essential'),
                'label_off'   => esc_html__('No', 'bisy-essential'),
                'default'     => 'no',
                'description' => esc_html__('Use Sticky option to feature posts', 'bisy-essential'),
            ]
        );
   
        do_action( 'bisy_section_sticky_tab_extra_control', $ele, $widget );
        
    $ele->end_controls_section();

	}
}