<?php
/**
 * @package  Appscres-essential
 */
namespace BisyEssential\Base\Custom_Post_Type;
use BisyEssential\Api\Callbacks\Custom_Post;

class Event extends Custom_Post
{

    public $name         = 'events';
    public $menu         = 'Bisy Events';
    public $textdomain   = '';
    public $posts        = array();
    public $public_quary = false;
    public $slug         = 'bisy-events';
    public $search       = true;

	public function register() {

        $this->textdomain = 'bisy-essential';
        $this->posts      = array();
        
        add_action( 'init', array( $this, 'create_post_type' ) );
       
		
    }
    
    public function create_post_type(){

        if( !current_user_can('manage_options') ){
          return;
        }

        if( get_option('_cpt_event_name') !='' ){
            $this->name = get_option('_cpt_event_name');
        }

        if( get_option('_cpt_event_menu_name') !='' ){
            $this->menu = get_option('_cpt_event_menu_name');
        }

        if( get_option('_cpt_event_slug') !='' ){
            $this->slug = get_option('_cpt_event_slug');
        }
        
        if( get_option('_cpt_event_search') !='' ){
            $this->search = get_option('_cpt_event_search') == 'yes'?true:false;
        }
        
        if( get_option('_cpt_event_query') !='' ){
            $this->public_quary = get_option('_cpt_event_query') == 'yes'?true:false;
        }

        $this->init( 'bisy-events', $this->name, $this->menu, array( 'menu_icon' => 'dashicons-media-interactive',
            'supports'            => array( 'title','thumbnail','editor'),
            'rewrite'             => array( 'slug' => $this->slug ),
            'exclude_from_search' => $this->search,
            'has_archive'         => false,                                            // Set to false hides Archive Pages
            'publicly_queryable'  => $this->public_quary,
        ) 

       );

       $this->register_custom_post();
    }
}