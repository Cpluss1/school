<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) exit;


class Course_Category extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-course-category';
    }

    public function get_title() {
        return esc_html__( 'Bisy Course Category', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );

        $this->add_control(

         'layout', [
             'label'   => esc_html__('Choose Style', 'bisy-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                  'title'      => esc_html__( 'Style 1', 'bisy-essential' ),
                  'imagelarge' => BISY_IMG . '/admin/course/cat-2.png',
                  'imagesmall' => BISY_IMG . '/admin/course/cat-2.png',
                  'width'      => '50%',
               ],
               'style2' => [
                'title'      => esc_html__( 'Style 2', 'bisy-essential' ),
                'imagelarge' => BISY_IMG . '/admin/course/cat-1.png',
                'imagesmall' => BISY_IMG . '/admin/course/cat-1.png',
                'width'      => '100%',
             ],

         
           ],

         ]
       ); 
       $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Bisy Course Category', 'bisy-essential'),
            ]
        );

            $this->add_control(
                'title', [
                    'label'       => esc_html__( 'Title', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'Explore more' , 'bisy-essential' ),
                    'label_block' => true,
                    'condition' => [ 'layout' => ['style1'] ],
                ]
            );

            $this->add_control(
                'readmore_text', [
                    'label'       => esc_html__( 'Readmore label', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'Readmore' , 'bisy-essential' ),
                    'label_block' => true,
                    'condition' => [ 'layout' => ['style1'] ],
                ]
            );

            $this->add_control(
                'readmore_link', [
                    'label'       => esc_html__( 'Readmore link', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => '#',
                    'label_block' => true,
                    'condition' => [ 'layout' => ['style1'] ],
                ]
            );
    
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'list_cat',
			[
				'label'    => esc_html__( 'Category', 'bisy-essential' ),
				'type'     => \Elementor\Controls_Manager::SELECT2,
				'multiple' => false,
				'options'  => bisy_get_post_category('course_category'),
			
			]
		);
       
        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Icon', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				
			]
        );

        $repeater->add_control(
			'list_image',
			[
				'label' => esc_html__( 'Image ', 'bisy-essential' ),
				'description' => esc_html__( 'Image For Style 2', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				
			]
        );

        $repeater->add_control(
			'list_enable_custom_title',
			[
				'label'        => esc_html__( 'Enable Custom Title', 'bisy-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'bisy-essential' ),
				'label_off'    => esc_html__( 'Hide', 'bisy-essential' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
        );
        
		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Custom Title', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Design & Development' , 'bisy-essential' ),
                'label_block' => true,
                'condition' => [ 'list_enable_custom_title' => ['yes'] ],
			]
        );

        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Category List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
 
            $this->add_responsive_control(
                'course_cat_title_align', [
                    'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                            'title' => esc_html__( 'Right', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-right',
                    
                        ],
                    'justify'	 => [

                            'title' => esc_html__( 'Justified', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-justify',
                    
                        ],
                    ],
                'default' => 'center',
                
                    'selectors' => [
                        '{{WRAPPER}} .course-item-1' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .course-item-2' => 'text-align: {{VALUE}};',
                        

                    ],
                ]
            );//Responsive control end

        $this->end_controls_section();

        $this->start_controls_section(
			'section_heading_title_style', [
				'label' => esc_html__( 'Heading Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'layout' => ['style1'] ],
			]
        );
                $this->add_control(
                    'heading_title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .sec-title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'hading_title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .sec-title',
                    ]
                );

                $this->add_responsive_control(
                    'heading_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .sec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'hading_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .sec-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_heading_readmore_style', [
				'label' => esc_html__( 'Heading Readmore', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'layout' => ['style1'] ],
			]
        );
                $this->add_control(
                    'heading_btn_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .read-more' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'heading_btn_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .read-more',
                    ]
                );

                $this->add_responsive_control(
                    'heading_btn_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'heading_btn_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'heading_btn_icon_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .read-more i' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'heading_btn_icon_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .read-more i',
                    ]
                );

                $this->add_responsive_control(
                    'heading_readmorte_float',
                    [
                        'label' => esc_html__( 'Alignment', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => '',
                        'options' => [
                            'left'  => esc_html__( 'Left', 'bisy-essential' ),
                            'right' => esc_html__( 'Right', 'bisy-essential' ),
                            'inherit' => esc_html__( 'inherit', 'bisy-essential' ),
                       
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .read-more' => 'float: {{VALUE}};',
                        ],
                    ]
                );

        $this->end_controls_section();
       
		$this->start_controls_section(
			'section_category_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .course-item-1 h4 a' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .course-item-2 h4 a' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .course-item-1 h4 a,{{WRAPPER}} .course-item-2 h4 a',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .course-item-1 h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .course-item-2 h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .course-item-1 h4 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .course-item-2 h4 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_category_content_style', [
				'label' => esc_html__( 'Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .course-item-2 p' => 'color: {{VALUE}};',
            
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .course-item-2 p',
                    ]
                );

                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .course-item-2 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .course-item-2 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                         ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        
        $this->start_controls_section('bisy_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item box', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                      
                        '{{WRAPPER}} .course-item-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .course-item-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .course-item-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .course-item-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );   

            
            $this->add_responsive_control(
                'item__box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .course-item-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .course-item-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => '_item_section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .course-item-1,{{WRAPPER}} .course-item-2',
                    ]
                );
                              
                $this->add_control(
                    'border_popover_toggle',
                    [
                        'label' => esc_html__( 'Hover Border', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                        'label_off' => esc_html__( 'Default', 'bisy-essential' ),
                        'label_on' => __( 'Over Top Color', 'bisy-essential' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                        'condition' => [ 'layout' => ['style1'] ],
                    ]
                );

                $this->start_popover();

                    $this->add_control(
                        'item_border_top_border', [

                            'label'     => esc_html__( 'Top Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'condition' => [ 'layout' => ['style1'] ],
                            'selectors' => [
                            '{{WRAPPER}} .course-item-1:after' => 'border-top-color: {{VALUE}};',
                        
                            ],
                        ]
                    );

                    $this->add_control(
                        'item_border_bottom_border', [

                            'label'     => esc_html__( 'Bottom Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .course-item-1:after' => 'border-bottom-color: {{VALUE}};',
                        
                            ],
                        ]
                    );

                    $this->add_control(
                        'item_border_right_border', [

                            'label'     => esc_html__( 'Right Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .course-item-1:after' => 'border-right-color: {{VALUE}};',
                        
                            ],
                        ]
                    );

                    $this->add_control(
                        'item_border_left_border', [

                            'label'     => esc_html__( 'Left Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .course-item-1:after' => 'border-left-color: {{VALUE}};',
                        
                            ],
                        ]
                    );

                $this->end_popover();
                $this->add_control(
                    'border2_popover_toggle',
                    [
                        'label' => esc_html__( 'Hover Border', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                        'label_off' => esc_html__( 'Default', 'bisy-essential' ),
                        'label_on' => __( 'Over Top Color', 'bisy-essential' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                        'condition' => [ 'layout' => ['style2'] ],
                    ]
                );

                $this->start_popover();
                $this->add_control(
                    'item_border_left2_border', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .course-item-2:after' => 'box-shadow: 0px -3px 0px 0px {{VALUE}};',
                    
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'item_border_left2box_shadow',
                        'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .course-item-2:after',
                    ]
                );

                $this->end_popover();

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'item_border_top_box_shadow',
                        'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .course-item-2',
                        'condition' => [ 'layout' => ['style2'] ],
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('BISY_icon_box_inner_main_section',
                [
                'label' => esc_html__( 'Icon Box', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'layout' => ['style1'] ],
                ]
            );
                  
                    $this->add_control(
                        'icon_color', [

                            'label'     => esc_html__( 'Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .course-item-1 i' => 'color: {{VALUE}};',
                            '{{WRAPPER}} .course-item-1 svg path' => 'fill: {{VALUE}};',
                            ],
                        ]
                    );
                    
                    $this->add_group_control(
                        Group_Control_Typography:: get_type(),
                        [
                            'name'     => 'icon_typho',
                            'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                          
                            'selector' => '{{WRAPPER}} .course-item-1 i,{{WRAPPER}} .course-item-1 svg',
                        ]
                    );
              
                    $this->add_control(
                        'icon_box_outter_background_heading1',
                        [
                            'label' => esc_html__( ' Background color', 'bisy-essential' ),
                            'type' => \Elementor\Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'iconinner_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .course-item-1 svg',
                        ]
                    );
                  

                    $this->add_responsive_control(
                        'icon_box_section_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                    
                            'selectors'  => [
                                '{{WRAPPER}} .course-item-1 svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .course-item-1 img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .course-item-1 i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                               
                            ],
                            'separator' => 'before',
                        ]
                    );

                  

        $this->end_controls_section();
    

        $this->start_controls_section('BISY_main_section',
                [
                'label' => esc_html__( 'Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );

                    $this->add_control(
                        'enable_main_container',
                        [
                            'label'        => esc_html__( 'Enable main Container', 'bisy-essential' ),
                            'type'         => \Elementor\Controls_Manager::SWITCHER,
                            'label_on'     => esc_html__( 'Show', 'bisy-essential' ),
                            'label_off'    => esc_html__( 'Hide', 'bisy-essential' ),
                            'return_value' => 'yes',
                            'default'      => 'no',
                        ]
                    );
                     
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

        $settings      = $this->get_settings();
        $list          = $settings['list'];
        $title         = $settings['title'];
        $readmore_text = $settings['readmore_text'];
        $readmore_link = $settings['readmore_link'];
        $title_1       = str_replace(['{', '}'], ['<span>', '</span>'], $title);
         
    ?>
        <?php if($settings['layout'] == 'style1'): ?>    
            <!-- Course Start -->
            <?php if( $settings['enable_main_container'] =='yes' ): ?>
            <section class="popular-course-section">
                <div class="container">
            <?php endif; ?>
                <?php if($readmore_text !='' || $title_1 !=''): ?>
                        <div class="row">
                            <?php if($title_1 !=''): ?>
                                <div class="col-md-8">
                                    <h2 class="sec-title"><?php echo bisy_kses($title_1); ?></h2>
                                </div>
                            <?php endif; ?>
                            <?php if($readmore_text !=''): ?>
                                <div class="col-md-4">
                                    <a class="read-more" href="<?php echo esc_url($readmore_link); ?>"> <?php echo esc_html($readmore_text); ?> <i class="arrow_right"></i></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="course-wrapper main-section">
                            <?php foreach($list as $item): ?>
                                    <?php if($item['list_cat'] !=''): ?>
                                            <div class="course-item-1 text-center">
                                                <?php
                                                    $category    = get_term_by('id', $item['list_cat'], 'course_category');
                                                ?>
                                                <?php if($item['list_image']['url'] ==''): ?> 
                                                <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                                <?php else: ?>
                                                    <img src="<?php echo esc_url($item['list_image']['url']); ?>" alt="<?php echo esc_html($item['list_title']); ?>">
                                                <?php endif; ?>
                                                <?php if($item['list_enable_custom_title'] == 'yes'): ?>
                                                    <h4><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($item['list_title']); ?> </a></h4>
                                                <?php else: ?>
                                                    <h4><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($category->name); ?> </a></h4>
                                                <?php endif; ?>
                                            </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php if( $settings['enable_main_container'] =='yes' ): ?>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?> 
        <!-- Course End -->
        <?php if( $settings['layout'] == 'style2' ): ?>   
            <!-- Course Start -->
            <?php if( $settings['enable_main_container'] =='yes' ): ?>
                <section class="popular-course-section-2 main-section">
                    <div class="container">
                    <?php endif; ?>   
                        <div class="row">
                        <?php foreach($list as $item): ?>
                                <?php
                                    $category    = get_term_by('id', $item['list_cat'], 'course_category');
                                ?>
                                <?php if($item['list_cat'] !=''): ?>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="course-item-2">
                                            <?php if( $item['list_image']['url'] !='' ): ?>
                                                <div class="course-thumb">
                                                    <?php if($item['list_image']['url'] ==''): ?> 
                                                        <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                                    <?php else: ?>
                                                        <img src="<?php echo esc_url($item['list_image']['url']); ?>" alt="<?php echo esc_html($item['list_title']); ?>">
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($item['list_enable_custom_title'] == 'yes'): ?>
                                                <h4><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($item['list_title']); ?> </a></h4>
                                            <?php else: ?>
                                                <h4><a href="<?php echo esc_url(get_category_link($item['list_cat'])); ?>"> <?php echo esc_html($category->name); ?> </a></h4>
                                            <?php endif; ?>
                                            <p> <?php echo sprintf( _n( 'Over %s Course', 'Over %s Courses', $category->count, 'bisy-essential' ),$category->count ); ?></p>

                                        </div>
                                    </div>
                                <?php endif; ?>
                        <?php endforeach; ?>
                        </div>
                    
            <?php if( $settings['enable_main_container'] == 'yes' ): ?>
                    </div>
                </section>
        <?php endif; ?>   
        <!-- Course End -->
        <?php endif; ?>  
    <?php  

    }
    
    protected function _content_template() { }
}