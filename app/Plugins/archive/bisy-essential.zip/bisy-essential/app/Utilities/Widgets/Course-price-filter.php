<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {
  
    //
    // Create a course price widget
    //
    CSF::createWidget( 'bisy_essential_course_price_filter', array(
      'title'       => esc_html__('Bisy Course Price Filter','bisy-essential'),
      'classname'   => 'about-widget',
      'description' => esc_html__('Bisy Course Price Filter','bisy-essential'),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   => esc_html__('Title','bisy-essential'),
        ),
  
      )
    ) );
     
    if( ! function_exists( 'bisy_essential_course_price_filter' ) ) {
      function bisy_essential_course_price_filter( $args, $instance ) {
       
        echo $args['before_widget'];
       
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        

        ?>
           
          
           <form action="<?php echo esc_url($_SERVER['REQUEST_URI']) ?>" method="get" class="clearfix">
                <div class="price-filter">
                    <ul>
                        <li>
                            <input type="radio" checked="checked" id="all" name="course-price-filter" value="all">
                            <label for="all">
                                <?php echo esc_html__('All','bisy-essential'); ?>
                            </label>
                        </li>
                        <li>
                            <input type="radio" id="premium" name="course-price-filter" value="premium">
                            <label for="premium">
                                <?php echo esc_html__(' Premium Courses','bisy-essential'); ?>
                            </label>
                        </li>
                        <li>
                            <input type="radio" id="free" name="course-price-filter" value="free">
                            <label for="free">
                                <?php echo esc_html__('Free Courses','bisy-essential'); ?>
                            </label>
                        </li>
                    </ul>
                    <button type="submit"> <?php echo esc_html__('Filter Results','bisy-essential'); ?></button>
                </div>
            </form>
            

        <?php
  
        echo $args['after_widget'];
  
      }
    }
  
  }
  