<?php 
namespace BisyEssential\Base\Controls\Slider;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use BisyEssential\Base\BaseController;

class Generel_Block_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('bisy_section_general_block_slider_tab' , array( $this, 'settings_section' ), 10, 2 );
		
	}
    public function not_allowed_control($control,$widget){
       
        $widget_list = [
           'bisy-post-slider' =>
                 ['show_view_count']
       ];
        try{
            if(isset($widget_list[$widget])){

                $the_widget = $widget_list[$widget];
                if( in_array($control,$the_widget) ){
                  return false;
                }else{
                    return true;
                }
            }
           
            return true;
        }catch (Exception $e) {
            return true;
        }
        return true;
    }
	public function settings_section( $ele,$widget ) 
	{
            
           $ele->start_controls_section(
            'section_general_tab',
                [
                    'label' => esc_html__('General', 'bisy-essential'),
                ]
            );

                $ele->add_control(
                'post_count',
                    [
                        'label'         => esc_html__( 'Load Posts', 'bisy-essential' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '3',
                    ]
                );
       
                $ele->add_control(
                'post_title_crop',
                    [
                        'label'         => esc_html__( 'Post title crop', 'bisy-essential' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '8',
                        
                    ]
                );
                // uncommon  
                    if(!in_array($widget,['bisy-post-block-slider'])){

                        $ele->add_control(
                            'show_content',
                            [
                                'label'     => esc_html__('Show content', 'bisy-essential'),
                                'type'      => Controls_Manager::SWITCHER,
                                'label_on'  => esc_html__('Yes', 'bisy-essential'),
                                'label_off' => esc_html__('No', 'bisy-essential'),
                                'default'   => 'yes',
                               
                            ]
                        );

                        $ele->add_control(
                            'post_content_crop',
                                [
                                    'label'         => esc_html__( 'Post content crop', 'bisy-essential' ),
                                    'type'          => Controls_Manager::NUMBER,
                                    'default'       => '18',
                                  
                                ]
                        );

                    }
                   
               
                    $ele->add_control(
                        'show_date',
                        [
                            'label'     => esc_html__('Show Date', 'bisy-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'bisy-essential'),
                            'label_off' => esc_html__('No', 'bisy-essential'),
                            'default'   => 'yes',
                          
                        ]
                    );
               

               
                    $ele->add_control(
                        'show_cat',
                        [
                            'label'     => esc_html__('Show Category', 'bisy-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'bisy-essential'),
                            'label_off' => esc_html__('No', 'bisy-essential'),
                            'default'   => '',
                           
                        ]
                    );

                    $ele->add_control(
                        'show_comment',
                        [
                            'label'     => esc_html__('Show Comment', 'bisy-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'bisy-essential'),
                            'label_off' => esc_html__('No', 'bisy-essential'),
                            'default'   => 'yes',
                           
                        ]
                    );
             
         
                    $ele->add_control(
                        'show_author',
                        [
                            'label'     => esc_html__('Show Author', 'bisy-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'bisy-essential'),
                            'label_off' => esc_html__('No', 'bisy-essential'),
                            'default'   => '',
                           
                        ]
                    );

                    $ele->add_control(
                        'show_readmore',
                        [
                            'label'     => esc_html__('Show ReadMore', 'bisy-essential'),
                            'type'      => Controls_Manager::SWITCHER,
                            'label_on'  => esc_html__('Yes', 'bisy-essential'),
                            'label_off' => esc_html__('No', 'bisy-essential'),
                            'default'   => 'yes',
                           
                        ]
                    );

                    if($widget == 'bisy-post-block-slider'){

                        $ele->add_control(
                            'date_format',
                            [
                                'label' => esc_html__( 'Date Format', 'bisy-essential' ),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'default' => '',
                                'options' => bisy_custom_date_format()
                            ]
                        );
            
                        $ele->add_control(
                            'custom_date_format',
                            [
             
                                'label'       => esc_html__( 'Custom Date ','bisy-essential' ),
                                'type'        => Controls_Manager::TEXT,
                                'default'        => 'M d, Y',
                                'condition'     => [ 
                                    'date_format' => ['0'] 
                                  ], 
                            
                            ]
                         );
                    }
            
              
                
            $ele->end_controls_section();	
    }
    
   
}