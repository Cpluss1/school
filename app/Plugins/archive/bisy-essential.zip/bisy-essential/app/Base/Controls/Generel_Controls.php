<?php 
namespace BisyEssential\Base\Controls;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use BisyEssential\Base\BaseController;

class Generel_Controls extends BaseController
{
	public function register() 
	{
	
		add_action('bisy_section_general_tab' , array( $this, 'settings_section' ), 10, 2 );
		add_action('bisy_section_general_tab_extra_control' , array( $this, 'settings_section_extra' ),13, 2 );
	}
   
	public function settings_section( $ele,$widget ) 
	{
         
            $course = [ 'bisy-course-block' ];
            

           $ele->start_controls_section(
            'section_general_tab',
                [
                    'label' => esc_html__('General', 'bisy-essential'),
                ]
            );
            
                $ele->add_control(
                'post_count',
                    [
                        'label'         => esc_html__( 'Post count', 'bisy-essential' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '8',
                    ]
                );
               
                $ele->add_control(
                'post_title_crop',
                    [
                        'label'         => esc_html__( 'Post title crop', 'bisy-essential' ),
                        'type'          => Controls_Manager::NUMBER,
                        'default'       => '8',
                    ]
                );
                // uncommon  
                     if( !in_array($widget, $course )){  
                        $ele->add_control(
                            'show_content',
                            [
                                'label'     => esc_html__('Show content', 'bisy-essential'),
                                'type'      => Controls_Manager::SWITCHER,
                                'label_on'  => esc_html__('Yes', 'bisy-essential'),
                                'label_off' => esc_html__('No', 'bisy-essential'),
                                'default'   => 'yes',
                            ]
                        );
                    }

                    if( !in_array($widget, $course )){  
                        $ele->add_control(
                            'post_content_crop',
                                [
                                    'label'         => esc_html__( 'Post content crop', 'bisy-essential' ),
                                    'type'          => Controls_Manager::NUMBER,
                                    'default'       => '18',
                                ]
                        );
                    }
              
                    if( !in_array($widget, $course )){
                        $ele->add_control(
                            'show_date',
                            [
                                'label'     => esc_html__('Show Date', 'bisy-essential'),
                                'type'      => Controls_Manager::SWITCHER,
                                'label_on'  => esc_html__('Yes', 'bisy-essential'),
                                'label_off' => esc_html__('No', 'bisy-essential'),
                                'default'   => 'yes',
                            ]
                        );
                    }
               
                        if( !in_array($widget, $course )){
                
                            $ele->add_control(
                                'show_cat',
                                [
                                    'label'     => esc_html__('Show Category', 'bisy-essential'),
                                    'type'      => Controls_Manager::SWITCHER,
                                    'label_on'  => esc_html__('Yes', 'bisy-essential'),
                                    'label_off' => esc_html__('No', 'bisy-essential'),
                                    'default'   => 'yes',
                                ]
                            );
                        }
               
                        if( !in_array($widget, $course )){
                            $ele->add_control(
                                'show_author',
                                [
                                    'label'     => esc_html__('Show Author', 'bisy-essential'),
                                    'type'      => Controls_Manager::SWITCHER,
                                    'label_on'  => esc_html__('Yes', 'bisy-essential'),
                                    'label_off' => esc_html__('No', 'bisy-essential'),
                                    'default'   => '',
                                ]
                            );
                        }
               
                   
                        $ele->add_control(
                            'show_readmore',
                            [
                                'label'     => esc_html__('Show Readmore', 'bisy-essential'),
                                'type'      => Controls_Manager::SWITCHER,
                                'label_on'  => esc_html__('Yes', 'bisy-essential'),
                                'label_off' => esc_html__('No', 'bisy-essential'),
                                'default'   => 'yes',
                            ]
                        );
                
                  
                        $ele->add_control(
                            'readmore_text',
                                [
                                    'label'         => esc_html__( 'Readmore Label', 'bisy-essential' ),
                                    'type'          => Controls_Manager::TEXT,
                                    'default'       => esc_html__( 'more details', 'bisy-essential' ),
                                ]
                        );
             
                       
            
                      
                do_action( 'bisy_section_general_tab_extra_control', $ele, $widget );
            $ele->end_controls_section();	
    }
    
    public function settings_section_extra($ele, $widget ){

        
    }
}