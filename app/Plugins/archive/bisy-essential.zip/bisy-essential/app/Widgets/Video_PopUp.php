<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Video_PopUp extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-video-popup';
    }

    public function get_title() {
        return esc_html__( 'Video PopUp', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-video-camera";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }
    public function layout(){
        return[
            
            'style1' => esc_html__( 'Style 1', 'bisy-essential' ),
            'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
       
      
        ];
    }
    protected function _register_controls() {
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );
            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Style', 'bisy-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
        $this->end_controls_section();
     
      
        $this->start_controls_section(
            'section_video_tab',
            [
                'label' => esc_html__('Video settings', 'bisy-essential'),
            ]
        );

            $this->add_control(
                'video_url', [
                    'label'       => esc_html__( 'Video Url', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Video url here', 'bisy-essential' ),
                    'default'     => 'https://www.youtube.com/watch?v=WXW7ztYNlWg',
                ]
            );

            $this->add_control(
                'icon',
                [
                    'label' => esc_html__( 'Icon', 'bisy-essential' ),
                    'type'  => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'fas fa-play',
                        'library' => 'solid',
                    ],
                ]
            );
            
            $this->add_control(
                'column',
                [
                    'label' => esc_html__( 'Column', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => '10', 
                    'options' => [
                        '6'    => esc_html__( '6 Column', 'bisy-essential' ),
                        '4'    => esc_html__( '4 Column', 'bisy-essential' ),
                        '10'    => esc_html__( '10 Column', 'bisy-essential' ),
                        '12'   => esc_html__( 'Full width', 'bisy-essential' ),
                    
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name' => 'inner_shape_content_background',
                        'label' => esc_html__( 'Background', 'bisy-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .video-banner',
                 
                    ]
            );

          
            
        $this->end_controls_section();
  
        $this->start_controls_section('bisy_shape__inner_main_section',
            [
            'label' => esc_html__( 'Shape ', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'video__shape_heading',
            [
               'label'     => esc_html__( 'Shape Background', 'bisy-essential' ),
               'type'      => \Elementor\Controls_Manager::HEADING,
               'separator' => 'before',
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
                [
                    'name' => 'video__shape_content_background',
                    'label' => esc_html__( 'Background', 'bisy-essential' ),
                    'types' => [ 'classic', 'gradient','video' ],
                    'selector' => '{{WRAPPER}} .video-banner:after',
             
                ]
        );

        $this->add_responsive_control(
            'shape_background_image_top',
            [
                'label' => esc_html__( 'Shape Top', 'bisy-essential' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -500,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .video-banner:after' => 'top: {{SIZE}}{{UNIT}};',
                ],
               
            ]
        );

        $this->add_responsive_control(
            'shape_background_image_left',
            [
                'label' => esc_html__( 'Shape left', 'bisy-essential' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -500,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .video-banner:after' => 'left: {{SIZE}}{{UNIT}};',
                ],
               
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section('bisy_icon_inner_main_section',
            [
            'label' => esc_html__( 'Video Icon', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
                $this->add_control( 
                    'video_icon_color', [

                        'label'     => esc_html__( 'Icon Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .popup-video i' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );

                $this->add_control( 
                    'video_icon_hover_color', [

                        'label'     => esc_html__( 'Icon Hover Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .popup-video:hover i' => 'color: {{VALUE}};',
                        
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'video_icon_typho',
                        'label'    => esc_html__( 'Icon Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .popup-video i',
                    ]
                );

                $this->add_responsive_control(
                    'video_icon_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .popup-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name' => 'video_icon_gradient_background',
                            'label' => esc_html__( 'Background', 'bisy-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .popup-video',
                        ]
                );

                $this->add_control(
                    'video_section_border_radius2',
                        [
                            'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .popup-video' => 'border-radius: {{VALUE}}px;',
                           ],
                    ]
                ); 

                $this->add_control(
                    'video_icon_c_heading',
                    [
                       'label'     => esc_html__( 'Icon Hover Background', 'bisy-essential' ),
                       'type'      => \Elementor\Controls_Manager::HEADING,
                       'separator' => 'before',
                    ]
                 );

                 $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name' => 'video_icon_hover_gradient_background',
                            'label' => esc_html__( 'Background', 'bisy-essential' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .popup-video:hover',
                        ]
                );
        

        $this->end_controls_section();
          
        $this->start_controls_section('bisy_box__main_section',
                [
                'label' => esc_html__( 'Main Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );
      
            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name' => '_shape_content_background',
                        'label' => esc_html__( 'Background', 'bisy-essential' ),
                        'types' => [ 'classic', 'gradient','video' ],
                        'selector' => '{{WRAPPER}} .video-section',
                 
                    ]
            );
        $this->end_controls_section();

        $this->start_controls_section('bisy_box_inner_main_section',
                [
                'label' => esc_html__( 'Inner Box', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

            $this->add_responsive_control(
                'inner_box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-banner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'inner_box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .video-banner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                    ],
                    'separator' => 'before',
                ]
            );
      
            $this->add_control(
                'inner_section_border_radius2',
                    [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 500,
                        'step'  => 1,
                        
                        'selectors' => [
                            '{{WRAPPER}} .video-banner' => 'border-radius: {{VALUE}}px;',
                          
                    ],
                ]
            ); 

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'inner_section_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .video-banner',
                ]
            );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		
       
    ?>
       
      
       <?php if($settings['style'] == 'style1'): ?>  

                <!-- Video Start -->
                <section class="video-section">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-<?php echo esc_attr($settings['column']); ?> text-center">
                                <div class="video-banner">
                                    <a class="popup-video" href="<?php echo esc_url($settings['video_url']); ?>" data-rel="lightcase"><i class="fas fa-play"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Video End -->

       <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
}