<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit;

class Intro_Banner extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-intro-banner';
    }

    public function get_title() {
        return esc_html__( 'Intro Banner', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fab fa-adversal";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {
 
        $this->start_controls_section(
            'section_layout_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );
            $this->add_control(
                'layout',
                [
                    'label'   => esc_html__( 'Layout Style', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1' => esc_html__( 'Style 1', 'bisy-essential' ),
                        'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
             
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_tab',
            [
                'label' => esc_html__('Intro Banner Content', 'bisy-essential'),
            ]
        );
       
                
                
                $this->add_control(
                    'top_title', [
                        'label'       => esc_html__( 'Top Title', 'bisy-essential' ),
                        'type'        => Controls_Manager::TEXTAREA,
                        'label_block' => true,
                        'placeholder' => esc_html__( 'Becoming A Dvd Expert Online', 'bisy-essential' ),
                        'default'     => esc_html__( 'Becoming A Dvd Expert Online', 'bisy-essential' ),
                        'condition' => [ 'layout' => ['style2'] ],
                        
                    ]
                );

                $this->add_control(
                    'title', [
                        'label'       => esc_html__( 'Title', 'bisy-essential' ),
                        'type'        => Controls_Manager::TEXTAREA,
                        'label_block' => true,
                        'placeholder' => esc_html__( 'Becoming A Dvd Repair Expert Online', 'bisy-essential' ),
                        'default'     => esc_html__( 'Becoming A Dvd Repair Expert Online', 'bisy-essential' ),
                        
                    ]
                );

                $this->add_control(
                    'sub_title', [
                        'label'       => esc_html__( 'Sub Title', 'bisy-essential' ),
                        'type'        => Controls_Manager::TEXTAREA,
                        'label_block' => true,
                        'placeholder' => esc_html__( 'Sub content here', 'bisy-essential' ),
                        'default'     => esc_html__( 'Finding the perfect learning tool for Flash is a daunting task to any novice web developer. One can find help in a number of ways through books, friends and private tutors', 'bisy-essential' ),
                    ]
                );


                $this->add_control(
                    'thumb',
                    [
                        'label' => esc_html__( 'Choose thumb', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::MEDIA,
                    ]
                );

                $this->add_control(
                    'top_background_heading1',
                    [
                        'label' => esc_html__( 'Background', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                );

                $this->add_control(
                    'bottom_background_heading1',
                    [
                        'label' => esc_html__( 'Bottom Background', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                        'condition' => [ 'layout' => ['style1'] ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'     => 'botom_section_background',
                            'label'    => esc_html__( 'Bottom Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .hero-banner-1::after',
                            'condition' => [ 'layout' => ['style1'] ],
                        ]
                );

     
        $this->end_controls_section();
        $this->start_controls_section(
            'section_feature_tab',
            [
                'label' => esc_html__('Feature List', 'bisy-essential'),
                'condition' => [ 'layout' => ['style2','style3','style4'] ],
            ]
        );

            $feature = new \Elementor\Repeater();

          
            $feature->add_control(
                'list_title', [
                    'label'       => esc_html__( 'Title', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'List Title' , 'bisy-essential' ),
                    'label_block' => true,
                ]
            );

            $feature->add_control(
                'icon',
                [
                    'label' => esc_html__( 'Icon', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'icon_check_alt2',
                        'library' => 'solid',
                    ],
                ]
            );

            $feature->add_control(
                'list_color',
                [
                    'label' => esc_html__( 'Color', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
                    ],
                ]
            );
            
            $this->add_control(
                'feature_list',
                [
                    'label'     => esc_html__( 'Feature List', 'bisy-essential' ),
                    'type'      => \Elementor\Controls_Manager::REPEATER,
                    'fields'    => $feature->get_controls(),
                    'title_field' => '{{{ list_title }}}',
                ]
            );


        $this->end_controls_section();
        $this->start_controls_section(
            'section_button_tab',
            [
                'label' => esc_html__('Button', 'bisy-essential'),
                'condition' => [ 'layout' => ['style1','style2','style3','style4'] ],
            ]
        );
        
                $this->add_control(
                    'button_text', [
                        'label'       => esc_html__( 'Button Text', 'bisy-essential' ),
                        'type'        => Controls_Manager::TEXT,
                        'label_block' => true,
                        
                    ]
                );

                $this->add_control(
                    'button_url', [
                        'label'       => esc_html__( 'Url', 'bisy-essential' ),
                        'type'        => Controls_Manager::TEXT,
                        'label_block' => true,
                       
                    ]
                );

            

        $this->end_controls_section();

       
        $this->start_controls_section(
            'section_shape_image_list_tab',
            [
                'label' => esc_html__('Shape images', 'bisy-essential'),
               
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'shape',
            [
                'label' => esc_html__( 'Choose shape', 'bisy-essential' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );
		
        $repeater->add_control(
			'list_title', [
				'label'       => esc_html__( 'Title', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'List Title' , 'bisy-essential' ),
				'label_block' => true,
			]
        );
        
		$this->add_control(
			'shape_list',
			[
				'label'     => esc_html__( 'Shape List', 'bisy-essential' ),
				'type'      => \Elementor\Controls_Manager::REPEATER,
				'fields'    => $repeater->get_controls(),
				'title_field' => '{{{ list_title }}}',
			]
		);


        $this->end_controls_section();

        $this->start_controls_section(
			'section_top_title_style', [
				'label' => esc_html__( 'Top Title', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'layout' => ['style2'] ],
          	]
        );
                $this->add_control(
                    'top_title_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-content .sub-heading' => 'color: {{VALUE}};',
                   
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'top_title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                       
                        'selector' => '{{WRAPPER}} .hero-content .sub-heading',
                    ]
                );

                $this->add_responsive_control(
                    'top_title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content .sub-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'top_title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content .sub-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

       
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-content h2' => 'color: {{VALUE}};',
                   
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                       
                        'selector' => '{{WRAPPER}} .hero-content h2',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
        $this->end_controls_section();

         //Sub Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .hero-content p' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                     
                        'selector' => '{{WRAPPER}} .hero-content p',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_feature_list_style', [
				'label' => esc_html__( 'Feature List', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'layout' => ['style2','style3','style4'] ],
			]
        );

                $this->add_responsive_control(
                    'feature_section_item_margin',
                    [
                        'label'      => esc_html__( 'Single Item Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'feature_section_item_icon_margin',
                    [
                        'label'      => esc_html__( 'Single Item Icon Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content ul li i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'feature_item_icon_typho1',
                        'label'    => esc_html__( 'Icon Typography', 'bisy-essential' ),
                       
                        'selector' => '{{WRAPPER}} .hero-content ul li i',
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'feature_item_typho1',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                       
                        'selector' => '{{WRAPPER}} .hero-content ul li',
                    ]
                );

                $this->add_responsive_control(
                    'feature_section_padding1',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'feature_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        ],
                        'separator' => 'before',
                    ]
                );

      

        $this->end_controls_section();
        
        // button 
        $this->start_controls_section(
			'section_button1_style', [
				'label' => esc_html__( 'Button 1', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [ 'layout' => ['style1','style2','style3','style4'] ],
			]
        );
                $this->add_control(
                    'button_color1', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .hero-content a' => 'color: {{VALUE}};',
                            
                        ],
                    ]
                );

                $this->add_control(
                    'button_color_hv1', [

                        'label'     => esc_html__( 'Hover color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .hero-content a:hover' => 'color: {{VALUE}};',
                           
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typho1',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                   
                        'selector' => '{{WRAPPER}} .hero-content a',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_padding1',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin1',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .hero-content a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_control(
                    'button_background_heading1',
                    [
                        'label' => esc_html__( 'Background color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
        
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_inp_section_background1',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .hero-content a',
                    ]
                );
                $this->add_control(
                    'button_background_hv_heading1',
                    [
                        'label' => esc_html__( 'Background hover color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'name'     => 'button_input_section_hv_background1',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .hero-content a:hover',
                    ]
                );

                $this->add_control(
                    'button_section_border_radius1',
                        [
                            'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                            'type'  => \Elementor\Controls_Manager::NUMBER,
                            'min'   => 0,
                            'max'   => 200,
                            'step'  => 1,
                            
                            'selectors' => [
                                '{{WRAPPER}} .hero-content a' => 'border-radius: {{VALUE}}px;',
                                
                               
                        ],
                    ]
                ); 

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'button1_section_border1',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .hero-content a',
                    ]
                );


        $this->end_controls_section();


        $this->start_controls_section('section_media__section',
            [
            'label' => esc_html__( 'Media', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
		$this->add_responsive_control(
			'image_top_pos',
			[
				'label' => esc_html__( 'Top Position', 'bisy-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
                ],
              
				
				'selectors' => [
					'{{WRAPPER}} .banner-thumb' => 'top: {{SIZE}}{{UNIT}};',
			
				],
			]
        );

        $this->add_responsive_control(
			'image_left_pos',
			[
				'label' => esc_html__( 'Left Position', 'bisy-essential' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => -500,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
                ],
              
				
				'selectors' => [
					'{{WRAPPER}} .banner-thumb' => 'left: {{SIZE}}{{UNIT}};',
				
				],
			]
        );
        

        $this->end_controls_section();

        $this->start_controls_section('bisy_box_section',
            [
            'label' => esc_html__( 'Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
      
                $this->add_responsive_control(
                'box_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );

                $this->add_responsive_control(
                   'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                    ]
                );
    
                
            $this->add_responsive_control(
                'box__height',
                [
                    'label'      => esc_html__( 'Height', 'bisy-essential' ),
                    'type'       => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px','%' ],
                    'range'      => [
                        'px' => [
                            'min'  => 0,
                            'max'  => 1200,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    
                    ],
                   
                    'selectors' => [
                        '{{WRAPPER}} .main-section' => 'height: {{VALUE}}{{UNIT}};',
                   ],
                    
                ]
            );

     $this->end_controls_section();
    
      
    } //Register control end
   
    protected function render( ) {

		$settings    = $this->get_settings();
		$title       = $settings['title'];
		$sub_title   = $settings['sub_title'];
		$button_url  = $settings['button_url'];
		$button_text = $settings['button_text'];
		$thumb       = $settings['thumb'];

		$title_1    = str_replace(['{', '}'], ['<span>', '</span>'], $title);
        $shape_list = $settings['shape_list'];
        $feature_list = $settings['feature_list'];
        
        
    ?>
       <?php if($settings['layout'] == 'style1'): ?>
            <!-- Hero Banner Start -->
            <section class="hero-banner-1 main-section">
                <?php if(is_array($shape_list) && count($shape_list)): ?>
                    <!-- shape -->
                    <div class="shape-wrap">
                        <?php foreach($shape_list as $key => $image): ?>
                            <div class="b-shape-<?php echo esc_attr(++$key); ?>">
                                <img src="<?php echo esc_url($image['shape']['url']); ?>" alt="<?php echo esc_attr($image['list_title']); ?>">
                            </div>
                            <?php
                                if($key == 4){
                                    break; 
                                } 
                            ?> 
                        <?php endforeach; ?>
                    </div>
                    <!-- shape -->
                <?php endif; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5 col-md-5">
                            <div class="hero-content">
                                <?php if( $settings['title'] !='' ): ?>
                                    <h2> <?php echo esc_html( $settings['title'] ); ?> </h2>
                                <?php endif; ?>
                                <?php if( $settings['sub_title'] !='' ): ?>
                                    <p>
                                        <?php echo esc_html( $settings['sub_title'] ); ?>
                                    </p>
                                <?php endif; ?>
                                <?php if( $settings['button_text'] !=''): ?>
                                    <a href="<?php echo esc_url($settings['button_url']); ?>" class="bisylms-btn"> <?php echo esc_html($settings['button_text']); ?> </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if( isset($thumb['url']) && $thumb['url'] !='' ): ?>
                            <div class="col-lg-7 col-md-7">
                                <div class="banner-thumb">
                                    <img src="<?php echo esc_url($thumb['url']); ?>" alt="<?php echo esc_attr($settings['sub_title']); ?>">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>  
            <!-- Banner End -->  
        <?php endif; ?>
        <?php if($settings['layout'] == 'style2'): ?>
              <!-- Hero Banner Start -->
                <section class="hero-banner-2 main-section">
                    <?php if(is_array($shape_list) && count($shape_list)): ?>
                        <!-- shape -->
                        <div class="shape-wrap">
                            <?php foreach($shape_list as $key => $image): ?>
                                <div class="b-shape-<?php echo esc_attr(++$key); ?>">
                                    <img src="<?php echo esc_url($image['shape']['url']); ?>" alt="<?php echo esc_attr($image['list_title']); ?>">
                                </div>
                                <?php
                                    if($key == 4){
                                        break; 
                                    } 
                                ?>
                            <?php endforeach; ?>
                        </div>
                        <!-- shape -->
                    <?php endif; ?>
                    <div class="container">
                        <div class="row">
                            <?php if( isset($thumb['url']) && $thumb['url'] !='' ): ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="banner-thumb">
                                        <img src="<?php echo esc_url($thumb['url']); ?>" alt="<?php echo esc_attr($settings['sub_title']); ?>">
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-lg-<?php echo esc_attr($thumb['url'] == ''?'12':'6') ?> col-md-<?php echo esc_attr($thumb['url'] == ''?'12':'6') ?>">
                                <div class="hero-content">
                                    <?php if( $settings['top_title'] !='' ): ?>
                                        <div class="sub-heading"> <?php echo esc_html($settings['top_title']); ?> </div>
                                    <?php endif; ?>
                                    <?php if( $settings['title'] !='' ): ?>
                                     <h2> <?php echo esc_html( $settings['title'] ); ?> </h2>
                                    <?php endif; ?>
                                    <?php if( $settings['sub_title'] !='' ): ?>
                                        <p>
                                            <?php echo esc_html( $settings['sub_title'] ); ?>
                                        </p>
                                    <?php endif; ?>
                                    <?php if( is_array( $feature_list ) && count( $feature_list ) ): ?>
                                        <ul>
                                            <?php foreach($feature_list as $feature_item): ?>
                                                <li class="elementor-repeater-item-<?php echo esc_attr($feature_item['_id']); ?>"> 
                                                <?php \Elementor\Icons_Manager::render_icon( $feature_item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                                 <?php echo esc_html($feature_item['list_title']); ?> </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                   <?php if( $settings['button_text'] !=''): ?>
                                    <a href="<?php echo esc_url($settings['button_url']); ?>" class="bisylms-btn bisylms-btn-2"> <?php echo esc_html($settings['button_text']); ?> </a>
                                   <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>  
               <!-- Banner End -->
        <?php endif; ?>
    <?php  

    }
    
    protected function _content_template() { }
   
}