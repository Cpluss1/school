<?php 


if(!function_exists('bisy_return')):

    function bisy_return($str){
        return $str;
    }

endif;

/**
 * 
 *
 * get widgets class list
 *
 * @since 1.0
 * @return array
 */
if(!function_exists('bisy_widgets_class_list')):
    function bisy_widgets_class_list($dir){
       $classes = [];
        foreach (glob("$dir/*.php") as $filename) {
            if(!is_null(basename( $filename))){
                $classes[] = strtok( basename($filename),'.') ;
            }
           
        }
        return $classes;
    }
endif;




function bisy_errors(){
    static $wp_error; // Will hold global variable safely
    return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
}

// get theme setting option
if( !function_exists('bisy_carbon_option')):
    function bisy_carbon_option( $key, $default_value = '', $method = 'option' ) {
        
        if ( defined( 'QTRP' ) ) {
            switch ( $method ) {
             
                case 'option':
                    $value = carbon_get_theme_option( $key );
                    break;
                default:
                    $value = '';
                    break;
            }
            return (!isset($value) || $value == '') ? $default_value :  $value;
        }
        return $default_value;
    }
endif;
// get theme post ,page meta option
if( !function_exists('bisy_carbon_meta_option')): 
    function bisy_carbon_meta_option( $postid, $key, $default_value = '' ) {
        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_post_meta($postid, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;
    }
endif;
// get user meta option
if( !function_exists('bisy_user_meta_option')): 
    function bisy_user_meta_option( $user_id, $key, $default_value = '' ) {
        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_user_meta($user_id, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;
    }
endif;
// get comment meta option
if( !function_exists('bisy_comment_meta_option')): 
    function bisy_comment_meta_option( $comment_id, $key, $default_value = '' ) {

        if ( defined( 'QTRP' ) ) {
            $value = carbon_get_comment_meta($comment_id, $key);
        }
        return (!isset($value) || $value == '') ? $default_value :  $value;

    }
endif;

 if(!function_exists('bisy_eseential_get_post_category')) {
    function bisy_eseential_get_post_category($tax = 'category',$return_all = false) {

        $list = [];
        if( !count( $list ) ) {
         
            $categories = get_terms( $tax, array(
                    'orderby'       => 'name', 
                    'order'         => 'DESC',
                    'hide_empty'    => false,
                    'number'        => 200
            
            ) );

            if($return_all){
                
                return $categories;
            }
             print_r($categories);
            foreach( $categories as $category ) {
                $list[$category->term_id] = $category->name;
            }
        }
       
        return $list;
    }
 }

 if( !function_exists('bisy_get_post_tags') ){

    function bisy_get_post_tags($tax = 'post_tag') {
   
        $list = [];

        if( !count( $list ) ) {
           $categories = get_terms( $tax, array(
              'orderby'       => 'name', 
              'order'         => 'DESC',
              'hide_empty'    => false,
              'number'        => 200
             
          ) );
     
          foreach( $categories as $category ) {
             $list[$category->term_id] = $category->name;
          }
          
        }
      
        return $list;
    }
 }

 if(!function_exists('bisy_get_post_author')){

    function bisy_get_post_author(){
        static $list = [];

        if( !count( $list ) ) {
           $authors = get_users(
                array( 
                    'fields' => array( 'display_name','ID' ) ) 
            );
     
          foreach( $authors as $author ) {
             $list[$author->ID] = $author->display_name;
          }
          
        }
      
        return $list;
    }

 }

 if(!function_exists('bisy_get_posts')) {

    function bisy_get_posts($post_type = 'post'){
        $list = [];

        if( !count( $list ) ) {
           $posts = get_posts(
                [
                'numberposts' => -1,
                'post_status' => 'publish',
                'post_type' => $post_type
                ]
            );
     
          foreach( $posts as $post ) {
             $list[$post->ID] = $post->post_title;
          }
          
        }
      
        return $list;
    }

 }

 function bisy_current_theme_supported_post_format(){
   
    static $list = [];

    if( !count( $list ) ) {

        $post_formats = get_theme_support( 'post-formats' );
        
        if(isset($post_formats[0])) {
            $post_formats = $post_formats[0];
        }else{
            return $list;
        }
        
        foreach( $post_formats as $format ) {
            $list['post-format-'.$format] = $format;
        }
      
    }
   
    return $list;
   
 }

 /* elementor Slider control  */

 function bisy_widgets_slider_controls_setttings($settings){
    
    $return_controls = [];

    $slider_controls = [
        'bisy_slider_items',
        'slider_enable',
        'bisy_slider_items_tablet',
        'bisy_slider_items_mobile',
        'bisy_slider_autoplay',
        'bisy_slider_autoplay_timeout',
        'bisy_slider_smart_speed',
        'bisy_slider_dot_nav_show',
        'bisy_slider_nav_show',
        'bisy_slider_padding',
        'bisy_slider_loop'
    ];   
    
    
    foreach($settings as $key=> $item){

       if(in_array($key,$slider_controls) ){
          $return_controls[$key] = $item;
       } 
      
    }
    
   return $return_controls;
 }
  // get all user created menu list
 function bisy_get_all_menus(){

    $list = [];
    $menus = wp_get_nav_menus(); 
    
    foreach($menus as $menu){
        $list[$menu->slug] = $menu->name;
    }
    $list['empty'] = esc_html__('Empty','bisy-essential');
    return $list;

 }

 function bisy_get_border_style(){

    $borders_class = [
        'border_white_right'  => esc_html__( 'Right', 'bisy-essential' ),
        'border_white_left'   => esc_html__( 'Left', 'bisy-essential'),
        'border_white_bottom' => esc_html__( 'Bottom', 'bisy-essential'),
        'border_white_top'    => esc_html__( 'Top', 'bisy-essential'),
        'border_none'         => esc_html__( 'None', 'bisy-essential' ),
    ];

    return $borders_class;
 }

    
    if(!function_exists('bisy_meta_option')){
        function bisy_meta_option( $postid, $key, $default_value = '', $parent_key = '' ) {
           
            $post_key = 'bisy_post_options';
           // page meta
           if(is_singular( 'page' )){
              $post_key = 'bisy_page_options';
           }
            // post meta
           if(is_singular('post')){
              $post_key = 'bisy_post_options';
           }
           // custom post meta
           if(is_singular('lp_course')){
              $post_key = 'bisy_lp_course_options';
           }
           
           if(is_singular('bisy-events')){
              $post_key = 'bisy_events_options';
           }
           if($parent_key !=''){
            $post_key = $parent_key;
           }
         
           if( class_exists( 'CSF' ) ){
              $options = get_post_meta( $postid, $post_key, true );
              return ( isset( $options[$key] ) ) ? $options[$key] : $default_value; 
              
           }
           
           return $default_value;
        }
     }
   

    

     if( !function_exists('bisy_term_option')):
        
        function bisy_term_option( $termid, $key, $default_value = '', $taxomony = 'category') {
           
           if ( defined( 'FW' ) ) {
                $value = fw_get_db_term_option($termid, $taxomony, $key);
            }
           
           return (!isset($value) || $value == '') ? $default_value :  $value;
        }

    endif;

    function bisy_course_cageory_by_id( $post_id=null,$single=true ){
        $terms = get_the_terms( $post_id, 'course_category' );
        $cat = '';
        $cat_with_link = '';
                    
        if(is_array($terms)):
    
            foreach($terms as $tkey=>$term):
                
                $cat.= $term->slug.' ';
                
                $cat_with_link .= sprintf("<a class='c-cate' href='%s'>%s</a>",get_category_link($term->term_id),$term->name);
                
                if($single){
                    break;
                }
    
                if($tkey==1)  {
                    break;
                }
    
            endforeach;
    
        endif; 
         return $cat_with_link;
    }

    function bisy_custom_date_format($index = null){

        $data = [];
        $data[0]    = esc_html__('Custom Date formt','bisy-essential');
        $data[]    = 'F j, Y';
        $data[]    = 'M d, Y';
        $data[]    = 'M j, Y';
        $data[]    = 'Y-m-d';
        $data[]    = 'm/d/Y';
        $data[]    = 'd/m/Y';
  
        if( !is_null( $index ) ){
  
         return $data[$index];
        }
  
        return $data;
     } 

  