<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;

class About extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-about-course';
    }

    public function get_title() {
        return esc_html__( 'Bisy About Course', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'fa fa-file-powerpoint-o';
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }
    public function layout(){
        return[
            
            'style1'   => esc_html__( 'Style1', 'bisy-essential' ),
        

        ];
    }
    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Settings', 'bisy-essential'),
            ]
        );

            $this->add_control(
                'style',
                [
                    'label'   => esc_html__( 'Layout', 'bisy-essential' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => $this->layout(),
                ]
            );
        
            $this->add_control(
                'top_title', [
                    'label'       => esc_html__( 'Top Title', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Get in ', 'bisy-essential' ),
                    'default'     => esc_html__( 'Service We Offer ', 'bisy-essential' ),
                    
                ]
            ); 

            $this->add_control(
                'title', [
                    'label'       => esc_html__( 'Title text', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Get in ', 'bisy-essential' ),
                    'default'     => esc_html__( 'Get Best In Your Side Pocket ', 'bisy-essential' ),
                
                    
                ]
            );

            $this->add_control(
                'content', [
                    'label'       => esc_html__( 'Sub Content', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'placeholder' => esc_html__( 'Sub content here', 'bisy-essential' ),
                    'description' => esc_html__(' use \n for new line ','bisy-essential')
                 ]
            );

            $this->add_control(
                'button_text', [
                    'label'       => esc_html__( 'Button text', 'bisy-essential' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                   
                ]
            );

            $this->add_control(
                'button_url', [
                    'label'       => esc_html__( 'Button Url', 'bisy-essential' ),
                    'type'        => Controls_Manager::URL,
                    'label_block' => true,
                   
                ]
            );

            $this->add_control(
            'heading_type',
                [
                    'label'   => esc_html__( 'Top Heading type', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'default' => 'h3',
                    'options' => [
                        'h1' => esc_html__( 'H1', 'bisy-essential' ),
                        'h2' => esc_html__( 'H2', 'bisy-essential' ),
                        'h3' => esc_html__( 'H3', 'bisy-essential' ),
                        'h4' => esc_html__( 'H4', 'bisy-essential' ),
                        'h5' => esc_html__( 'H5', 'bisy-essential' ),
                        'h6' => esc_html__( 'H6', 'bisy-essential' ),
                        'p'  => esc_html__( 'P', 'bisy-essential' ),
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_align', [
                    'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                    'type'    => Controls_Manager::CHOOSE,
                    'options' => [

                'left'		 => [
                    
                    'title' => esc_html__( 'Left', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-left',
                
                ],
                    'center'	     => [
                    
                    'title' => esc_html__( 'Center', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-center',
                
                ],
                'right'	 => [

                    'title' => esc_html__( 'Right', 'bisy-essential' ),
                    'icon'  => 'fa fa-align-right',
                    
                ],
                
                'justify'	 => [

                   'title' => esc_html__( 'Justified', 'bisy-essential' ),
                   'icon'  => 'fa fa-align-justify',
                   
                        ],
                ],
                 
                'selectors' => [
                        '{{WRAPPER}} .ab-content'   => 'text-align: {{VALUE}};',
                    ],
                ]
            );//Responsive control end

        $this->end_controls_section();

        //Title Style Section
	
        $this->start_controls_section(
			'section_top_title_style', [
				'label' => esc_html__( 'Top Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
   
        $this->add_control(
			'top_title_color', [

				'label'		 => esc_html__( 'Color', 'bisy-essential' ),
				'type'		 => Controls_Manager::COLOR,
				'selectors'	 => [
                  '{{WRAPPER}} .top-title' => 'color: {{VALUE}};',
      
                 
				],
			]
        );

        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'top_title_typho',
                'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                'selector' => '{{WRAPPER}} .top-title',
            ]
        );

        $this->add_responsive_control(
            'top_title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .top-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                    
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'top_title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .top-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                   
                ],
                'separator' => 'before',
            ]
        );
  
        $this->end_controls_section();
         
        $this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
 

            $this->add_control(
                'title_color', [

                    'label'		 => esc_html__( 'Title color', 'bisy-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                
                    
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'title_typho',
                    'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .title',
                
                ]
            );

            $this->add_responsive_control(
                'title_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'title_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

       
        $this->end_controls_section();

        $this->start_controls_section(
			'section_sub_title_style', [
				'label' => esc_html__( 'Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
               
			]
        );

            $this->add_control(
                'sub_title_color', [

                    'label'		 => esc_html__( 'Color', 'bisy-essential' ),
                    'type'		 => Controls_Manager::COLOR,
                    'selectors'	 => [
                    '{{WRAPPER}} .content' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'sub_title_typho',
                    'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .content',
                
                ]
            );

            $this->add_responsive_control(
                'sub_title_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                    
                        '{{WRAPPER}} .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'sub_title_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                    
                        '{{WRAPPER}} .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section('BISY__main_section',
            [
            'label' => esc_html__( 'Main Box', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

  
            $this->add_responsive_control(
                'main_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .ab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'main_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .ab-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'main_section_background',
                    'label' => esc_html__( 'Background', 'bisy-essential' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .ab-content',
                ]
            );

       $this->end_controls_section();

       $this->start_controls_section(
            'section_button_style2', [
                'label' => esc_html__( 'Button', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                
            ]
        );


            $this->add_control(
                'fea_button_color2', [

                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .main-btn' => 'color: {{VALUE}};',
                  
                    ],
                ]
            );

            $this->add_control(
                'fea_button_hv_color2', [

                    'label'     => esc_html__( 'Hover Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .main-btn:hover' => 'color: {{VALUE}};',
                   
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'button_content_typho2',
                    'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .main-btn',
                ]
            );

            $this->add_responsive_control(
                'button_section_padding2',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'button_section_margin2',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .main-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_background_heading2',
                [
                    'label' => esc_html__( 'Background color', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
    
            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'button_input_section_background2',
                    'label'    => esc_html__( 'Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .main-btn',
                ]
            );
            $this->add_control(
                'button_background_hv_heading2',
                [
                    'label' => esc_html__( 'Background hover color', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'button_input_section_hv_background2',
                    'label'    => esc_html__( 'Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .main-btn:hover',
                ]
            );

            $this->add_control(
                'button_section_border_radius2',
                    [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                            '{{WRAPPER}} .main-btn' => 'border-radius: {{VALUE}}px;',
                          
                    ],
                ]
            ); 

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'button2_section_border',
                    'label' => esc_html__( 'Border', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .main-btn',
                ]
            );

    $this->end_controls_section();

     
    } //Register control end

    protected function render( ) { 

		$settings   = $this->get_settings();
		$content    = $settings['content'];
		$button_url = $settings['button_url'];
		$content    = str_replace(['\n'], ['<span>', '</span>'], $content);
       
    ?>    
         
        <?php if( $settings['style'] == 'style1' ): ?> 
              <div class="ab-content">
                <<?php echo esc_attr( $settings['heading_type'] ); ?> class="top-title">
                    <?php if( $settings['top_title'] !='' ): ?>
                        <?php echo esc_html($settings['top_title']); ?>
                    <?php endif; ?>
                </<?php echo esc_attr($settings['heading_type']); ?>>
                <?php if( $settings['title'] !='' ): ?>
                    <p class="mid-item title"> <?php echo esc_html($settings['title']); ?> </p>
                <?php endif; ?>
                <?php if($settings['content'] !=''): ?>
                <p>
                  <?php echo esc_html( $settings['content'] ); ?> 
                </p>
                <?php endif; ?>
                <?php if($settings['button_text'] !=''): ?>
                    <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="bisylms-btn main-btn">
                      <?php echo esc_html( $settings['button_text'] ); ?>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif ?>    
    
    <?php  

    }
    
    protected function _content_template() { }
}