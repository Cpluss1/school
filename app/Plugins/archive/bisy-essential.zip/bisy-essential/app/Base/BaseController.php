<?php 
/**
 * @package  quomodo
 */
namespace BisyEssential\Base;

class BaseController
{
	public $plugin_path;

	public $plugin_url;

	public $plugin;

	public function __construct() {
		$this->plugin_path = BISY_ESSENTIAL_PLUGIN_PATH;
		$this->plugin_url  = BISY_ESSENTIAL_PLUGIN_URL;
		$this->plugin      = BISY_ESSENTIAL_PLUGIN;
	}
}