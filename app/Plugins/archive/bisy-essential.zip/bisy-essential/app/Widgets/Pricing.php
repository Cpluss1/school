<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;


class Pricing extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-pricing';
    }

    public function get_title() {
        return esc_html__( 'Pricing box', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'eicon-price-list';
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        
        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'bisy-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'bisy-essential' ),
                    'imagelarge' => BISY_ESSENTIAL_IMG . '/admin/price/style-1.png',
                    'imagesmall' => BISY_ESSENTIAL_IMG . '/admin/price/style-1.png',
                    'width'      => '50%',
               ],

         
         
           ],

         ]
       ); 

       $this->end_controls_section();

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Pricing Content', 'bisy-essential'),
            ]
        );

        $this->add_control(
                'image',
                [
                    'label'   => esc_html__( 'Choose Image', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                         'url' => '',
                    ],
                ]
        );
       
        $this->add_control(
			'package_name',
			[
				'label'       => esc_html__( 'Package Name', 'bisy-essential' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter your Price Package', 'bisy-essential' ),
			]
        );

        $this->add_control(
			'price',
			[
				'label'       => esc_html__( 'Package Price', 'bisy-essential' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Package Price', 'bisy-essential' ),
			]
        );

        $this->add_control(
			'currency',
			[
				'label'       => esc_html__( 'Currency', 'bisy-essential' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Package Currency', 'bisy-essential' ),
			]
        );

        
        $this->add_control(
			'duration',
			[
				'label'       => esc_html__( 'Duration', 'bisy-essential' ),
				'type'        => Controls_Manager::TEXT,
				
			]
        );

     
     
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Optimized' , 'bisy-essential' ),
				'label_block' => true,
			]
        );
        
        $repeater->add_control(
			'check_disable',
			[
				'label'        => esc_html__( 'Check Disable', 'bisy-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Enable', 'bisy-essential' ),
				'label_off'    => esc_html__( 'Disable', 'bisy-essential' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'service_list',
			[
				'label' => esc_html__( 'Service List', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ list_title }}}',
			]
		);
      


        
        $this->add_control('price_button_text',
			   [
				'label' => esc_html__( 'Button Text', 'bisy-essential' ),
				'type'  => Controls_Manager::TEXT,
				
			   ]
        );
        
        $this->add_control('price_button_url',
            [
               'label' => esc_html__( 'Button Link', 'bisy-essential' ),
               'type'  => Controls_Manager::TEXT,
               
            ]
        );
      
        
        $this->add_responsive_control(
			'contents_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .pricing-item' => 'text-align: {{VALUE}};',
                 

				],
			]
        );//Responsive control end

      
        
        $this->end_controls_section();

          
        $this->start_controls_section('price_section_package_tag_style',
            [
                'label' => esc_html__( 'Package name', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
               
            ]
        );
        
                $this->add_control('box_price_package_tag_color',
                    [
                    'label'     => esc_html__( 'Price color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-item h5' => 'color: {{VALUE}};',
                        
                    ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'   => 'box_price_package_tag_typography',
                        'label'  => esc_html__( 'Typhography', 'bisy-essential' ),
                        'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                    
                    'selector' => '{{WRAPPER}} .pricing-item h5',
                    ]
                );

                $this->add_responsive_control(
                    'box_price_package_tag_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pricing-item h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

                $this->add_responsive_control(
                    'box_price_package_tag_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pricing-item h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

       $this->end_controls_section();

       $this->start_controls_section('pricing_image_section',
            [
                'label' => esc_html__( 'Image', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image__pos_top',
            [
                'label' => esc_html__( 'Position Top', 'bisy-essential' ),
               
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -500,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .pricing-item img' => 'top: {{SIZE}}{{UNIT}};',
                    
                    
                ],
               
            ]
        );

         $this->add_responsive_control(
            'image_pos_left',
               [
                  'label' => esc_html__( 'Position left', 'bisy-essential' ),
                  'type' => Controls_Manager::SLIDER,
                  
                  'size_units' => [ 'px', '%' ],
                  'range' => [
                     'px' => [
                           'min' => -500,
                           'max' => 1000,
                           'step' => 1,
                     ],
                     '%' => [
                           'min' => 0,
                           'max' => 100,
                     ],
                  ],
                  
                  'selectors' => [
                     '{{WRAPPER}} .pricing-item img' => 'left: {{SIZE}}{{UNIT}};',
                     
                     
                  ],
                  
               ]
         );

         
         $this->add_responsive_control(
            'image_pos_right',
               [
                  'label' => esc_html__( 'Position right', 'bisy-essential' ),
                  'type' => Controls_Manager::SLIDER,
                  
                  'size_units' => [ 'px', '%' ],
                  'range' => [
                     'px' => [
                           'min' => -500,
                           'max' => 1000,
                           'step' => 1,
                     ],
                     '%' => [
                           'min' => 0,
                           'max' => 100,
                     ],
                  ],
                  
                  'selectors' => [
                     '{{WRAPPER}} .pricing-item img' => 'right: {{SIZE}}{{UNIT}};',
                     
                     
                  ],
                  
               ]
         );
       
         
     
       $this->end_controls_section();
        
        
  
        $this->start_controls_section('price_section',
            [
                'label' => esc_html__( 'Price', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control('box_price_color',
            [
               'label'     => esc_html__( 'Price color', 'bisy-essential' ),
               'type'      => Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .p-price ' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .p-price sup' => 'color: {{VALUE}};',
                
               ],
			  ]
        );

        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'   => 'box_price_typography',
                'label'  => esc_html__( 'Typhography', 'bisy-essential' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
            
               'selector' => '{{WRAPPER}} .p-price sup,{{WRAPPER}} .p-price',
            ]
        );

        $this->add_responsive_control(
            'price_package_padding',
            [
                'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .p-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   
                ],
            ]
        );

       $this->end_controls_section();
       $this->start_controls_section('package_duration_section',
            [
                'label' => esc_html__( 'Package Duration', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
       );
            $this->add_control('package_duration_color',
            [
                'label'     => esc_html__( 'Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .p-price span' => 'color: {{VALUE}};',
                
                ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'   => 'package_duration_typography',
                    'label'  => esc_html__( 'Typhography', 'bisy-essential' ),
                    'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                
                   'selector' => '{{WRAPPER}} .p-price span',
                ]
            );

            $this->add_responsive_control(
                'package_duration_padding',
                [
                    'label'      => esc_html__( ' Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .p-price span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};display:block;',
                    ],
                ]
            );
            $this->add_responsive_control(
                'package_name_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .p-price span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};display:block;',
                    ],
                ]
            );

        $this->end_controls_section();
        $this->start_controls_section('button_section',
            [
                'label' => esc_html__( 'Button', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
       );
       
                $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'app_price_button_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .bisylms-btn-2',
                            
                        ]
                );

                $this->add_control('box_button_text_color',
                    [
                    'label'     => esc_html__( 'Button text color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .bisylms-btn-2' => 'color: {{VALUE}};',
                                    
                        ],
                    ]
                );
      
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'   => 'box_button_text_typography',
                        'label'  => esc_html__( 'Typhography', 'bisy-essential' ),
                        'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .bisylms-btn-2',
                    ]
                );

                $this->add_control('box_button_text_hover_color',
                    [
                    'label'     => esc_html__( 'Button text hover', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                            '{{WRAPPER}} .bisylms-btn-2:hover' => 'color: {{VALUE}};',
                        
                                            
                            ],
                    ]
                );
                
                $this->add_control('box_button_bg_color',
                [
                        'label'     => esc_html__( 'Button background', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .bisylms-btn-2' => 'background: {{VALUE}};',
                        
                        
                                    
                        ],
                    ]
                );

                $this->add_control(
                    'box_button_hv_bg_colors_heading',
                    [
                        'label' => esc_html__( 'Hover Background color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'box_button_hv_bg_colors',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .bisylms-btn-2:hover',
                    ]
                );

                $this->add_control(
                    'box_button_border_hv_bg_colors_heading',
                    [
                        'label' => esc_html__( 'Hover border', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'box_button_border_hv_bg_colors',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .bisylms-btn-2:hover',
                    ]
                );
     
                $this->add_responsive_control(
                    'label_border_radius',
                    [
                        'label'     => esc_html__( 'Button Border Radius', 'bisy-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .bisylms-btn-2' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'pricing_btn_borders',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .bisylms-btn-2',
                    ]
                );
                
                $this->add_responsive_control(
                        'pricing_boxs_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .bisylms-btn-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    
                    $this->add_responsive_control(
                        'pricing_boxs_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .bisylms-btn-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                
        $this->end_controls_section();


        $this->start_controls_section('details_section',
                [
                    'label' => esc_html__( 'Service content', 'bisy-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
            $this->add_control('box_content_color',
                [
                'label'     => esc_html__( 'content color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-item ul li' => 'color: {{VALUE}};',
                    
                ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'   => 'footer_typography',
                    'label'  => esc_html__( 'Typhography', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .pricing-item ul li',
                ]
            );

            $this->add_responsive_control(
                'service_details_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .pricing-item ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'service_details_inner_padding',
                [
                    'label'      => esc_html__( 'List Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .pricing-item ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            
            $this->add_control(
                'service_detail_show_border',
                [
                    'label' => esc_html__( 'Show Service', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'block',
                    'options' => [
                        'block' => esc_html__( 'Show', 'bisy-essential' ),
                        'none'  => esc_html__( 'Hide', 'bisy-essential' ),
                    ],
                    'selectors'  => [
                        '{{WRAPPER}} .pricing-item ul' => 'display: {{VALUE}};',
                    ],
                   
                ]
            );

            $this->add_responsive_control(
                'service_detail_icon_padding',
                    [
                        'label'      => esc_html__( 'List Icon Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .pricing-item ul li i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
      
                 ]
            );

        $this->end_controls_section();

        $this->start_controls_section('box_section',
                [
                    'label' => esc_html__( 'Box', 'bisy-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
        );

        $this->add_control('box_background_color',
        [
            'label'     => esc_html__( 'Background color', 'bisy-essential' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                  '{{WRAPPER}} .pricing-item' => 'background: {{VALUE}};',
                           
                ],
            ]
        );
      
       
        $this->add_group_control(
			Group_Control_Border:: get_type(),
			[
				'name'     => 'box_border',
				'label'    => esc_html__( 'Border', 'bisy-essential' ),
				'selector' => '{{WRAPPER}} .pricing-item',
			]
        );

        $this->add_responsive_control(
            '_box_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .pricing-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'box_margin',
            [
                'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .pricing-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
            ]
        );

        $this->add_responsive_control(
            'box_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .pricing-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'pricing_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
				'selector' => '{{WRAPPER}} .pricing-item',
			]
        );
        
        $this->add_control(
            'box_item_hv_bg_colors_heading',
            [
                'label' => esc_html__( 'Hover Background color', 'bisy-essential' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
               
            ]
        );

        $this->add_control('box_background_color_style4',
        [
            'label'     => esc_html__( 'Background color', 'bisy-essential' ),
            'type'      => Controls_Manager::COLOR,
           
            'selectors' => [
                  '{{WRAPPER}} .pricing-item:hover' => 'background: {{VALUE}};',
                           
                ],
            ]
            
        );

        $this->add_control(
            'pricing_border_popover_toggle',
            [
                'label' => esc_html__( 'Hover Border', 'bisy-essential' ),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'label_off' => esc_html__( 'Default', 'bisy-essential' ),
                'label_on' => esc_html__( 'Over Top Color', 'bisy-essential' ),
                'return_value' => 'yes',
                'default' => 'yes',
                
            ]
        );

                $this->start_popover();

                    $this->add_control(
                        'item_border_top_color_border', [

                            'label'     => esc_html__( 'Color', 'bisy-essential' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                            '{{WRAPPER}} .pricing-item:after' => 'box-shadow: 0px -3px 0px 0px {{VALUE}}',
                        
                        
                            ],
                        ]
                    );

                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'item_border__top_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .pricing-item:after',
                        ]
                    );

                $this->end_popover();

       

        $this->end_controls_section();

    } //Register control end

    protected function render( ) { 
     
                $settings             = $this->get_settings();
                $package_name         = $settings["package_name"];
                $price                = $settings["price"];
              
                $service_list         = $settings["service_list"];
               
                $button_text          = $settings["price_button_text"];
                $button_url           = $settings["price_button_url"];
             

    
        ?>  

        <?php if($settings['block_style'] =='style1'): ?>    
                <div class="pricing-item">
                    <h5><?php echo esc_html($package_name); ?></h5>
                    <?php if($settings['image']['url'] != ''): ?>
                    <img src="<?php echo esc_url($settings['image']['url']); ?>" alt="<?php echo esc_attr($package_name); ?>">
                    <?php endif; ?>
                    <div class="p-price">
                        <sup> <?php echo esc_html($settings['currency']); ?> </sup> <?php echo esc_html($price); ?> <span> <?php echo esc_html($settings['duration']); ?>  </span>
                    </div>
                    <ul>
                        <?php foreach($service_list as $item): ?>
                        
                            <?php if($item['check_disable'] =='yes'): ?>
                                <li class="disable"><i class="icon_check"></i> <?php echo esc_html( $item['list_title'] ); ?> </li>
                            <?php else: ?>
                                <li><i class="icon_check"></i> <?php echo esc_html( $item['list_title'] ); ?> </li>
                            <?php endif ?>
                        <?php endforeach; ?>  
                    
                    </ul>
                    <?php if($button_text !=''): ?>
                    <a href="<?php echo esc_url($button_url); ?>" class="bisylms-btn-2"> <?php echo esc_html($button_text); ?> </a>
                    <?php endif; ?>
                </div>
        <?php endif; ?>
    <?php  
    }
    protected function _content_template() { }
}