<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use BisyEssential\Base\Repository\Base_Modal;
if ( ! defined( 'ABSPATH' ) ) exit;

class Course extends Widget_Base {

  public $base;

    public function get_name() {
        return 'bisy-course-block';
    }

    public function get_title() {
        return esc_html__( 'Course Post', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'eicon-nav-menu';
    }

    public function get_categories() {
        return [ 'ahost-elements' ];
    }

    protected function _register_controls() {

      
       do_action( 'bisy_section_general_tab', $this, $this->get_name() );
       do_action( 'bisy_section_data_exclude_tab', $this , $this->get_name() );  
       do_action( 'bisy_section_date_filter_tab', $this , $this->get_name());  
       do_action( 'bisy_section_taxonomy_filter_tab', $this , $this->get_name());  
       do_action( 'bisy_section_sort_tab', $this , $this->get_name());  
       do_action( 'bisy_section_sticky_tab', $this , $this->get_name());  
        // Style
          
        $this->start_controls_section('bisy_style_title_section',
        [
           'label' => esc_html__( 'Title', 'bisy-essential' ),
           'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
            $this->add_control(
               'block_title_color',
               [
                  'label'   => esc_html__('Color', 'bisy-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .signle__blog__content .title a' => 'color: {{VALUE}};',
                  
                  ],
               ]
            );

            $this->add_control(
               'block_title_hv_color',
               [
                  'label'   => esc_html__('Hover color', 'bisy-essential'),
                  'type'    => Controls_Manager::COLOR,
                  'default' => '',
               
                  'selectors' => [
                     '{{WRAPPER}} .signle__blog__content .title a:hover' => 'color: {{VALUE}};',
                
                  ],
               ]
            );

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'post_title_typography',
                  'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                
                  'selector' => '{{WRAPPER}} .signle__blog__content .title a',
               ]
            );

            $this->add_responsive_control(
             'title_margin',
             [
                'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'selectors'  => [
                   '{{WRAPPER}} .signle__blog__content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
                ],
             ]
            );

            $this->add_responsive_control(
               'title_padding',
               [
                  'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .signle__blog__content .title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                  ],
               ]
            );

      $this->end_controls_section();

      $this->start_controls_section('BISY__post_content_section',
         [
            'label'     => esc_html__( 'Content ', 'bisy-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
           
         ]
     );

         $this->add_control(
            'block_content_color',
            [
               'label'   => esc_html__('Color', 'bisy-essential'),
               'type'    => Controls_Manager::COLOR,
               'default' => '',
               
               'selectors' => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'color: {{VALUE}};',
               ],
            ]
         );

        
         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'post_content_typography',
               'label'    => esc_html__( 'Typography', 'bisy-essential' ),
             
               'selector' => '{{WRAPPER}} .signle__blog__content .post-desc',
            ]
         );
         $this->add_responsive_control(
         'content_margin',
         [
            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}}  .signle__blog__content .post-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
         );
         $this->add_responsive_control(
            'content_padding',
            [
               'label'      => esc_html__( 'Padding', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .signle__blog__content .post-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

      $this->end_controls_section();

      $this->start_controls_section('bisy_style_pcontent_section',
         [
            'label'     => esc_html__( 'Post meta', 'bisy-essential' ),
            'tab'       => Controls_Manager::TAB_STYLE,
         
         ]
     );
  
      $this->add_control(
       'post_meta_date_color',
         [
             'label' => esc_html__('Date color', 'bisy-essential'),
             'type'  => Controls_Manager::COLOR,
             
             'selectors' => [
                 '{{WRAPPER}} .single__blog__meta .meta__date'    => 'color: {{VALUE}};',
             
             ],
         ]
      ); 
 
       $this->add_group_control(
         Group_Control_Typography:: get_type(),
         [
             'name'     => 'meta_other_typography',
             'label'    => esc_html__( ' Date Typography', 'bisy-essential' ),
           
             'selector' => '{{WRAPPER}} .single__blog__meta .meta__date',
           
         ]
      );  

     // author
     
         $this->add_control(
            'post_meta_author_color',
            [
                  'label' => esc_html__('Author color', 'bisy-essential'),
                  'type'  => Controls_Manager::COLOR,
                  
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__meta .meta__author a'    => 'color: {{VALUE}};',
                  
                  ],
            ]
         ); 

         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                  'name'     => 'meta_author_typography',
                  'label'    => esc_html__( ' Author Typography', 'bisy-essential' ),
                
                  'selector' => '{{WRAPPER}} .single__blog__meta .meta__author',
               
            ]
         ); 

     //cat

        $this->add_control(
         'post_category_color',
            [
               'label'     => esc_html__('Category Color', 'bisy-essential'),
               'type'      => Controls_Manager::COLOR,
               'default'   => '',
               'selectors' => [

                  '{{WRAPPER}} .single__blog__meta .meta__category .cat' => 'color: {{VALUE}};',
            
               ],
            ]
         ); 

         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'meta_category_typography',
               'label'    => esc_html__( 'Category Typography', 'bisy-essential' ),
             
               'selector' => '{{WRAPPER}} .single__blog__meta .meta__category .cat',
               
            ]
         );

         $this->add_responsive_control(
            'post__meta_margin',
            [
               'label'      => esc_html__( 'Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                     '{{WRAPPER}} .single__blog__meta'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );
     
     $this->end_controls_section();
 
      $this->start_controls_section('bisy_image_section',
         [
            'label' => esc_html__( 'Image', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );

            $this->add_responsive_control(
            'image_margin',
               [
                  'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                     '{{WRAPPER}} .single__blog__post__thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  ],
               ]
            );

            $this->add_control(
               'post_image_overlay_c_heading',
               [
                  'label'     => esc_html__( 'Overlay color', 'bisy-essential' ),
                  'type'      => \Elementor\Controls_Manager::HEADING,
                  'separator' => 'before',
               ]
            );
   
         
            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'      => 'post_image_overlay_color',
                  'label'     => esc_html__( 'Background', 'bisy-essential' ),
                  'types'     => [ 'gradient' ],
                  'selector'  => '{{WRAPPER}} .gradient1::after',
                 
               ]
            );
            
            $this->add_control(
               'post_image_overlay_opecity',
               [
                  'label'      => esc_html__( 'Opacity', 'bisy-essential' ),
                  'type'       => Controls_Manager::SLIDER,
                  'size_units' => [ 'px' ],
                  'range'      => [
                     'px' => [
                        'min'  => 0,
                        'max'  => 1,
                        'step' => .1,
                     ],
                   
                  ],
                 
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__post__thumb::after' => 'opacity: {{SIZE}};',
                  ],
               ]
            );
  
            $this->add_responsive_control(
               'box_image_height',
               [
                  'label'      => esc_html__( 'Image height', 'bisy-essential' ),
                  'type'       => Controls_Manager::SLIDER,
                  'size_units' => [ 'px' ,'%' ],
                  'range'      => [
                     'px' => [
                        'min'  => 0,
                        'max'  => 800,
                        'step' => 1,
                     ],
                  
                  ],
               
                  'selectors' => [
                     '{{WRAPPER}} .single__blog__post__thumb img' => 'height: {{SIZE}}{{UNIT}};',
                  ],
               ]
            );

         $this->add_responsive_control(
            'box_image_width',
            [
               'label'      => esc_html__( 'Image Width', 'bisy-essential' ),
               'type'       => Controls_Manager::SLIDER,
               'size_units' => [ 'px','%' ],
               'range'      => [
                  'px' => [
                     'min'  => 0,
                     'max'  => 800,
                     'step' => 1,
                  ],
                
               ],
              
               'selectors' => [
                  '{{WRAPPER}} .single__blog__post__thumb img' => 'width: {{SIZE}}{{UNIT}};',
               ],
            ]
         );
      
          
      $this->end_controls_section();

      $this->start_controls_section('bisy_single_box_section',
         [
            'label' => esc_html__( 'Post item', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
   
      $this->add_responsive_control(
         'item_borders_radius',
         [
            'label'      => esc_html__( 'Border radius', 'bisy-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            
            'selectors' => [
               
               '{{WRAPPER}} .single__blog__post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
               
            ],
         ]
      );

      $this->add_group_control(
         \Elementor\Group_Control_Box_Shadow:: get_type(),
         [
            'name'     => 'single_post_box_shadow',
            'label'    => esc_html__( 'Box Shadow', 'bisy-essential' ),
            'selector' => '{{WRAPPER}} .single__blog__post',
         ]
      );
   
      $this->add_group_control(
         \Elementor\Group_Control_Background:: get_type(),
         [
            'name'     => 'single_box_background',
            'label'    => esc_html__( 'Background', 'bisy-essential' ),
            'types'    => [ 'classic', 'gradient', 'video' ],
            'selector' => '{{WRAPPER}} .single__blog__post,{{WRAPPER}} .signle__blog__content ',
         ]
      );
   
     $this->add_responsive_control(
      'single_box_margin',
      [
         'label'      => esc_html__( 'Margin', 'bisy-essential' ),
         'type'       => Controls_Manager::DIMENSIONS,
         'size_units' => [ 'px','%'],
         'selectors'  => [
            '{{WRAPPER}} .single__blog__post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
         ],
      ]
      );

      $this->add_responsive_control(
         'single_box_padding',
         [
            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px','%'],
            'selectors'  => [
               '{{WRAPPER}} .single__blog__post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
         ]
      );

      $this->end_controls_section();

      $this->start_controls_section('BISY_box_section',
         [
            'label' => esc_html__( ' Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
    
      $this->add_group_control(
			\Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'section_background',
               'label'    => esc_html__( 'Background', 'bisy-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .main-section',
            ]
        );
        
        $this->add_responsive_control(
         'box_margin',
            [
               'label'      => esc_html__( 'Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  
               ],
            ]
         );
         $this->add_responsive_control(
            'box_padding',
            [
               'label'      => esc_html__( 'Padding', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               'selectors'  => [
                  '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 
               ],
            ]
         );
      $this->end_controls_section();

    
   
      
        $this->start_controls_section('bisy_readmore_section',
            [
                  'label'     => esc_html__( 'Readmore', 'bisy-essential' ),
                  'tab'       => Controls_Manager::TAB_STYLE,
                 
            ]
         );

         $this->add_responsive_control(
            'readmore_margin',
                  [
                     'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px','%'],
                     'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     ],
                  ]
            );

            $this->add_responsive_control(
                  'readmore_padding',
                     [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                        '{{WRAPPER}} .readmore__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                     ]
            );

            $this->add_group_control(
                  \Elementor\Group_Control_Border::get_type(),
                  [
                     'name'     => 'readmore_border',
                     'label'    => esc_html__( 'Border', 'bisy-essential' ),
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Background::get_type(),
               [
                  'name'     => 'readmore_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient' ],
                  'selector' => '{{WRAPPER}} .readmore__btn',
               ]
            );
            $this->add_control(
            'readmore_color',
               [
                  'label'     => esc_html__('Color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .readmore__btn' => 'color: {{VALUE}};',
               
                  ],
               ]
            ); 

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                     'name'     => 'readmore_typography',
                     'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                   
                     'selector' => '{{WRAPPER}} .readmore__btn',
                     
               ]
            );
            $this->add_control(
               'readmore_bottom_border_hide',
               [
                  'label' => esc_html__( 'Border hide', 'bisy-essential' ),
                  'type' => \Elementor\Controls_Manager::SELECT,
                  'default' => 'solid',
                  'options' => [
                     'block'  => esc_html__( 'Show', 'bisy-essential' ),
                     'none' => esc_html__( 'None', 'bisy-essential' ),
                  ],
                  'selectors' => [
                     '{{WRAPPER}} a.readmore__btn:before' => 'display: {{VALUE}};',
               
                  ],
               ]
            );
            $this->add_control(
               'readmore_bottom_border_color',
                  [
                     'label'     => esc_html__('Bottom border Color', 'bisy-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} a.readmore__btn:before' => 'background: {{VALUE}};',
                  
                     ],
                  ]
            ); 

      $this->end_controls_section();

    }

    protected function render( ) { 
      
        $settings       = $this->get_settings();
        $data           = new Base_Modal($settings);
        $data->set_post_type('lp_course');
        $query          = $data->get();
       
        if( !$query ){
          return;  
        }
      
     ?>
      
      
        <!-- Course Start -->
        <section class="popular-course-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="course-wrapper">
                           <?php while($query->have_posts()) : $query->the_post(); ?>
                                 <div class="course-item-1 text-center">
                                    <?php

                                       $options = get_post_meta( get_the_ID(), 'bisy_lp_course_options', true );
                                       $icon    = '';
                                       if(isset( $options['course_icon'] )){
                                          if(isset($options['course_icon']['url'])){
                                             $icon = $options['course_icon']['url'];
                                          }
                                          
                                       }
                                     
                                    ?> 
                                    <?php if($icon != ''): ?>
                                         <img src="<?php echo esc_url($icon); ?>" />
                                    <?php endif; ?>
                                    <h4><a href="<?php echo esc_url(get_the_permalink()); ?>"> <?php echo esc_html(get_the_title()); ?> </a></h4>
                                 </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Course End -->


      <?php  
    }
    

    
}