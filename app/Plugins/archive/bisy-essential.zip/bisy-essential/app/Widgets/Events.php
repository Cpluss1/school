<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Custom_Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;


class Events extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-events-box';
    }

    public function get_title() {
        return esc_html__( 'Events', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-anchor";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }
   
    protected function _register_controls() {

        $this->start_controls_section(
            'section_layouts_tab',
            [
                'label' => esc_html__('Layout', 'bisy-essential'),
            ]
        );

        $this->add_control(

         'block_style', [
             'label'   => esc_html__('Choose Style', 'bisy-essential'),
             'type'    => Custom_Controls_Manager::RADIOIMAGE,
             'default' => 'style1',
             'options' => [
               'style1' => [
                    'title'      => esc_html__( 'Style 1', 'bisy-essential' ),
                    'imagelarge' => BISY_IMG . '/admin/events-box/style-1.png',
                    'imagesmall' => BISY_IMG . '/admin/events-box/style-1.png',
                    'width'      => '100%',
               ],
   
              ],

         ]
       ); 
       $this->end_controls_section();


        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Events settings', 'bisy-essential'),
            ]
        );
       
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'enable_custom_title',
			[
				'label'        => esc_html__( 'Enable Custom title', 'bisy-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Enable', 'bisy-essential' ),
				'label_off'    => esc_html__( 'Disable', 'bisy-essential' ),
				'return_value' => 'yes',
				'default'      => '',
			]
        );

		$repeater->add_control(
			'list_title', [
				'label'       => esc_html__( 'Event Custom Title', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Events Title' , 'bisy-essential' ),
				
                'label_block' => true,
                'condition' => array(
                    'enable_custom_title' => ['yes']
                  )
			]
        );
        
        $repeater->add_control('event_id',
            [
                'label'     => esc_html__( 'Select Event', 'quomodo-essential' ),
                'type'      => \Elementor\Controls_Manager::SELECT2,
                'multiple' => false,
                'options'   => $this->getEvents(),
                'show_label'  => true,
                'label_block' => true
            
            ]
      ); 
     
		$repeater->add_control(
			'enable_custom_link',
			[
				'label'        => esc_html__( 'Enable Custom Link', 'bisy-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Enable', 'bisy-essential' ),
				'label_off'    => esc_html__( 'Disable', 'bisy-essential' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
        );
        
        $repeater->add_control(
			'list_event_link', [
				'label'       => esc_html__( 'Custom Event Link', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::URL,
				
                'label_block' => true,
                'condition' => array(
                    'enable_custom_link' => ['yes']
                  )
               
			]
		);

        $repeater->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'Location Icon', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'icon_pin_alt',
                    'library' => 'solid',
                ],
			]
        );

        $repeater->add_control(
			'enable_custom_date',
			[
				'label'        => esc_html__( 'Enable Custom Date', 'bisy-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Enable', 'bisy-essential' ),
				'label_off'    => esc_html__( 'Disable', 'bisy-essential' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
        );

        $repeater->add_control(
			'list_due_date',
			[
				'label' => esc_html__( 'Event Date', 'bisy-essential' ),
                'type' => \Elementor\Controls_Manager::DATE_TIME,
                'condition' => array(
                    'enable_custom_date' => ['yes']
                  )
			]
		);

        $repeater->add_control(
			'list_location', [
				'label'      => esc_html__( 'Event Location', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( 'Vancouver, Canada' , 'bisy-essential' ),
				
			]
        );

        $repeater->add_control(
			'list_ticket_text', [
				'label'      => esc_html__( 'Ticket Text', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( 'Get Ticket' , 'bisy-essential' ),
				
			]
        );
        
        
        $repeater->add_control(
			'list_ticket_link', [
				'label'      => esc_html__( 'Ticket Url', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::URL,
               	
			]
        );
        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Events List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'left',
            
                'selectors' => [
                   
                     '{{WRAPPER}} .event-item-1' => 'text-align: {{VALUE}};',
               
				],
			]
        );//Responsive control end

        $this->end_controls_section();
      
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


        $this->add_control(
			'title_color', [

				'label'     => esc_html__( 'Color', 'bisy-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .title' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_control(
			'title_hover_color', [

				'label'     => esc_html__( 'hover Color', 'bisy-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .event-item-1:hover .title' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'title_typho',
                'label'    => esc_html__( 'Typography', 'bisy-essential' ),
              
                'selector' => '{{WRAPPER}} .title',
            ]
        );

        $this->add_responsive_control(
            'title_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

          //Location Style Section
		$this->start_controls_section(
			'section_date_style', [
				'label' => esc_html__( 'Date', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


            $this->add_control(
                'date_day_color', [

                    'label'     => esc_html__( 'day Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .e-date' => 'color: {{VALUE}};',
                    ],
                ]
            );
        
            $this->add_control(
                'date_day_hover_color', [

                    'label'     => esc_html__( 'Hover Day Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .event-item-1:hover .e-date' => 'color: {{VALUE}};',
                    ],
                ]
            );


            $this->add_responsive_control(
                'date_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .e-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'date_day_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .e-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            
            $this->add_control(
                'date_month_color', [

                    'label'     => esc_html__( 'Month Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .e-date span' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_control(
                'date_month_hover_color', [

                    'label'     => esc_html__( 'Hover Day Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .event-item-1:hover .e-date span' => 'color: {{VALUE}};',
                    ],
                ]
            );
        
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'date_month_typho',
                    'label'    => esc_html__( 'Month', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .e-date span',
                ]
            );

            $this->add_responsive_control(
                'date_month_section_margin',
                [
                    'label'      => esc_html__( 'Month Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .e-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();

          //Location Style Section
		$this->start_controls_section(
			'section_location_style', [
				'label' => esc_html__( 'Location', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


            $this->add_control(
                'location_color', [

                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .event-item-1 p' => 'color: {{VALUE}};',
                    ],
                ]
            );
        
            $this->add_control(
                'location_hover_color', [

                    'label'     => esc_html__( 'hover Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .event-item-1:hover p' => 'color: {{VALUE}};',
                    ],
                ]
            );
        
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'location_typho',
                    'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                  
                    'selector' => '{{WRAPPER}} .event-item-1 p',
                ]
            );

            $this->add_responsive_control(
                'location_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .event-item-1 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'location_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .event-item-1 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_location_icon_style', [
				'label' => esc_html__( 'Location Icon', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


            $this->add_control(
                'location_icon_color', [

                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .event-item-1 p i' => 'color: {{VALUE}};',
                    ],
                ]
            );
        
            $this->add_control(
                'location_icon_hover_color', [

                    'label'     => esc_html__( 'hover Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .event-item-1:hover p i' => 'color: {{VALUE}};',
                    ],
                ]
            );
        
            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'location_icon_typho',
                    'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .event-item-1 p i',
                ]
            );
            $this->add_responsive_control(
                'location_icon_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .event-item-1 p i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'location_icon_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .event-item-1 p i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'location_icon_top_position',
                [
                   'label'      => esc_html__( 'Position Top', 'bisy-essential' ),
                   'type'       => Controls_Manager::SLIDER,
                   'size_units' => [ 'px' ,'%' ],
                   'range'      => [
                      'px' => [
                         'min'  => -500,
                         'max'  => 800,
                         'step' => 1,
                      ],
                   
                   ],
                
                   'selectors' => [
                      '{{WRAPPER}} .event-item-1 p i' => 'top: {{SIZE}}{{UNIT}};',
                   ],
                ]
             );
             $this->add_responsive_control(
                'location_icon_left_position',
                [
                   'label'      => esc_html__( 'Position Left', 'bisy-essential' ),
                   'type'       => Controls_Manager::SLIDER,
                   'size_units' => [ 'px' ,'%' ],
                   'range'      => [
                      'px' => [
                         'min'  => -500,
                         'max'  => 800,
                         'step' => 1,
                      ],
                   
                   ],
                
                   'selectors' => [
                      '{{WRAPPER}} .event-item-1 p i' => 'left: {{SIZE}}{{UNIT}};',
                   ],
                ]
             );
        $this->end_controls_section();
      
        $this->start_controls_section('box_view_more_section',
                [
                    'label' => esc_html__( 'Ticket Button', 'bisy-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                   
                ]
        );

        $this->add_control(
			'view_more_color', [

				'label'     => esc_html__( 'Color', 'bisy-essential' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
                  '{{WRAPPER}} .ticket-btn' => 'color: {{VALUE}};',
				],
			]
        );
        
        $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
                'name'     => 'view_more_typho',
                'label'    => esc_html__( 'Typography', 'bisy-essential' ),
              
                'selector' => '{{WRAPPER}} .ticket-btn',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
            [
               'name'     => 'hover_overlay_background',
               'label'    => esc_html__( 'Background', 'bisy-essential' ),
               'types'    => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .ticket-btn',
            ]
         );

        $this->add_responsive_control(
            'view_more_section_margin',
            [
                'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ticket-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'view_more_section_padding',
            [
                'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ticket-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('box_section',
                [
                    'label' => esc_html__( 'Box', 'bisy-essential' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
         );

            $this->add_control('box_background_color',
            [
                'label'     => esc_html__( 'Background color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                     '{{WRAPPER}} .event-item-1' => 'background: {{VALUE}};',
                   ],
                ]
            );

            $this->add_control(
                'box_hv_background_heading1',
                [
                    'label' => esc_html__( 'Background Hover', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    
                ]
            );
            $this->add_control('box_hv_background_color',
            [
                'label'     => esc_html__( 'Background color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
               
                'selectors' => [
                      '{{WRAPPER}} .event-item-1:hover' => 'background: {{VALUE}};',
                            
                    ],
                ]
               
            );
            $this->add_group_control(
                Group_Control_Border:: get_type(),
                [
                    'name'     => 'box_border',
                    'label'    => esc_html__( 'Border', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .event-item-1',
                ]
            );


            $this->add_responsive_control(
                '_box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .event-item-1' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .event-item-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       ],
                ]
            );

            $this->add_responsive_control(
                'box_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .event-item-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .event-item-1',
                ]
            );

                           
            $this->add_control(
                'border_popover_toggle',
                [
                    'label' => esc_html__( 'Hover Border', 'bisy-essential' ),
                    'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                    'label_off' => esc_html__( 'Default', 'bisy-essential' ),
                    'label_on' => __( 'Over Top Color', 'bisy-essential' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->start_popover();

                $this->add_control(
                    'item_border_top_border', [

                        'label'     => esc_html__( 'Top Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .event-item-1:after' => 'border-top-color: {{VALUE}};',
                    
                        ],
                    ]
                );

                $this->add_control(
                    'item_border_bottom_border', [

                        'label'     => esc_html__( 'Bottom Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .event-item-1:after' => 'border-bottom-color: {{VALUE}};',
                    
                        ],
                    ]
                );

                $this->add_control(
                    'item_border_right_border', [

                        'label'     => esc_html__( 'Right Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .event-item-1:after' => 'border-right-color: {{VALUE}};',
                    
                        ],
                    ]
                );

                $this->add_control(
                    'item_border_left_border', [

                        'label'     => esc_html__( 'Left Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .event-item-1:after' => 'border-left-color: {{VALUE}};',
                    
                        ],
                    ]
                );

            $this->end_popover();


        $this->end_controls_section();
        // main section
        $this->start_controls_section('bisy_box__main_section',
            [
            'label' => esc_html__( 'Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_control(
			'enable_main_container',
			[
				'label'        => esc_html__( 'Main container', 'bisy-essential' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Enable', 'bisy-essential' ),
				'label_off'    => esc_html__( 'Disable', 'bisy-essential' ),
				'return_value' => 'yes',
				'default'      => '',
			]
        );

        $this->add_control(
            'column',
            [
                'label' => esc_html__( 'Column', 'bisy-essential' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '6', 
                'options' => [
                    '6'    => esc_html__( '6 Column', 'bisy-essential' ),
                    '4'    => esc_html__( '4 Column', 'bisy-essential' ),
                    '10'    => esc_html__( '10 Column', 'bisy-essential' ),
                    '12'   => esc_html__( 'Full width', 'bisy-essential' ),
                
                ],
            ]
        );

         $this->add_group_control(
           \Elementor\Group_Control_Background:: get_type(),
           [
              'name'     => 'main_section_background',
              'label'    => esc_html__( 'Background', 'bisy-essential' ),
              'types'    => [ 'classic', 'gradient', 'video' ],
              'selector' => '{{WRAPPER}} .main-section',
           ]
        );
       
       $this->add_responsive_control(
        'main_box_margin',
           [
              'label'      => esc_html__( 'Margin', 'bisy-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
              ],
           ]
        );

        $this->add_responsive_control(
           'main_box_padding',
           [
              'label'      => esc_html__( 'Padding', 'bisy-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px','%'],
              'selectors'  => [
                 '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
              ],
           ]
        );

     $this->end_controls_section();

    
    } //Register control end

    public function getEvents(){
      
        $_list = [];
        $args = array(
              'numberposts'      => -1,
              'orderby'          => 'post_date',
              'order'            => 'DESC',
              'post_type'        => 'bisy-events',
              'post_status'      => 'publish',
              'suppress_filters' => false
        );
  
        $posts = get_posts($args);
   
        if($posts):
         // Loop the posts
           foreach ($posts as $_post):
             $_list[$_post->ID] = $_post->post_title; 
           endforeach;
        endif;
  
        return $_list;
  
    }
    protected function render( ) { 

		$settings = $this->get_settings();
		$list        = $settings['list'];
	
    ?>
        <div class="main-section <?php echo esc_attr($settings['enable_main_container'] == 'yes'?'container':''); ?>">
            <div class="row">
                <?php foreach ($list as $key => $item): ?>
                    <div class="col-md-<?php echo esc_attr($settings['column']); ?>">
                        <div class="event-item-1">
                            <div class="e-date">
                                 <?php if( $item['enable_custom_date'] == 'yes' ): ?>
                                    <?php echo date( 'd', strtotime($item['list_due_date']) ); ?> <span><?php echo date( 'M', strtotime($item['list_due_date']) ); ?></span>
                                 <?php else: ?>
                                    <?php echo get_the_date( 'd' ); ?> <span><?php echo get_the_date( 'M' ); ?></span>
                                 <?php endif; ?>
                            </div>
                            <p>
                                <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php echo esc_html($item['list_location']); ?>
                            </p>
                            <?php if($item['enable_custom_link'] == 'yes'): ?>
                                <?php $event_link =  $item['list_event_link']; ?>
                                <h4 class="title">
                                <a target="<?php echo esc_attr( $event_link['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($event_link['url']) ?>"> 
                                        <?php if( $item['enable_custom_title'] == 'yes' ): ?>
                                            <?php echo esc_html( $item['list_title'] ); ?>
                                        <?php else: ?>
                                            <?php echo esc_html(get_the_title($item['event_id'])); ?>
                                        <?php endif; ?>
                                    </a>
                                </h4>
                            <?php else: ?>
                                <h4 class="title">
                                    <a href="<?php echo esc_url( get_the_permalink( $item['event_id'] ) ); ?>"> 
                                    <?php if( $item['enable_custom_title'] == 'yes' ): ?>
                                            <?php echo esc_html( $item['list_title'] ); ?>
                                        <?php else: ?>
                                            <?php echo esc_html(get_the_title($item['event_id'])); ?>
                                        <?php endif; ?>
                                    </a>
                                </h4>
                            <?php endif; ?>
                            <?php if($item['list_ticket_text'] !=''): ?>
                                <?php $button_url =  $item['list_ticket_link']; ?>
                                <a target="<?php echo esc_attr( $button_url['is_external'] =='on'?'_blank':'_self' ); ?>"  href="<?php echo esc_url($button_url['url']) ?>" class="bisylms-btn ticket-btn"> <?php echo esc_html($item['list_ticket_text']); ?> </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?> 
            </div>
        </div>
      
    <?php  

    }
    
    protected function _content_template() { }
}