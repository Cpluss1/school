<?php 
/**
 * @package  bisy-essential
 */
namespace BisyEssential\Base;

use BisyEssential\Base\BaseController;
use Carbon_Fields\Container;
use Carbon_Fields\Field;
use BisyEssential\Api\Serialized_Theme_Options_Datastore;
/**
*  Theme Settings Options
*/
class ThemeOption extends BaseController
{
	public function register() {
        // admin
        
        add_action( 'carbon_fields_register_fields', array( $this, 'essential_attach_p_options' ) );
        add_action( 'carbon_fields_register_fields', array( $this, 'event_cpt_settings' ) );
        //add_action( 'carbon_fields_register_fields', array( $this, 'user_meta' ) );
     
        
    }
    public function user_meta(){

        Container::make( 'user_meta', esc_html__('Social Share','bisy-essential') )
            ->add_fields( array(
                Field::make( 'complex', 'bisy_user_social_share', esc_html__( 'Social Share','bisy-essential' ) )
                ->add_fields( array(
                    Field::make( 'text', 'title', esc_html__( 'Title','bisy-essential' ) ),
                    Field::make( 'text', 'url', esc_html__( 'Url','bisy-essential' ) ),
                    Field::make( 'icon', 'social_site_icon', esc_html__( 'Icon', 'bisy-essential' ) )
                        ->add_fontawesome_options(),
                ) )
            ) );
    }
    public function event_cpt_settings(){

        Container::make( 'theme_options', esc_html__('Settings','bisy-essential') )
        ->set_page_parent( 'edit.php?post_type=bisy-events' ) 
        ->add_fields( array(
            Field::make( 'text', 'cpt_event_name' , esc_html__('Name','bisy-essential')),
            Field::make( 'text', 'cpt_event_menu_name' , esc_html__('Menu Name','bisy-essential')),
            Field::make( 'text', 'cpt_event_slug', esc_html__('Slug','bisy-essential') ),
            Field::make( 'checkbox', 'cpt_event_search', esc_html__('Public Search','bisy-essential') ),
            Field::make( 'checkbox', 'cpt_event_query', esc_html__('Public Query','bisy-essential') ),
        
        ) );

    }
	public function essential_attach_p_options() {
    
        Container::make( 'post_meta', 'Tranding' )
        ->where( 'post_type', '=', 'post' )
        ->set_context( 'side' )
        ->set_priority('high')
        ->add_fields( array(
            Field::make( 'select', 'bisy_trending', __( 'Choose Options' ) )
                ->set_options( 
                    array(
                    'no'  => esc_html__( 'No', 'bisy-essential' ),
                    'yes' => esc_html__( 'Yes', 'bisy-essential' ),
                
                ) 
            ),
           
        ));
    }
}