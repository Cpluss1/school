<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit;

class Membership extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-membership';
    }

    public function get_title() {
        return esc_html__( 'Bisy Membership', 'bisy-essential' );
    }
    
    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Membership settings', 'bisy-essential'),
            ]
        );
         
        $this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Style', 'bisy-essential' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => esc_html__( 'Style 1', 'bisy-essential' ),
					'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
				],
			]
        );
        
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label'       => esc_html__( 'Title', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Membership Title' , 'bisy-essential' ),
				'label_block' => true,
			]
        );
        
        $repeater->add_control(
			'list_content', [
				'label'      => esc_html__( 'Course Content', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( "He nicked it I don't want no agro what a load of rubbish chancer." , 'bisy-essential' ),
				'show_label' => true,
			]
        );
        
        $repeater->add_control(
            'list_image',
            [
                'label' => esc_html__( 'Thumbnail', 'bisy-essential' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );
     
		$repeater->add_control(
			'list_price', [
				'label'      => esc_html__( 'Price', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '250' , 'bisy-essential' ),
				'show_label' => true,
			]
        );
        
        $repeater->add_control(
			'list_sale_price', [
				'label'      => esc_html__( 'Sale Price', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '200' , 'bisy-essential' ),
				'show_label' => true,
			]
        );

        $repeater->add_control(
			'list_duration', [
				'label'      => esc_html__( 'Course Duration', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( ' / 2 years' , 'bisy-essential' ),
				'show_label' => true,
			]
		);
          
        $repeater->add_control(
			'list_button_text', [
				'label'      => esc_html__( 'Button Link', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( 'Apply Now' , 'bisy-essential' ),
				'show_label' => true,
			]
        );

        $repeater->add_control(
			'list_button_link', [
				'label'      => esc_html__( 'Course Link', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '#' , 'bisy-essential' ),
				'show_label' => true,
			]
        );

        
        
        $repeater->add_control(
			'list_total_lessons', [
				'label'      => esc_html__( 'Total Lessons', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '30' , 'bisy-essential' ),
				'show_label' => true,
			]
        );
        
        $repeater->add_control(
			'list_total_class', [
				'label'      => esc_html__( 'Total class', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '10' , 'bisy-essential' ),
				'show_label' => true,
			]
        );
        

        $repeater->add_control(
            'list_icon',
            [
                'label' => esc_html__( 'Choose Logo Icon', 'bisy-essential' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );
       
		$this->add_control(
			'list',
			[
				'label'       => esc_html__( 'Counter List', 'plugin-domain' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ list_title }}}',
			]
		);
 
        $this->add_responsive_control(
			'content_align', [
				'label'   => esc_html__( 'Content Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
             
                'selectors' => [
                     '{{WRAPPER}} .pack-details' => 'text-align: {{VALUE}};',
                  

				],
			]
        );//Responsive control end

        $this->add_responsive_control(
			'lesson_align', [
				'label'   => esc_html__( 'Meta Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'flex-start'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'flex-end'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
			
				],
             
                'selectors' => [
                     '{{WRAPPER}} .pack-meta' => 'justify-content: {{VALUE}};',
              	],
			]
        );//Responsive control end

        $this->add_responsive_control(
			'image_max_width',
			[
				'label' => esc_html__( 'Image Max Width', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'inherit',
				'options' => [
					'fit-content' => esc_html__( 'Fit Content', 'bisy-essential' ),
					'max-content' => esc_html__( 'Max Content', 'bisy-essential' ),
					'min-content' => esc_html__( 'Min Content', 'bisy-essential' ),
					'100%'        => esc_html__( '100%', 'bisy-essential' ),
					'inherit'     => esc_html__( 'Default', 'bisy-essential' ),
					'none'        => esc_html__( 'None', 'bisy-essential' ),
					
                ],
                'selectors' => [
                    '{{WRAPPER}} .pack-thumb img' => 'max-width: {{VALUE}};',
                 ],
			]
        );
        

        $this->end_controls_section();
       
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                    
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //content Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .content' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .content',
                    ]
                );

              
                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_price_style', [
				'label' => esc_html__( 'Price', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'price_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .pack-price' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_control(
                    'origin_price_color', [

                        'label'     => esc_html__( 'Orginal Price Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .pack-price span' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'price_typho',
                        'label'    => esc_html__( 'Price Fonts', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .pack-price , {{WRAPPER}} .pack-price span',
                    ]
                );
                

              
                $this->add_responsive_control(
                    'price_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pack-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'price_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pack-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        
        $this->start_controls_section(
			'section_lesson_class_style', [
				'label' => esc_html__( 'Lesson & class', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );


                $this->add_control(
                    'lesson_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .pack-meta span' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'pack_meta_typho',
                        'label'    => esc_html__( 'Fonts', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .pack-meta span',
                    ]
                );

                $this->add_control(
                    'pack_metaicon_color', [

                        'label'     => esc_html__( 'Icon Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .pack-meta span i' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
               

                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'pack_meta_icon_typho',
                        'label'    => esc_html__( 'Icon Typhography', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .pack-meta span i',
                    ]
                );
                

              
                $this->add_responsive_control(
                    'pack_meta_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pack-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'pack_meta_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pack-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        
        $this->start_controls_section('bisy_item_button_section',
            [
            'label' => esc_html__( 'Button', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

                
                $this->add_control(
                    'button_text_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .bisylms-btn' => 'color: {{VALUE}};',
                    
                        ],
                    ]
                );
    
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'button__typho',
                        'label'    => esc_html__( 'Typhography', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .bisylms-btn',
                    ]
                );
        
                $this->add_responsive_control(
                    'button_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .bisylms-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .bisylms-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'button_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%' ],
                        'selectors' => [
                            '{{WRAPPER}} .bisylms-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'button_item_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .bisylms-btn',
                        ]
                );


        $this->end_controls_section();

        $this->start_controls_section('bisy_item_button_hover_section',
            [
            'label' => esc_html__( 'Button Hover', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

            
            $this->add_control(
                'button_hover_text_color', [

                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                    '{{WRAPPER}} .bisylms-btn:hover' => 'color: {{VALUE}};',
                
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography:: get_type(),
                [
                    'name'     => 'button_hover_typho',
                    'label'    => esc_html__( 'Typhography', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .bisylms-btn:hover',
                ]
            );
    
            $this->add_responsive_control(
                'button_hover_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .bisylms-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                'button_hover_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .bisylms-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );


            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'button_hover_item_section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .bisylms-btn:hover',
                    ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'button_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .bisylms-btn:hover',
                ]
            );


    $this->end_controls_section();

        $this->start_controls_section('bisy_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item / details', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

                $this->add_responsive_control(
                    '_item_content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pack-details' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        ],
                        'separator' => 'before',
                    ]
                );
                
                $this->add_responsive_control(
                    '_item_content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .pack-details' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );   

                $this->add_responsive_control(
                    '_item__box_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%' ],
                        'selectors' => [
                            '{{WRAPPER}} .pack-details' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => '_item_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .pack-details',
                        ]
                );


        $this->end_controls_section();

        

        $this->start_controls_section('bisy_inner_main_box',
                [
                'label' => esc_html__( 'Box', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'inner_main_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .package-item',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'inner_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .package-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'inner_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .package-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                  

                   
        $this->end_controls_section();

        $this->start_controls_section('bisy_main_section',
            [
                'label' => esc_html__( 'Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
    
            $this->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'main_section_background',
                    'label'    => esc_html__( 'Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .pack-slider.slick-slider',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'main__box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .pack-slider.slick-slider',
                ]
            );

            $this->add_responsive_control(
            'section_box_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );

            $this->add_responsive_control(
            'section_box_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px','%'],
                    'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'main_section_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .main-section',
                ]
            );
            $this->add_responsive_control(
                'main_item__box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .main-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .package-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                        
                    ],
                    'separator' => 'before',
                ]
            );
       $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings = $this->get_settings();
		$list     = $settings['list'];
	    
    ?>

       <!-- Package Start -->
  
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div id="pack-slider" class="pack-slider main-section">
                            <?php foreach($list as $item): ?>
                                <?php

                                    $image = $item['list_image'];
                                    $icon  = $item['list_icon'];
                                
                                ?>
                                <div class="package-item">
                                    <?php if($image['url'] !='' || $icon['url'] !=''): ?>
                                        <div class="pack-thumb">
                                            <?php if($image['url'] !=''): ?>
                                            <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($item['list_title']); ?>">
                                            <?php endif; ?>
                                            <?php if( $icon['url'] !='' ): ?>
                                                <div class="pack-middle">
                                                    <img src="<?php echo esc_url($icon['url']); ?>" alt="<?php echo esc_attr($item['list_title']); ?>">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="pack-details">
                                        <div class="pack-price">
                                          <?php if($item['list_price'] !=''): ?>
                                            <span><?php echo esc_html($item['list_price']); ?></span> 
                                          <?php endif; ?>
                                           <?php echo esc_html($item['list_sale_price']); ?> <?php echo esc_html($item['list_duration']); ?></div>
                                        <h3 class="title"><?php echo esc_html($item['list_title']); ?></h3>
                                        <div class="pack-meta">
                                             <?php if($item['list_total_lessons'] !=''): ?>
                                                <span class="bisy-lessons"><i class="icon_book_alt"></i> <?php echo esc_html($item['list_total_lessons']); ?> </span>
                                            <?php endif; ?>
                                            <?php if($item['list_total_class'] !=''): ?>
                                                <span class="bisy-total-class"><i class="icon_toolbox_alt"></i><?php echo esc_html($item['list_total_class']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($item['list_content'] !=''): ?>
                                            <p class="content">
                                               <?php echo esc_html($item['list_content']); ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if($item['list_button_text'] !=''): ?>
                                            <a href="<?php echo esc_html($item['list_button_link']); ?> " class="bisylms-btn"> <?php echo esc_html($item['list_button_text']); ?> </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>


    <?php  

    }
    
    protected function _content_template() { }
}