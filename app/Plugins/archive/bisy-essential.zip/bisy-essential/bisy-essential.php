<?php
/*
* Plugin Name: Bisy Essentials
* License - GNU/GPL V2 or Later
* Description: This is a essential plugin for Bisy theme.
* Version: 1.4
* text domain: bisy-essential
*/

// If this file is calledd directly, abort!!!
defined( 'ABSPATH' ) or die( 'Hey, what are you doing here? You silly human!' );

// Require once the Composer Autoload
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}
// Require option library
if ( file_exists( dirname( __FILE__ ) . '/app/Framework/codestar-framework.php' ) ) {
	require_once dirname( __FILE__ ) . '/app/Framework/codestar-framework.php';
}

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/** 
 * plugin constant
 */
define( 'QTRP', true );
define( 'BISY_ESSENTIAL_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'BISY_ESSENTIAL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BISY_ESSENTIAL_PLUGIN', plugin_basename( dirname( __FILE__ ) ) . '/bisy-essential.php');
define( 'BISY_ESSENTIAL_IMG', get_template_directory_uri() . '/assets/images');
define( 'BZOOM_API_URL' , 'https://api.zoom.us/v2/');


/**
 * The code that runs during plugin activation
 */

add_action( 'plugins_loaded', 'bisy_essential_crb_load' );
function bisy_essential_crb_load() {
	\Carbon_Fields\Carbon_Fields::boot();
}

function bisy_activate_essential_plugin() {
	BisyEssential\Base\Activate::activate();
}

register_activation_hook( __FILE__, 'bisy_activate_essential_plugin' );

/**
 * The code that runs during plugin deactivation
 */

function bisy_deactivate_essential_plugin() {
	BisyEssential\Base\Deactivate::deactivate();
}
register_deactivation_hook( __FILE__, 'bisy_deactivate_essential_plugin' );

/**
 * Initialize all the core classes of the plugin
 */
if ( class_exists( 'BisyEssential\\Init' ) ) {
	
	BisyEssential\Init::register_services();
	BisyEssential\Init::register_modules();
}

