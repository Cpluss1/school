<?php 
/**
 * @package  bisy-essential
 */
namespace BisyEssential\Base;
use BisyEssential\Base\BaseController;

/**
* zoom
*/
class Zoom extends BaseController
{
	public function register() {
		// admin
		//add_action( 'admin_init', array( $this, 'get_users_meetings' ) );
		//add_action( 'admin_init', array( $this, 'create_meeting' ) );
		
	}
	
	function get_users_meetings() {

        $token = bisy_option('zoom_token');
		$wp_request_headers = array(
			'Authorization' => 'Bearer '.$token,
			'content-type' => 'application/json'
		);
		
		$wp_request_url = 'https://api.zoom.us/v2/users?status=active&page_size=50&page_number=1';
		
		$_response = wp_remote_request(
			$wp_request_url,
			array(
				'method'    => 'GET',
				'headers'   => $wp_request_headers
			)
		);

        $response_status = wp_remote_retrieve_response_message( $_response ); 
		$response_code =  wp_remote_retrieve_response_code( $_response );
		$response_content =  wp_remote_retrieve_body( $_response );
		if($response_code == 200){
			fw_print($response_content);
		}
		
	}

	public function create_meeting(){
		$token = bisy_option('zoom_token');
		$wp_request_headers = array(
			'Authorization' => 'Bearer '.$token,
			'content-type' => 'application/json'
		);
		
		$wp_request_url = 'https://api.zoom.us/v2/users/me/meetings';
		
		$_response = wp_remote_request(
			$wp_request_url,
			array(
				'method'    => 'POST',
				'headers'   => $wp_request_headers,
				'json' => [
					"topic" => "Let's learn Laravel",
					"type" => 2,
					"start_time" => "2021-08-05T20:30:00",
					"duration" => "30", // 30 mins
					"password" => "123456"
				],
			)
		);

        $response_status = wp_remote_retrieve_response_message( $_response ); 
		$response_code =  wp_remote_retrieve_response_code( $_response );
		$response_content =  wp_remote_retrieve_body( $_response );
		
		if($response_code == 200){
			fw_print($response_content);
		}	
	}

	
}