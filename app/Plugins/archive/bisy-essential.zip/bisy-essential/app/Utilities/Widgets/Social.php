<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {
  
    //
    // Create a about widget
    //
    CSF::createWidget( 'bisy_essential_social', array(
      'title'       => esc_html__('Bisy Social','bisy-essential'),
      'classname'   => 'about-widget social',
      'description' => esc_html__('Social','bisy-essential'),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   => esc_html__('Title','bisy-essential'),
        ),
  

        array(
            'id'     => 'social_list',
            'type'   => 'repeater',
            'title'  => esc_html__('Social List','bisy-essential'),
            'fields' => array(
          
                array(
                    'id'    => 'social_icon',
                    'type'  => 'icon',
                    'title' => esc_html__('Icon','bisy-essential'),
                ),
                array(
                    'id'      => 'social_url',
                    'type'    => 'text',
                    'title'   => esc_html__('Url','bisy-essential'),
                  ),
          
            ),
          ),
          
  
      )
    ) );
     
    if( ! function_exists( 'bisy_essential_social' ) ) {
      function bisy_essential_social( $args, $instance ) {
  
        echo $args['before_widget'];
  
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
     
        ?>
           
                <?php if(is_array($instance['social_list'])): ?>
                  <div class="ab-social">
                    <?php foreach($instance['social_list'] as $item): ?>
                      <a class="fac" href="<?php echo esc_url($item['social_url']); ?>"><i class="<?php echo esc_attr($item['social_icon']); ?>"></i></a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
            

        <?php
  
        echo $args['after_widget'];
  
      }
    }
  
  }
  