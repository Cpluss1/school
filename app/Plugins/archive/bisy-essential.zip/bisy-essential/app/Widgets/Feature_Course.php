<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class Feature_Course extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-feature-course-grid';
    }

    public function get_title() {
        return esc_html__( 'Feature Course', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'fa fa-flag-o';
    }

    public function get_keywords() {
      return [ 'feature', 'course', 'sale' ];
    }

    public function get_categories() {

        return [ 'bisy-elements' ];
    }

    	// Get list courses category
      public function course_category(){

        if(!defined('LP_COURSE_CPT')){
          return [];
        }
        
        $tax_terms = get_terms('course_category', array('hide_empty' => false));
        $category_list = [];
         
        foreach($tax_terms as $term_single) {      
          $category_list[$term_single->term_id] = [$term_single->name];
         
        }
        
        return $category_list;
        }

    protected function _register_controls() {

     

      $this->start_controls_section(
        'content',
        [
          'label' => esc_html__( 'Feature Courses', 'bisy-essential' )
        ]
      );
  

          $this->add_control(
            'layout',
            [
              'label'   => esc_html__( 'Layout', 'bisy-essential' ),
              'type'    => Controls_Manager::SELECT,
              'options' => [
                'style1'         => esc_html__( 'Style 1', 'bisy-essential' ),
              
              ],
              'default' => 'style1'
            ]
          );
  
          $this->add_control(
            'order',
            [
              'label'   => esc_html__( 'Order By', 'bisy-essential' ),
              'type'    => Controls_Manager::SELECT,
              'options' => [
                'popular'  => esc_html__( 'Popular', 'bisy-essential' ),
                'latest'   => esc_html__( 'Latest', 'bisy-essential' ),
              ],
              'default' => 'latest',
              'condition' => array(
                'layout' => ['style1', 'tabs']
              )
            ]
          );
   
          $this->add_control(
            'limit',
            [
              'label'   => esc_html__( 'Limit Number of Courses', 'bisy-essential' ),
              'type'    => Controls_Manager::NUMBER,
              'default' => 8,
              'min'     => 1,
              'step'    => 1,
              'condition' => array(
                'layout' => ['style1', 'tabs']
              )
            ]
          );
  
          $this->add_control(
            'cat_id',
            [
              'label'     => esc_html__( 'Select Category', 'bisy-essential' ),
              'type'      => Controls_Manager::SELECT2,
              'options'   => $this->course_category(),
              'multiple'    => true,
              'default'     => 'all',
              'condition' => array(
                'layout' => ['style1']
              )
            ]
          );

          $this->add_control(
            'course_list',
            [
              'label'     => esc_html__( 'Select course', 'bisy-essential' ),
              'type'      => Controls_Manager::SELECT,
              'options'   => $this->course_list(),
              'condition' => array(
                'layout' => ['grid-single']
              )
            ]
          );

          $this->add_control(
            'course_tags_list',
            [
              'label'     => esc_html__( 'Select Tags', 'bisy-essential' ),
              'type' => \Elementor\Controls_Manager::SELECT2,
              'multiple' => true,
              'options'  => bisy_get_post_category('course_tag'),
              
            ]
          );

            $this->add_control(
              'featured',
              [
                'label'        => esc_html__( 'Display Featured Courses?', 'bisy-essential' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                'return_value' => 'yes',
                'default'      => '',
                'condition' => array(
                  'layout' => ['style1', 'tabs']
                )
              ]
            );
  
     
          $this->add_control(
              'course_rating_show',
              [
                  'label'        => esc_html__( 'Rating', 'bisy-essential' ),
                  'type'         => Controls_Manager::SWITCHER,
                  'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                  'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                  'return_value' => 'yes',
                  'default'      => 'yes',
                  'condition' => array(
                    'layout' => ['style1', 'tabs']
                  )
              ]
          );

          $this->add_control(
            'show_content',
            [
                'label'        => esc_html__( 'Show Content', 'bisy-essential' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition' => array(
                  'layout' => ['style1', 'tabs']
                )
            ]
        );

        $this->add_control(
          'content_limit',
          [
            'label'   => esc_html__( 'Content Limit', 'bisy-essential' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 8,
            'min'     => 1,
            'step'    => 1,
            'condition' => array(
              'show_content' => ['yes']
            )
          ]
        );

        $this->add_control(
          'show_author',
          [
              'label'        => esc_html__( 'Show Author', 'bisy-essential' ),
              'type'         => Controls_Manager::SWITCHER,
              'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
              'label_off'    => esc_html__( 'No', 'bisy-essential' ),
              'return_value' => 'yes',
              'default'      => 'yes',
              'condition' => array(
                'layout' => ['style1', 'tabs']
              )
          ]
        );

        $this->add_control(
          'image_type',
          [
            'label' => esc_html__( 'Front Image Type', 'bisy-essential' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'feature',
            'options' => [
              'feature'  => esc_html__( 'Feature Image', 'bisy-essential' ),
              'course' => esc_html__( 'Course Image', 'bisy-essential' ),
              'icon' => esc_html__( 'Icon Image', 'bisy-essential' ),
          
            ],
          ]
        );

        $this->add_control(
          'background_shape',
          [
              'label' => esc_html__( 'Background Shape', 'bisy-essential' ),
              'type'  => \Elementor\Controls_Manager::MEDIA,
          ]
        );
     
      $this->end_controls_section();


  
      $this->start_controls_section(
        'tab-options',
        [
          'label'     => esc_html__( 'Tab Options', 'bisy-essential' ),
          'condition' => array(
            'layout' => [ 'tabs' ]
          )
        ]
      );
  
      $this->add_control(
        'limit_tab',
        [
          'label'   => esc_html__( 'Limit Items Per Tab', 'bisy-essential' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 4,
          'min'     => 1,
          'step'    => 1
        ]
      );
  
      $this->add_control(
        'cat_id_tab',
        [
          'label'       => esc_html__( 'Select Category Tabs', 'bisy-essential' ),
          'label_block' => true,
          'type'        => Controls_Manager::SELECT2,
          'options'     => $this->course_category(),
          'multiple'    => true,
          'default'     => 'all'
        ]
      );
  
      $this->end_controls_section();



     
      $this->start_controls_section(
        'title_style', [
          'label'	 => esc_html__( 'Course Title', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'title_color', [
            'label'		 => esc_html__( 'Title color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .fci-details .title a' => 'color: {{VALUE}};',
              '{{WRAPPER}} .fci-details .title' => 'color: {{VALUE}};',
            ],
          ]
        );

        $this->add_control(
          'title_hover_color', [
            'label'		 => esc_html__( 'Title hover color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .fci-details .title:hover a' => 'color: {{VALUE}};',
             
            ],
          ]
        );
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'title_typography',
          'selector'	 => '{{WRAPPER}} .fci-details .title a',
          ]
        );
   
        $this->add_responsive_control(
          'title_margin',
          [
            'label' => esc_html__( 'Title margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .fci-details .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
            ],
          ]
        );

        $this->add_responsive_control(
          'title_back_padding',
          [
            'label' => esc_html__( 'Padding', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .fci-details .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              
            ],
          ]
        );

        
      
      $this->end_controls_section();


      $this->start_controls_section(
        'category_meta_style', [
          'label'	 => esc_html__( 'Category', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          '_category_meta_color', [
            'label'		 => esc_html__( 'Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .fci-details .c-cate' => 'color: {{VALUE}};',
             
            
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'category_meta_typography',
          'selector'	 => '{{WRAPPER}} .fci-details .c-cate',
          ]
        );  

        $this->add_control(
          'category_icon_color', [
            'label'		 => esc_html__( 'icon Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .fci-details .c-cate i' => 'color: {{VALUE}};',
            ],
          ]
        );
  
          
          $this->add_responsive_control(
            'category_margin',
            [
              'label' => esc_html__( 'Margin', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .fci-details .c-cate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
              ],
            ]
          );

          $this->add_responsive_control(
            'category_padding',
            [
              'label' => esc_html__( 'Padding', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .fci-details .c-cate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
              ],
            ]
          );

      $this->end_controls_section();

      $this->start_controls_section(
        'price_meta_style', [
          'label'	 => esc_html__( 'Price', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );
      
            $this->add_control(
              'price_meta_color', [
                'label'		 => esc_html__( 'Price Color', 'bisy-essential' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
               
                  '{{WRAPPER}} .course-price span' => 'color: {{VALUE}};',
                
                ],
              ]
            );

            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => 'price__meta_typography',
              'selector'	 => '{{WRAPPER}} .course-price span',
              ]
            );

            $this->add_control(
              'sale_price_color', [
                'label'		 => esc_html__( 'Sale Price Color', 'bisy-essential' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
                 
                  '{{WRAPPER}} .course-price' => 'color: {{VALUE}};',
                
                ],
              ]
            );
      
            
            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => 'sale_price_meta_typography',
              'selector'	 => '{{WRAPPER}} .course-price',
              ]
            );


            $this->add_responsive_control(
              'price_margin',
              [
                'label' => esc_html__( 'Margin', 'bisy-essential' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                 
                  '{{WRAPPER}} .course-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

            $this->add_responsive_control(
              'price_padding',
              [
                'label' => esc_html__( 'Padding', 'bisy-essential' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                 
                  '{{WRAPPER}} .course-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

      $this->end_controls_section();
     
     
      $this->start_controls_section(
        'instructor_style', [
          'label'	 => esc_html__( 'Instructor', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'instructor_color', [
            'label'		 => esc_html__( 'Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .author a' => 'color: {{VALUE}};',
            ],
          ]
        );
  
         
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
          'name'		 => 'instructor_title_typography',
          'selector'	 => '{{WRAPPER}} .author a',
          ]
        );

        $this->add_responsive_control(
          'instructor_margin',
          [
            'label' => esc_html__( 'Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_padding',
          [
            'label' => esc_html__( 'Padding', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_name_margin',
          [
            'label' => esc_html__( 'Name Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );


      $this->end_controls_section();

      $this->start_controls_section(
        'course_rating', [
          'label'	 => esc_html__( 'Course Rating', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

         
          $this->add_control(
            'course_icon_rating_color_', [
              'label'		 => esc_html__( 'Icon Color ', 'bisy-essential' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings i' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            Group_Control_Typography::get_type(), [
              'name'		 => 'rating_icon_typography',
              'selector'	 => '{{WRAPPER}} .ratings i',
              ]
            );

          $this->add_control(
            'course_rating_color_', [
              'label'		 => esc_html__( 'Color', 'bisy-essential' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings span' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            Group_Control_Typography::get_type(), [
              'name'		 => 'rating_typography',
              'selector'	 => '{{WRAPPER}} .ratings span',
              ]
            );

          $this->add_responsive_control(
            'course_rating_margin',
            [
              'label'      => esc_html__( 'Margin', 'bisy-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                '{{WRAPPER}} .ratings' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'course_rating_padding',
            [
              'label' => esc_html__( 'Padding', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .ratings' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

      $this->end_controls_section();
      
      $this->start_controls_section(
        'course_single_box', [
          'label'	 => esc_html__( 'Single Box', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

      $this->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'single_box_item_background',
                'label'    => esc_html__( 'Background', 'bisy-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .feature-course-item-3',
            ]
       );

       $this->add_group_control(
        \Elementor\Group_Control_Border::get_type(),
        [
          'name' => 'course_single_item_border_',
          'label' => esc_html__( 'Border', 'bisy-essential' ),
          'selector' => '{{WRAPPER}} .feature-course-item-3',
        ]
      );
  
       $this->add_responsive_control(
        '_item__box_border_radius',
        [
            'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors' => [
                '{{WRAPPER}} .feature-course-item-3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
             ],
            'separator' => 'before',
        ]
      );

      $this->add_control(
        'single_border2_popover_toggle',
        [
            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => esc_html__( 'Default', 'bisy-essential' ),
            'label_on' => __( 'Over Top Color', 'bisy-essential' ),
            'return_value' => 'yes',
            'default' => 'yes',
            'condition' => array(
              'layout' => ['style1']
            )
            
        ]
    );

    $this->start_popover();
        $this->add_control(
            'item_border_top_border', [

                'label'     => esc_html__( 'Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  '{{WRAPPER}} .feature-course-item-3' => 'box-shadow: 0px 20px 50px 0px {{VALUE}};',
            
                ],
            ]
        );

          $this->add_group_control(
              \Elementor\Group_Control_Box_Shadow::get_type(),
              [
                  'name' => 'item_border_top_box_hover_shadow',
                  'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                  'selector' => '{{WRAPPER}} .feature-course-item-3',
              ]
          );

          $this->end_popover();

          $this->add_group_control(
              \Elementor\Group_Control_Box_Shadow::get_type(),
              [
                  'name' => 'item_border_top_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                  'selector' => '{{WRAPPER}} .feature-course-item-3',
                
              ]
          );

          $this->add_responsive_control(
            'single_item_box_padding',
            [
              'label' => esc_html__( 'Padding', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .feature-course-item-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        
              ],
            ]
          );

          $this->add_responsive_control(
            'single_item_box_margin',
            [
              'label' => esc_html__( 'Margin', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .feature-course-item-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
             
              ],
            ]
          );

          

          $this->add_control(
            'single_item_',
            [
              'label' => esc_html__( 'Course Detail Background', 'bisy-essential' ),
              'type' => \Elementor\Controls_Manager::HEADING,
              'separator' => 'before',
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'single_hover_box_item_background',
                    'label'    => esc_html__( 'Hover Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .fci-details',
                ]
           );


      $this->end_controls_section();
 
     
    }    
    protected function render() {
   
      $settings   = $this->get_settings();
      $slide_controls   = bisy_widgets_slider_controls_setttings($settings);
      $course_settings = array(
       
        'order'             => $settings['order'],
        'cat_id'            => $settings['cat_id'],
        'course_list'       => $settings['course_list'],
        'layout'            => $settings['layout'],
        'limit'             => $settings['limit'],
        'tabs-options'      => array(
          'limit_tab'  => $settings['limit_tab'],
          'cat_id_tab' => $settings['cat_id_tab']
        ),
        'featured'          => $settings['featured'],
        'all_category' => $this->course_category()
      );

      $category_groups = []; 

      if(defined('LP_COURSE_CPT')){

         global $post, $wpdb;
         $random    = rand( 1, 99 );
        
         $cat_id    = $course_settings['cat_id'] ? $course_settings['cat_id'] : array();
         $limit     = $course_settings['limit'];
         $featured  = ! empty( $course_settings['featured'] ) ? true : false;
         $sort      = $course_settings['order'];
         $thumb_w   = ( ! empty( $course_settings['thumbnail_width'] ) && '' != $course_settings['thumbnail_width'] ) ? $course_settings['thumbnail_width'] : apply_filters( 'thim_course_thumbnail_width', 450 );
         $thumb_h   = ( ! empty( $course_settings['thumbnail_height'] ) && '' != $course_settings['thumbnail_height'] ) ? $course_settings['thumbnail_height'] : apply_filters( 'thim_course_thumbnail_height', 400 );
         $cat_id_tab = $course_settings['tabs-options']['cat_id_tab'] ? $course_settings['tabs-options']['cat_id_tab'] : array();

         $condition = array(
            'post_type'           => 'lp_course',
            'posts_per_page'      => $limit,
            
         );

         if ( is_array($cat_id) && count($cat_id) ) {

               $condition['tax_query'] = array(
                  array(
                     'taxonomy' => 'course_category',
                     'field'    => 'term_id',
                     'terms'    => $cat_id
                  ),
               );
            
         }

         $course_tags_list = $settings['course_tags_list'];
         if ( is_array($course_tags_list) && count($course_tags_list) ) {

               $condition['tax_query'] = array(
                  array(
                     'taxonomy' => 'course_tag',
                     'field'    => 'term_id',
                     'terms'    => $course_tags_list
                  ),
               );
            
         }

         if ( $sort == 'popular' ) {
            global $wpdb;
            $query = $wpdb->prepare( "
            SELECT ID, a+IF(b IS NULL, 0, b) AS students FROM(
               SELECT p.ID as ID, IF(pm.meta_value, pm.meta_value, 0) as a, (
                     SELECT COUNT(*)
                  FROM (SELECT COUNT(item_id), item_id, user_id FROM {$wpdb->prefix}learnpress_user_items GROUP BY item_id, user_id) AS Y
                  GROUP BY item_id
                  HAVING item_id = p.ID
                  ) AS b
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id  AND pm.meta_key = %s
                  WHERE p.post_type = %s AND p.post_status = %s
                  GROUP BY ID
                  ) AS Z
                  ORDER BY students DESC
                     LIMIT 0, $limit
                  ", '_lp_students', 'lp_course', 'publish' );

            $post_in = $wpdb->get_col( $query );

            $condition['post__in'] = $post_in;
            $condition['orderby']  = 'post__in';
         }

         if( $featured ) {
            $condition['meta_query'] = array(
               array(
                  'key' => '_lp_featured',
                  'value' =>  'yes',
               )
            );
         }

         $the_query = new \WP_Query( $condition );


       ?>
        <?php if ( $the_query->have_posts() ) : ?>

            <?php if($settings['layout'] =='style1'): ?>  
                  <div class="container">
                      <div class="row">
                            <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                                <?php

                                      $terms         = get_the_terms( $post->ID, 'course_category' );
                                      $cat_name       = null;
                                      $cat_url       = null;
                                      $cat_with_link = '';

                                      if(is_array($terms)):

                                        foreach($terms as $tkey=> $term):

                                          $cat_name = $term->name;
                                          $cat_url  = get_category_link($term->term_id);

                                          break;
                                        endforeach;

                                      endif; 

                                      
                                      $course            = LP()->global['course'];
                                      $lessons           = $course->get_curriculum_items( 'lp_lesson' )?count( $course->get_curriculum_items( 'lp_lesson' ) ) : 0;
                                      $students_enrolled = $course->get_users_enrolled();
                                      $instructor        = $course->get_instructor();
                                      $instructor_link   = $course->get_instructor_html();
                                      $instructor_id     = $course->get_id();
                                      $meta              = get_post_meta( $post->ID );
                                                  
                                      $featured = isset($meta['_lp_featured'][0]) ? $meta['_lp_featured'][0] : '';
                                      
                                ?>
                                <div class="col-lg-4 col-md-6">
                                      <div class="feature-course-item-3">
                                          
                                            <div class="fcf-thumb">
                                                <?php if( $settings['image_type'] == 'feature' ): ?>
                                                  <?php if( has_post_thumbnail() ): ?>
                                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_id(),'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                  <?php endif; ?>
                                                <?php elseif($settings['image_type'] == 'course'): ?> 
                                                  <?php  $course_image = bisy_meta_option( get_the_id(), 'course_image','','bisy_lp_course_options');  ?> 
                                                  <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                <?php elseif($settings['image_type'] == 'icon'): ?>  
                                                  <?php  $course_image = bisy_meta_option( get_the_id(), 'course_icon','','bisy_lp_course_options');  ?> 
                                                  <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                <?php endif; ?>
                                                <form name="purchase-course" method="post" enctype="multipart/form-data">
                                                      <input type="hidden" name="purchase-course" value="<?php echo esc_attr( $course->get_id() ); ?>"/>
                                                      <input type="hidden" name="purchase-course-nonce" value="<?php echo esc_attr( \LP_Nonce_Helper::create_course( 'purchase' ) ); ?>"/>
                                                      <button class="enroll"> <?php echo esc_html__('Enroll Now','bisy-essential'); ?> </button>
                                                </form>  
                                            </div>
                                          
                                          <div class="fci-details">

                                              <?php if( !is_null($cat_name) ): ?>
                                                <a href="<?php echo esc_url($cat_url); ?>" class="c-cate"><i class="icon_tag_alt"></i> <?php echo esc_html($cat_name); ?> </a>
                                              <?php endif; ?>
                                             
                                              <h4 class="title"> <a href="<?php echo esc_url($course->get_permalink()); ?>"> <?php echo esc_html(get_the_title()); ?> </a> </h4>
                                              <?php 
                                                  $dir          = learn_press_user_profile_picture_upload_dir();
                                                  $user         = get_user_by( 'id', $instructor->get_id());
                                                  $pro_link     = get_user_meta($user->ID,'_lp_profile_picture',true);
                                                  $base_url     = isset($dir['baseurl'])?$dir['baseurl']:'';
                                                  $profile_link = $base_url.'/'.$pro_link;

                                                  $course_free_price = bisy_meta_option( get_the_id(), 'course_free_price',0,'bisy_lp_course_options');
                                                  
                                              ?>
                                              <?php if($settings['show_author'] == 'yes'): ?>
                                              <div class="author">
                                                  <img src="<?php echo esc_url( get_avatar_url( $instructor->get_id() ) ); ?>">
                                                  <?php  echo wp_kses_post($instructor_link) ?>
                                              </div>
                                              <?php endif; ?>
                                              <div class="price-rate">
                                                  <div class="course-price">
                                                    <?php if($course->is_free()): ?>

                                                          <?php echo esc_html__('Free','bisy-essential'); ?>
                                                          <?php if($course_free_price > 0): ?>
                                                            <span> <?php echo esc_html($course_free_price); ?> </span>
                                                          <?php endif; ?>
                                                         
                                                      <?php else: ?>
                                                          
                                                          <?php if( $course->has_sale_price() ): ?> 
                                                            <?php echo $course->get_price_html(); ?> 
                                                          <?php endif; ?>
                                                          <span> <?php echo $course->get_origin_price_html(); ?> </span>   

                                                      <?php endif; ?>
                                                  </div>
                                                  <?php if( function_exists( 'learn_press_get_course_rate' ) && $settings['course_rating_show'] =='yes' ): ?>
                                                    <?php

                                                        $course_rate_res = learn_press_get_course_rate( $post->ID, false );
                                                        $course_rate     = $course_rate_res['rated'];
                                                        $total           = $course_rate_res['total'];
                                                       
                                                    
                                                    ?>
                                                    <div class="ratings">
                                                        <i class="icon_star"></i>
                                                        <span> <?php echo esc_html($course_rate); ?> (<?php echo esc_html($total); ?>)</span>
                                                    </div>
                                                  <?php endif; ?>
                                              </div>
                                          </div>
                                      </div>
                                </div>
                            <?php endwhile; wp_reset_postdata(); ?>
                        </div>
                    </div>
            <?php endif; ?>
          
       <?php  endif;  ?>
       <?php

         
      }
  
      
    }
   
    public function course_list(){
      if(!defined('LP_COURSE_CPT')){
        return [];
      }
      $args = array(

        'post_type'   => 'lp_course',
        'orderby' => 'post_date', 
        'order' => 'DESC',
        'post_status'  => 'publish',
        'posts_per_page' => -1
                  
        );  

        $lp_course = get_posts( $args ); 
        $course_list = [];
       
        foreach ($lp_course as $postdata) {
            setup_postdata( $postdata );
            $course_list[$postdata->ID] = [$postdata->post_title];
         
        }
      
        return $course_list;
    }

 

}