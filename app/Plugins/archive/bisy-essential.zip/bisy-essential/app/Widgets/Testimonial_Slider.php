<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

class Testimonial_Slider extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-testimonial-slider';
    }

    public function get_title() {
        return esc_html__( 'Testimonial Slider ', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fas fa-quote-left";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() { 

     
 
      $this->start_controls_section(
         'section_layouts_tab',
         [
             'label' => esc_html__('Layout', 'bisy-essential'),
         ]
     );

     $this->add_control(

      'block_style', [
          'label'   => esc_html__('Choose Style', 'bisy-essential'),
          'type'    => Custom_Controls_Manager::RADIOIMAGE,
          'default' => 'style1',
          'options' => [
            'style1' => [
               'title'      => esc_html__( 'Style 1', 'bisy-essential' ),
               'imagelarge' => BISY_ESSENTIAL_IMG . '/admin/testimonial/style1.png',
               'imagesmall' => BISY_ESSENTIAL_IMG . '/admin/testimonial/style1.png',
               'width'      => '50%',
            ],
           
        ],

      ]
    ); 

    $this->end_controls_section();
    do_action( 'bisy_section_slider_tab', $this , $this->get_name()); 
    $this->start_controls_section('section_tab',
         [
            'label' => esc_html__('Contents', 'bisy-essential'),
         ]
      );

      $this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'condition' => [ 'block_style' => ['style4','style6'] ],
			]
		);
        
      $this->add_control(
			'item_center',
			[
				'label' => __( 'Item Center active', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Enable', 'bisy-essential' ),
				'label_off' => __( 'Disable', 'bisy-essential' ),
				'return_value' => 'yes',
				'default' => '',
                'condition' => [ 'block_style' => ['style2'] ],
			]
		);
  

      $this->add_responsive_control(
			'content_align', [
				'label'   => esc_html__( 'Content Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
             
           'selectors' => [
              '{{WRAPPER}} .testimonial-item' => 'text-align: {{VALUE}};',
              
         
				],
			]
        );//Responsive control end

      
      $repeater = new \Elementor\Repeater();
 
		
      $repeater->add_control(
			'testimonial',
			[
				'label'       => esc_html__( 'Testimonial', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => esc_html__( 'Default testimonial', 'bisy-essential' ),
				'placeholder' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing', 'bisy-essential' ),
			]
      );
      
     

      $repeater->add_control(
			'client_name',
			[
				'label'       => esc_html__( 'Client name', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Shuvas Chandra', 'bisy-essential' ),
				'placeholder' => esc_html__( 'Type your client name here', 'bisy-essential' ),
			]
      );

      $repeater->add_control(
			'client_designation',
			[
				'label'       => esc_html__( 'Client designation', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Founder at Seative Digital', 'bisy-essential' ),
				'placeholder' => esc_html__( 'Type your client designation here', 'bisy-essential' ),
			]
      );
     

      $repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'bisy-essential' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
               'url' => BISY_ESSENTIAL_IMG.'/testimonial-1.jpg',
				],
			]
      );

    
  
		$this->add_control(
			'testimonial_list',
			[
				'label'       => esc_html__( 'Testimonial List', 'plugin-domain' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ client_name }}}',
			]
		);

      $this->end_controls_section();

    
      $this->start_controls_section('apps_content_style_section',
         [
            'label' => esc_html__( 'Content Style', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
     
   
               $this->add_responsive_control('box_padding_n',
                  [
                     'label'      => esc_html__( 'Testimonial Padding', 'bisy-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px' ],
                     
                     'selectors' => [
                        '{{WRAPPER}} .testimonial-item p' => 'padding-left: {{LEFT}}{{UNIT}};padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}}; padding-right:{{RIGHT}}{{UNIT}};',
                     
                     ],
                  ]
               );
 
      
               $this->add_control(
                  'testimonial_color',
                     [
                        'label'     => esc_html__('Testimonial color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} .testimonial-item p' => 'color: {{VALUE}};',
                        ],
                     ]
               );

               $this->add_group_control(
                  Group_Control_Typography:: get_type(),
                  [
                     'name'     => 'testimonial_typho',
                     'label'    => esc_html__( 'Testimonial Typography', 'bisy-essential' ),
                   
                     'selector' => '{{WRAPPER}} .testimonial-item p',
                  ]
               );

               $this->add_control(
                  'client_color',
                     [
                        'label'     => esc_html__('Client color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} .testimonial-item h5' => 'color: {{VALUE}};',
                           
                        ],
                     ]
               );

               
               $this->add_control(
                  'client_hover_color',
                     [
                        'label'     => esc_html__('Client Hover color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} .testimonial-item:hover h5' => 'color: {{VALUE}};',
                           
                        ],
                     ]
               );

               $this->add_group_control(
                  Group_Control_Typography:: get_type(),
                  [
                     'name'     => 'client_typho',
                     'label'    => esc_html__( 'Client Typography', 'bisy-essential' ),
                   
                     'selector' => '{{WRAPPER}} .testimonial-item h5',
                  ]
               );

               $this->add_responsive_control('client_margin_n',
               [
                  'label'      => esc_html__( 'Client Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%' ],
                  
                  'selectors' => [
                     '{{WRAPPER}} .testimonial-item h5' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
                  ],
               ]
            );

            $this->add_control(
               'des_color',
                  [
                     'label'     => esc_html__('Designation color', 'bisy-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} .testimonial-item span' => 'color: {{VALUE}};',
                     ],
                  ]
            );

            $this->add_control(
               'des_hover_color',
                  [
                     'label'     => esc_html__('Designation Hover', 'bisy-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} .testimonial-item:hover span' => 'color: {{VALUE}};',
                     ],
                  ]
            );

            $this->add_group_control(
               Group_Control_Typography:: get_type(),
               [
                  'name'     => 'des_typho',
                  'label'    => esc_html__( 'Designation Typography', 'bisy-essential' ),
                
                  'selector' => '{{WRAPPER}} .testimonial-item span',
               ]
            );

            $this->add_responsive_control('des_margin_n',
               [
                  'label'      => esc_html__( 'Designation Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%' ],
                  'selectors' => [
                     '{{WRAPPER}} .testimonial-item span' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}}; display:block;',
                  ],
               ]
            );

      $this->end_controls_section();  

      $this->start_controls_section(
			'section_images_style', [
				'label' => esc_html__( 'Image', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      );

         $this->add_responsive_control('image_client_margin_n',
            [
               'label'      => esc_html__( 'Client Image Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%' ],
               
               'selectors' => [
                  '{{WRAPPER}} .testi-author' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
               ],
            ]
         );

        
         $this->add_responsive_control(
            'client_img_borders_radius',
            [
               'label'      => esc_html__( 'Client Border radius', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%'],
               
               'selectors' => [
                  
                  '{{WRAPPER}} .testi-author img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                  
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'image_border',
                'label'    => esc_html__( 'Client Border', 'bisy-essential' ),
                'selector' => '{{WRAPPER}} .testi-author img',
              
            ]
         );

        // quote icon
         $this->add_responsive_control('image_quote_margin_n',
            [
               'label'      => esc_html__( 'Image Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%' ],
              
               'selectors' => [
                  '{{WRAPPER}} .testi-author' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
                 
               ],
            ]
         );
  
      $this->end_controls_section(); 
      $this->start_controls_section(
			'section_box_item_style', [
				'label' => esc_html__( 'Box Item', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      ); 

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'section_box_item_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .testimonial-item',
               ]
            );

            $this->add_responsive_control(
               'box_item_margin',
               [
                  'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} .testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_item_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        ],
                  ]
            );

            $this->add_control(
               'border_box_item_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} .testimonial-item' => 'border-radius: {{VALUE}}px;',
                      
                  ],
               ]
            );  

            $this->add_group_control(
               \Elementor\Group_Control_Box_Shadow::get_type(),
               [
                  'name' => 'box_item_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                  'selector' => '{{WRAPPER}} .testimonial-item',
               ]
            );

            $this->add_control(
               'box_item_hv_bg_colors_heading',
               [
                   'label' => esc_html__( 'Hover Background color', 'bisy-essential' ),
                   'type' => \Elementor\Controls_Manager::HEADING,
                   'separator' => 'before',
                  
               ]
           );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'section_box_item_hover_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .testimonial-item:hover',
                 
               ]
            );

      $this->end_controls_section(); 

      $this->start_controls_section(
			'section_slider_nav_style', [
				'label' => esc_html__( 'Slider Nav', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'block_style' => ['style2'] ],
			  ]
      ); 
          
         $this->add_control(
            'slider_nav_des_color',
               [
                  'label'     => esc_html__('Color', 'bisy-essential'),
                  'type'      => Controls_Manager::COLOR,
                  'default'   => '',
                  'selectors' => [
                     '{{WRAPPER}} .slick-arrow i' => 'color: {{VALUE}};',
                  ],
               ]
         );

         $this->add_group_control(
            Group_Control_Typography:: get_type(),
            [
               'name'     => 'slidar_nav_des_typho',
               'label'    => esc_html__( 'Typography', 'bisy-essential' ),
             
               'selector' => '{{WRAPPER}} .slick-arrow i ',
            ]
         );

         $this->add_control('tab_menu_switch_active_color',
         [
             'label'     => esc_html__( 'Background Color', 'bisy-essential' ),
             'type'      => Controls_Manager::COLOR,
             'selectors' => [
                 
                 '{{WRAPPER}} .slick-arrow' => 'background-color: {{VALUE}};',
                ],
             ]
         );

         $this->add_responsive_control(
            'slider_arrow_pos_top',
            [
                'label' => esc_html__( 'Position Top', 'bisy-essential' ),
                'condition' => [ 'block_style' => ['style2','style3','style4'] ],
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -500,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .slick-arrow' => 'top: {{SIZE}}{{UNIT}};',
                    
                    
                ],
               
            ]
        );

         $this->add_responsive_control(
            'slider_arrow_pos_prev_left',
               [
                  'label' => esc_html__( 'Position Prev Left', 'bisy-essential' ),
                  'type' => Controls_Manager::SLIDER,
                   'condition' => [ 'block_style' => ['style2','style3','style4'] ],
                  'size_units' => [ 'px', '%' ],
                  'range' => [
                     'px' => [
                           'min' => -500,
                           'max' => 1000,
                           'step' => 1,
                     ],
                     '%' => [
                           'min' => 0,
                           'max' => 100,
                     ],
                  ],
                  
                  'selectors' => [
                     '{{WRAPPER}} .slick-arrow.prev' => 'left: {{SIZE}}{{UNIT}};',
                     
                     
                  ],
                  
               ]
         );
       
         
     
         $this->add_control(
            'image_slider_nav_active_color_heading',
            [
               'label' => esc_html__( 'Active color', 'bisy-essential' ),
               'type' => \Elementor\Controls_Manager::HEADING,
               'separator' => 'before',
               'condition' => [ 'block_style' => ['style4','style5'] ],
            ]
         );

         $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'image_slider_nav_active_color',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient' ],
                  'condition' => [ 'block_style' => ['style4','style5'] ],
                  'selector' => '{{WRAPPER}} .slick-dots li.slick-active button',
               ]
         );

         $this->add_responsive_control('image_slider_nav_margin',
            [
               'label'      => esc_html__( 'Margin', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%' ],
               'condition' => [ 'block_style' => ['style4','style5'] ],
               'selectors' => [
                  '{{WRAPPER}} .slick-dots' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
               ],
            ]
         );

         $this->add_responsive_control('image_slider_nav_margin_n',
            [
               'label'      => esc_html__( 'Padding', 'bisy-essential' ),
               'type'       => Controls_Manager::DIMENSIONS,
               'size_units' => [ 'px','%' ],
               
               'selectors' => [
                  '{{WRAPPER}} .slick-dots li' => 'padding-left: {{LEFT}}{{UNIT}};padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}}; padding-right:{{RIGHT}}{{UNIT}};',
                  '{{WRAPPER}} .slick-arrow' => 'padding-left: {{LEFT}}{{UNIT}};padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}}; padding-right:{{RIGHT}}{{UNIT}};',
               ],
            ]
         );

      $this->end_controls_section();  

      $this->start_controls_section('bisy_main_section_section',
            [
            'label' => esc_html__( 'Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
      );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'section_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .main-section',
               ]
            );
  
            $this->add_responsive_control(
               'box_margin',
               [
                  'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                  ]
            );

            $this->add_control(
               'border_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} .main-section' => 'border-radius: {{VALUE}}px;',
                  ],
               ]
            );  
      $this->end_controls_section();
   }
   protected function render(){

     $settings         = $this->get_settings();
     $testimonial_list = $settings['testimonial_list'];
     $slider_enable    = $settings['slider_enable'];
     $slide_controls   = bisy_widgets_slider_controls_setttings($settings);
    
    ?>
       <?php if($settings['block_style'] =='style1'): ?>

         <div class="main-section testimonial-slider owl-carousel" data-controls='<?php echo json_encode($slide_controls); ?>'>
               <?php foreach($testimonial_list as $item): ?>
                     <div class="testimonial-item">
                        <div class="testi-author">
                           <?php if( $item['image']['url'] !=''): ?>
                           <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr($item['client_name']); ?>">
                           <?php endif; ?>
                           <?php if($item['client_name'] !=''): ?>
                              <h5> <?php echo esc_html($item['client_name']); ?> </h5>
                           <?php endif; ?>
                           <?php if($item['client_designation'] !=''): ?>
                           <span> <?php echo esc_html($item['client_designation']); ?> </span>
                           <?php endif; ?>
                        </div>
                        <p>
                           <?php echo esc_html($item['testimonial']); ?>
                        </p>
                     </div>
               <?php endforeach; ?>
         </div>
           
       <?php endif; ?>
         
   <?php  
   }
}  