<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class Grid_Course extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-grid-course';
    }

    public function get_title() {
        return esc_html__( 'Course', 'bisy-essential' );
    }

    public function get_icon() { 
        return 'eicon-person';
    }

    public function get_categories() {

        return [ 'bisy-elements' ];
    }

    	// Get list courses category
      public function course_category(){

        if(!defined('LP_COURSE_CPT')){
          return [];
        }
        
        $tax_terms = get_terms('course_category', array('hide_empty' => false));
        $category_list = [];
         
        foreach($tax_terms as $term_single) {      
          $category_list[$term_single->term_id] = [$term_single->name];
         
        }
        
        return $category_list;
        }

    protected function _register_controls() {
      $this->start_controls_section(
        'content',
        [
          'label' => esc_html__( 'Courses', 'bisy-essential' )
        ]
      );
  

        $this->add_control(
          'layout',
          [
            'label'   => esc_html__( 'Layout', 'bisy-essential' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
              
              'grid-1' => esc_html__( 'Grid 1', 'bisy-essential' ),
              'tabs'   => esc_html__( 'Category Tabs', 'bisy-essential' ),

            ],
            'default' => 'grid-1'
          ]
        );
  
        $this->add_control(
          'order',
          [
            'label'   => esc_html__( 'Order By', 'bisy-essential' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
              'popular'  => esc_html__( 'Popular', 'bisy-essential' ),
              'latest'   => esc_html__( 'Latest', 'bisy-essential' ),
            ],
            'default' => 'latest',
            'condition' => array(
              'layout' => ['grid-1', 'tabs']
            )
          ]
        );
  
        $this->add_control(
          'limit',
          [
            'label'   => esc_html__( 'Limit Number of Courses', 'bisy-essential' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 8,
            'min'     => 1,
            'step'    => 1,
            'condition' => array(
              'layout' => ['grid-1', 'tabs']
            )
          ]
        );
  
        $this->add_control(
          'cat_id',
          [
            'label'     => esc_html__( 'Select Category', 'bisy-essential' ),
            'type'      => Controls_Manager::SELECT2,
            'options'   => $this->course_category(),
            'multiple'    => true,
            'default'     => 'all',
            'condition' => array(
              'layout' => ['grid-1']
            )
          ]
        );
        $this->add_control(
          'course_tags_list',
          [
            'label'     => esc_html__( 'Select Tags', 'bisy-essential' ),
            'type' => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options'  => bisy_get_post_category('course_tag'),
            
          ]
        );
        $this->add_control(
          'course_list',
          [
            'label'     => esc_html__( 'Select course', 'bisy-essential' ),
            'type'      => Controls_Manager::SELECT,
            'options'   => $this->course_list(),
            'condition' => array(
              'layout' => ['grid-single']
            )
          ]
        );

          $this->add_control(
            'featured',
            [
              'label'        => esc_html__( 'Display Featured Courses?', 'bisy-essential' ),
              'type'         => Controls_Manager::SWITCHER,
              'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
              'label_off'    => esc_html__( 'No', 'bisy-essential' ),
              'return_value' => 'yes',
              'default'      => '',
              'condition' => array(
                'layout' => ['grid-1', 'tabs']
              )
            ]
          );
      
     
          $this->add_control(
                'course_rating_show',
                [
                    'label'        => esc_html__( 'Rating', 'bisy-essential' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => esc_html__( 'Yes', 'bisy-essential' ),
                    'label_off'    => esc_html__( 'No', 'bisy-essential' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                    'condition' => array(
                      'layout' => ['grid-1', 'tabs']
                    )
                ]
            );

          $this->add_control(
            'image_type',
            [
              'label' => esc_html__( 'Front Image Type', 'bisy-essential' ),
              'type' => \Elementor\Controls_Manager::SELECT,
              'default' => 'feature',
              'options' => [
                'feature'  => esc_html__( 'Feature Image', 'bisy-essential' ),
                'course' => esc_html__( 'Course Image', 'bisy-essential' ),
                'icon' => esc_html__( 'Icon Image', 'bisy-essential' ),
            
              ],
            ]
          );

          $this->add_control(
            'back_image_type',
            [
              'label' => esc_html__( 'Back Image Type', 'bisy-essential' ),
              'type' => \Elementor\Controls_Manager::SELECT,
              'default' => 'feature',
              'options' => [
                'feature'  => esc_html__( 'Feature Image', 'bisy-essential' ),
                'course' => esc_html__( 'Course Image', 'bisy-essential' ),
                'icon' => esc_html__( 'Icon Image', 'bisy-essential' ),
            
              ],
              'condition' => array(
                'layout' => ['tabs']
              )
            ]
          );
      $this->end_controls_section();

      $this->start_controls_section(
        'heading_title_section',
        [
          'label'     => esc_html__( 'Heading Title', 'bisy-essential' ),
          'condition' => array(
            'layout' => [ 'tabs' ]
          )
        ]
      );


          $this->add_control(
            'heading_top_title',
            [
              'label'   => esc_html__( 'Top Title', 'bisy-essential' ),
              'type'    => Controls_Manager::TEXT,
            ]
          );

          $this->add_control(
            'heading_title',
            [
              'label'   => esc_html__( 'Title', 'bisy-essential' ),
              'type'    => Controls_Manager::TEXT,
            ]
          );

      $this->end_controls_section();
  
 

  
      $this->start_controls_section(
        'tab-options',
        [
          'label'     => esc_html__( 'Tab Options', 'bisy-essential' ),
          'condition' => array(
            'layout' => [ 'tabs' ]
          )
        ]
      );
  
      $this->add_control(
        'limit_tab',
        [
          'label'   => esc_html__( 'Limit Items Per Tab', 'bisy-essential' ),
          'type'    => Controls_Manager::NUMBER,
          'default' => 4,
          'min'     => 1,
          'step'    => 1
        ]
      );
  
      $this->add_control(
        'cat_id_tab',
        [
          'label'       => esc_html__( 'Select Category Tabs', 'bisy-essential' ),
          'label_block' => true,
          'type'        => Controls_Manager::SELECT2,
          'options'     => $this->course_category(),
          'multiple'    => true,
          'default'     => 'all'
        ]
      );
  
      $this->end_controls_section();

      $this->start_controls_section(
        'tab_menu_style', [
          'label'	 => esc_html__( 'Tab Menu', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          'condition' => ['layout'=> 'tabs']
        ]
      );
      $this->add_control(
        'tab_menu_color', [
          'label'		 => esc_html__( 'color', 'bisy-essential' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .shaf-filter li' => 'color: {{VALUE}};',
          ],
        ]
        );

      $this->add_control(
        'tab_menu_active_color', [
          'label'		 => esc_html__( 'Tab menu active color', 'bisy-essential' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .shaf-filter li.active' => 'color: {{VALUE}};',
         
          ],
        ]
        );
  
         
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
        'name'		 => 'tab_menu_typography',
        'selector'	 => '{{WRAPPER}} .shaf-filter li',
        ]
        );
        
        $this->add_responsive_control(
          'tab_menu_margin',
          [
            'label' => esc_html__( 'Tab Menu margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
           
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );
        $this->add_responsive_control(
          'tab_menu_padding',
          [
            'label' => esc_html__( 'Tab Menu padding', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );
        $this->add_responsive_control(
          'tab_menu_border_radius',
          [
            'label' => esc_html__( 'Border Radius', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'tab_menu_main_margin',
          [
            'label' => esc_html__( 'Container margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
           
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .shaf-filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        
        $this->add_responsive_control(
          'content_align', [
            'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
    
                  'left'  => [
                            
                            'title' => esc_html__( 'Left', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-left',
                        
                        ],
                  'center'  => [
                            
                            'title' => esc_html__( 'Center', 'bisy-essential' ),
                            'icon'  => 'fa fa-align-center',
                        
                        ],
                  'right'	 => [
          
                      'title' => esc_html__( 'Right', 'bisy-essential' ),
                      'icon'  => 'fa fa-align-right',
                            
                    ],
                  'justify'	 => [
          
                      'title' => esc_html__( 'Justified', 'bisy-essential' ),
                      'icon'  => 'fa fa-align-justify',
                            
                    ],
                  ],
                  'default' => 'right',
                      
                  'selectors' => [
                    '{{WRAPPER}} .shaf-filter' => 'text-align: {{VALUE}};',
                  ],
            ]
        );//Responsive control end

 
      $this->end_controls_section();

      $this->start_controls_section(
        'heading_title_style_section',
        [
          'label'     => esc_html__( 'Heading Title', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          'condition' => array(
            'layout' => [ 'tabs' ]
          )
        ]
      );

            $this->add_control(
              'heading_top_title_color', [
                'label'     => esc_html__( 'Top title color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  '{{WRAPPER}} .sec-title span' => 'color: {{VALUE}};',
                ],
              ]
            );
      
            
            $this->add_group_control(
            Group_Control_Typography::get_type(), [
              'name'     => 'heading_top_title_typography',
              'selector' => '{{WRAPPER}} .sec-title span',
              ]
            );

            $this->add_control(
              'heading_title_color', [
                'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  '{{WRAPPER}} .sec-title' => 'color: {{VALUE}};',
                ],
              ]
            );
      
            
            $this->add_group_control(
            Group_Control_Typography::get_type(), [
              'name'     => 'heading_title_typography',
              'selector' => '{{WRAPPER}} .sec-title',
              ]
            );
            
            $this->add_responsive_control(
              'heading_top_title_margin',
              [
                'label' => esc_html__( 'Top Title margin', 'bisy-essential' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                  '{{WRAPPER}} .sec-title span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

            $this->add_responsive_control(
              'heading_title_margin',
              [
                'label' => esc_html__( 'Title margin', 'bisy-essential' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                  '{{WRAPPER}} .sec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

            $this->add_responsive_control(
              'heading_content_align', [
                'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
        
                      'left'  => [
                                
                                'title' => esc_html__( 'Left', 'bisy-essential' ),
                                'icon'  => 'fa fa-align-left',
                            
                            ],
                      'center'  => [
                                
                                'title' => esc_html__( 'Center', 'bisy-essential' ),
                                'icon'  => 'fa fa-align-center',
                            
                            ],
                      'right'	 => [
              
                          'title' => esc_html__( 'Right', 'bisy-essential' ),
                          'icon'  => 'fa fa-align-right',
                                
                        ],
                      'justify'	 => [
              
                          'title' => esc_html__( 'Justified', 'bisy-essential' ),
                          'icon'  => 'fa fa-align-justify',
                                
                        ],
                      ],
                          
                      'selectors' => [
                        '{{WRAPPER}} .sec-title' => 'text-align: {{VALUE}};',
                      ],
                ]
            );//Responsive control end

      $this->end_controls_section();

      $this->start_controls_section(
        'title_style', [
          'label'	 => esc_html__( 'Course Title', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'title_color', [
            'label'		 => esc_html__( 'Title color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2 .title a' => 'color: {{VALUE}};',
              '{{WRAPPER}} .flipper .front .title' => 'color: {{VALUE}};',
            ],
          ]
        );

        $this->add_control(
          'title_hover_color', [
            'label'		 => esc_html__( 'Title hover color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2:hover .title a' => 'color: {{VALUE}};',
              '{{WRAPPER}} .flipper:hover .title a' => 'color: {{VALUE}};',
            ],
          ]
        );
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'title_typography',
          'selector'	 => '{{WRAPPER}} .feature-course-item-2 .title a, {{WRAPPER}} .flipper .title a,{{WRAPPER}} .flipper .title',
          ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
            'name'		 => 'title_hover_typography',
            'label'		 => esc_html__( 'Title hover', 'bisy-essential' ),
            'selector'	 => '{{WRAPPER}} .flipper .back .title a',
            'condition' => array(
              'layout' => ['tabs']
            ),
            ]
          );
        
        $this->add_responsive_control(
          'title_margin',
          [
            'label' => esc_html__( 'Title margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .feature-course-item-2 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .flipper .front .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'title_back_margin',
          [
            'label' => esc_html__( 'Title Hover Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'condition' => array(
              'layout' => ['tabs']
            ),
            'selectors' => [
              '{{WRAPPER}} .feature-course-item-2 .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .flipper .back .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        
      
      $this->end_controls_section();

      $this->start_controls_section(
        'category_meta_style', [
          'label'	 => esc_html__( 'Category', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          '_category_meta_color', [
            'label'		 => esc_html__( 'Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2 .c-cate' => 'color: {{VALUE}};',
              '{{WRAPPER}} .front .c-cate' => 'color: {{VALUE}};',
            
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'category_meta_typography',
          'selector'	 => '{{WRAPPER}} .feature-course-item-2 .c-cate,{{WRAPPER}} .front .c-cate',
          ]
        );  

        $this->add_control(
          'category_hover_color', [
            'label'		 => esc_html__( 'Hover Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2 .c-cate:hover' => 'color: {{VALUE}};',
              '{{WRAPPER}} .back .c-cate' => 'color: {{VALUE}};',
            
            ],
          ]
        );

        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'category__back_meta_typography',
          'label'		 => esc_html__( 'Hover Typhography', 'bisy-essential' ),
          'selector'	 => '{{WRAPPER}} .back .c-cate',
          'condition' => array(
            'layout' => ['tabs']
          ),
          ]
        );  
  
        $this->add_control(
          'categhory_bg_color', [
            'label'		 => esc_html__( 'Background color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2 .c-cate' => 'background-color: {{VALUE}};',
              '{{WRAPPER}} .front .c-cate' => 'background-color: {{VALUE}};',
             
            ],
          ]
          );

          $this->add_control(
            'categhory_hover_bg_color', [
              'label'		 => esc_html__( 'Hover Background', 'bisy-essential' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .feature-course-item-2 .c-cate:hover' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .back .c-cate' => 'background-color: {{VALUE}};',
                
              ],
            ]
          ); 
          
          $this->add_responsive_control(
            'category_margin',
            [
              'label' => esc_html__( 'Margin', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .feature-course-item-2 .c-cate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front .c-cate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'category_padding',
            [
              'label' => esc_html__( 'Padding', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .feature-course-item-2 .c-cate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front .c-cate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

      $this->end_controls_section();

      $this->start_controls_section(
        'lesson_meta_style', [
          'label'	 => esc_html__( 'Lesson', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );
      $this->add_control(
        'lesson_meta_color', [
          'label'		 => esc_html__( 'Color', 'bisy-essential' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .feature-course-item-2 .bisy-lesson' => 'color: {{VALUE}};',
            '{{WRAPPER}} .front .fcf-bottom .bisy-lesson' => 'color: {{VALUE}};',
           
          ],
        ]
      );

    

      $this->add_control(
        'lesson_hover_color', [
          'label'		 => esc_html__( 'Hover Color', 'bisy-essential' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .feature-course-item-2 .bisy-lesson:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .back .fcf-bottom .bisy-lesson' => 'color: {{VALUE}};',
           
          ],
        ]
        );
  
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'lesson_meta_typography',
          'selector'	 => '{{WRAPPER}} .feature-course-item-2 .bisy-lesson,{{WRAPPER}} .bisy-lesson',
          ]
        );

        $this->add_control(
          'lesson_icon_meta_color', [
            'label'		 => esc_html__( 'Icon Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2 .bisy-lesson i' => 'color: {{VALUE}};',
              '{{WRAPPER}} .fcf-bottom .bisy-lesson i' => 'color: {{VALUE}};',
             
            ],
          ]
        );
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'lesson_icon_meta_typography',
          'selector'	 => '{{WRAPPER}} .feature-course-item-2 .bisy-lesson i,{{WRAPPER}} .fcf-bottom .bisy-lesson i',
          ]
        );

        $this->add_responsive_control(
          'lesson_margin',
          [
            'label' => esc_html__( 'Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .feature-course-item-2 .bisy-lesson' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .bisy-lesson' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'lesson_padding',
          [
            'label' => esc_html__( 'Padding', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .feature-course-item-2 .bisy-lesson' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .bisy-lesson' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

      $this->end_controls_section();

      $this->start_controls_section(
        'students_meta_style', [
          'label'	 => esc_html__( 'Students', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

      $this->add_control(
        'students_meta_color', [
          'label'		 => esc_html__( 'Color', 'bisy-essential' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .feature-course-item-2 .bisy-students' => 'color: {{VALUE}};',
            '{{WRAPPER}} .front .fcf-bottom .bisy-students' => 'color: {{VALUE}};',
           
          ],
        ]
      );

      $this->add_control(
        'students_hover_color', [
          'label'		 => esc_html__( 'Hover Color', 'bisy-essential' ),
          'type'		 => Controls_Manager::COLOR,
          'selectors'	 => [
            '{{WRAPPER}} .feature-course-item-2 .bisy-students:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .back .fcf-bottom .bisy-students' => 'color: {{VALUE}};',
           
          ],
        ]
        );
  
         
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'students_meta_typography',
          'selector'	 => '{{WRAPPER}} .feature-course-item-2 .bisy-students,{{WRAPPER}} .fcf-bottom .bisy-students',
          ]
        );

        $this->add_control(
          'students_icon_meta_color', [
            'label'		 => esc_html__( 'Icon Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .feature-course-item-2 .bisy-students i' => 'color: {{VALUE}};',
              '{{WRAPPER}} .fcf-bottom .bisy-students i' => 'color: {{VALUE}};',
             
            ],
          ]
        );
        $this->add_group_control(
          Group_Control_Typography::get_type(), [
          'name'		 => 'students_icon_meta_typography',
          'selector'	 => '{{WRAPPER}} .feature-course-item-2 .bisy-students i,{{WRAPPER}} .fcf-bottom .bisy-students i',
          ]
        );

        $this->add_responsive_control(
          'students_margin',
          [
            'label' => esc_html__( 'Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .feature-course-item-2 .bisy-students' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .bisy-students' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'students_padding',
          [
            'label' => esc_html__( 'Padding', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .feature-course-item-2 .bisy-students' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              '{{WRAPPER}} .fcf-bottom .bisy-students' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

      $this->end_controls_section();

      $this->start_controls_section(
        'price_meta_style', [
          'label'	 => esc_html__( 'Price', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );
      
            $this->add_control(
              'price_meta_color', [
                'label'		 => esc_html__( 'Price Color', 'bisy-essential' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
                  '{{WRAPPER}} .feature-course-item-2 .course-price span' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .course-price span' => 'color: {{VALUE}};',
                
                ],
              ]
            );

            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => 'price__meta_typography',
              'selector'	 => '{{WRAPPER}} .feature-course-item-2 .course-price span,{{WRAPPER}} .course-price span',
              ]
            );

            $this->add_control(
              'sale_price_color', [
                'label'		 => esc_html__( 'Sale Price Color', 'bisy-essential' ),
                'type'		 => Controls_Manager::COLOR,
                'selectors'	 => [
                  '{{WRAPPER}} .feature-course-item-2 .course-price' => 'color: {{VALUE}};',
                  '{{WRAPPER}} .course-price' => 'color: {{VALUE}};',
                
                ],
              ]
            );
      
            
            $this->add_group_control(
              Group_Control_Typography::get_type(), [
              'name'		 => 'sale_price_meta_typography',
              'selector'	 => '{{WRAPPER}} .feature-course-item-2 .course-price , {{WRAPPER}} .course-price',
              ]
            );


            $this->add_responsive_control(
              'price_margin',
              [
                'label' => esc_html__( 'Margin', 'bisy-essential' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                  '{{WRAPPER}} .feature-course-item-2 .course-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .course-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

            $this->add_responsive_control(
              'price_padding',
              [
                'label' => esc_html__( 'Padding', 'bisy-essential' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                  '{{WRAPPER}} .feature-course-item-2 .course-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                  '{{WRAPPER}} .course-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
              ]
            );

      $this->end_controls_section();
     
     
      $this->start_controls_section(
        'instructor_style', [
          'label'	 => esc_html__( 'Instructor', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
        ]
      );

        $this->add_control(
          'instructor_color', [
            'label'		 => esc_html__( 'Color', 'bisy-essential' ),
            'type'		 => Controls_Manager::COLOR,
            'selectors'	 => [
              '{{WRAPPER}} .author a' => 'color: {{VALUE}};',
            ],
          ]
        );
  
         
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
        'name'		 => 'instructor_title_typography',
        'selector'	 => '{{WRAPPER}} .author a',
        ]
        );

        $this->add_responsive_control(
          'instructor_margin',
          [
            'label' => esc_html__( 'Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_padding',
          [
            'label' => esc_html__( 'Padding', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );

        $this->add_responsive_control(
          'instructor_name_margin',
          [
            'label' => esc_html__( 'Name Margin', 'bisy-essential' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors' => [
              '{{WRAPPER}} .author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
          ]
        );


      $this->end_controls_section();

      $this->start_controls_section(
        'course_rating', [
          'label'	 => esc_html__( 'Course Rating', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

         
          $this->add_control(
            'course_rating_color_', [
              'label'		 => esc_html__( 'Color', 'bisy-essential' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings i' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_control(
            'course_rating_active_color_', [
              'label'		 => esc_html__( 'Active Color', 'bisy-essential' ),
              'type'		 => Controls_Manager::COLOR,
              'selectors'	 => [
                '{{WRAPPER}} .ratings .active' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
              'name'     => 'course_Rating_border_',
              'label'    => esc_html__( 'Top Border', 'bisy-essential' ),
              'selector' => '{{WRAPPER}} .ratings',
            ]
          );

          $this->add_responsive_control(
            'course_rating_margin',
            [
              'label'      => esc_html__( 'Margin', 'bisy-essential' ),
              'type'       => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors'  => [
                '{{WRAPPER}} .ratings' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'course_rating_padding',
            [
              'label' => esc_html__( 'Padding', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .ratings' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

      $this->end_controls_section();
      
      $this->start_controls_section(
        'course_single_box', [
          'label'	 => esc_html__( 'Single Box', 'bisy-essential' ),
          'tab'	 => Controls_Manager::TAB_STYLE,
          
        ]
      );

      $this->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'single_box_item_background',
                'label'    => esc_html__( 'Background', 'bisy-essential' ),
                'types'    => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .feature-course-item-2,{{WRAPPER}} .front',
            ]
       );

       $this->add_group_control(
        \Elementor\Group_Control_Border::get_type(),
        [
          'name' => 'course_single_item_border_',
          'label' => esc_html__( 'Border', 'bisy-essential' ),
          'selector' => '{{WRAPPER}} .feature-course-item-2,{{WRAPPER}} .front',
        ]
      );
  
       $this->add_responsive_control(
        '_item__box_border_radius',
        [
            'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors' => [
                '{{WRAPPER}} .feature-course-item-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .back' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               
                
            ],
            'separator' => 'before',
        ]
      );

      $this->add_control(
        'single_border2_popover_toggle',
        [
            'label' => esc_html__( 'Hover Border', 'bisy-essential' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => esc_html__( 'Default', 'bisy-essential' ),
            'label_on' => __( 'Over Top Color', 'bisy-essential' ),
            'return_value' => 'yes',
            'default' => 'yes',
            'condition' => array(
              'layout' => ['grid-1']
            )
            
        ]
    );

    $this->start_popover();
        $this->add_control(
            'item_border_top_border', [

                'label'     => esc_html__( 'Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  '{{WRAPPER}} .feature-course-item-2:hover' => 'box-shadow: 0px -3px 0px 0px {{VALUE}};',
            
                ],
            ]
        );

          $this->add_group_control(
              \Elementor\Group_Control_Box_Shadow::get_type(),
              [
                  'name' => 'item_border_top_box_hover_shadow',
                  'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                  'selector' => '{{WRAPPER}} .feature-course-item-2:hover',
              ]
          );

          $this->end_popover();

          $this->add_group_control(
              \Elementor\Group_Control_Box_Shadow::get_type(),
              [
                  'name' => 'item_border_top_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                  'selector' => '{{WRAPPER}} .feature-course-item-2,{{WRAPPER}} .front',
                
              ]
          );

          $this->add_responsive_control(
            'single_item_box_padding',
            [
              'label' => esc_html__( 'Padding', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .feature-course-item-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .back' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_responsive_control(
            'single_item_box_margin',
            [
              'label' => esc_html__( 'Margin', 'bisy-essential' ),
              'type' => Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%', 'em' ],
              'selectors' => [
                '{{WRAPPER}} .feature-course-item-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .front' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .back' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
            ]
          );

          $this->add_control(
            'single_item_',
            [
              'label' => esc_html__( 'Hover Background', 'bisy-essential' ),
              'type' => \Elementor\Controls_Manager::HEADING,
              'separator' => 'before',
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'single_hover_box_item_background',
                    'label'    => esc_html__( 'Hover Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .feature-course-item-2:hover,{{WRAPPER}} .back',
                ]
           );


      $this->end_controls_section();
 
     
    }    
    protected function render() {
   
      $settings   = $this->get_settings();

      $course_settings = array(
       
        'order'             => $settings['order'],
        'cat_id'            => $settings['cat_id'],
        'course_list'       => $settings['course_list'],
        'layout'            => $settings['layout'],
        'limit'             => $settings['limit'],
        'tabs-options'      => array(
          'limit_tab'  => $settings['limit_tab'],
          'cat_id_tab' => $settings['cat_id_tab']
        ),
        'featured'          => $settings['featured'],
        'all_category' => $this->course_category()
      );

      $category_groups = []; 

      if(defined('LP_COURSE_CPT')){

         global $post, $wpdb;
         $random    = rand( 1, 99 );
         $limit_tab = $course_settings['tabs-options']['limit_tab'] ? $course_settings['tabs-options']['limit_tab'] : 4;
         $cat_id    = $course_settings['cat_id'] ? $course_settings['cat_id'] : array();
         $limit     = $course_settings['limit'];
         $featured  = ! empty( $course_settings['featured'] ) ? true : false;
         $sort      = $course_settings['order'];
         $thumb_w   = ( ! empty( $course_settings['thumbnail_width'] ) && '' != $course_settings['thumbnail_width'] ) ? $course_settings['thumbnail_width'] : apply_filters( 'thim_course_thumbnail_width', 450 );
         $thumb_h   = ( ! empty( $course_settings['thumbnail_height'] ) && '' != $course_settings['thumbnail_height'] ) ? $course_settings['thumbnail_height'] : apply_filters( 'thim_course_thumbnail_height', 400 );
         $cat_id_tab = $course_settings['tabs-options']['cat_id_tab'] ? $course_settings['tabs-options']['cat_id_tab'] : array();

         $condition = array(
            'post_type'           => 'lp_course',
            'posts_per_page'      => $limit,
            
         );
        
         if ( is_array($cat_id) ) {

               $condition['tax_query'] = array(
                  array(
                     'taxonomy' => 'course_category',
                     'field'    => 'term_id',
                     'terms'    => $cat_id
                  ),
               );
            
         }

         $course_tags_list = $settings['course_tags_list'];
         if ( is_array($course_tags_list) && count($course_tags_list) ) {

               $condition['tax_query'] = array(
                  array(
                     'taxonomy' => 'course_tag',
                     'field'    => 'term_id',
                     'terms'    => $course_tags_list
                  ),
               );
            
         }

         if ( $sort == 'popular' ) {
            global $wpdb;
            $query = $wpdb->prepare( "
            SELECT ID, a+IF(b IS NULL, 0, b) AS students FROM(
               SELECT p.ID as ID, IF(pm.meta_value, pm.meta_value, 0) as a, (
                     SELECT COUNT(*)
                  FROM (SELECT COUNT(item_id), item_id, user_id FROM {$wpdb->prefix}learnpress_user_items GROUP BY item_id, user_id) AS Y
                  GROUP BY item_id
                  HAVING item_id = p.ID
                  ) AS b
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id  AND pm.meta_key = %s
                  WHERE p.post_type = %s AND p.post_status = %s
                  GROUP BY ID
                  ) AS Z
                  ORDER BY students DESC
                     LIMIT 0, $limit
                  ", '_lp_students', 'lp_course', 'publish' );

            $post_in = $wpdb->get_col( $query );

            $condition['post__in'] = $post_in;
            $condition['orderby']  = 'post__in';
         }

         if( $featured ) {
            $condition['meta_query'] = array(
               array(
                  'key' => '_lp_featured',
                  'value' =>  'yes',
               )
            );
         }


         $the_query = new \WP_Query( $condition );


       ?>
        <?php if ( $the_query->have_posts() ) : ?>
            <?php if($settings['layout'] =='grid-1'): ?>  
                <div class="row">
                    <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                      <?php

                            $terms         = get_the_terms( $post->ID, 'course_category' );
                            $cat           = '';
                            $cat_with_link = '';
                          
                            if(is_array($terms)):
            
                              foreach($terms as $tkey=>$term):
                                  
                              $cat.= $term->slug.' ';
                              
            
                              endforeach;
            
                            endif; 
                            
                            $cat_with_link     = bisy_course_cageory_by_id($post->ID);
                            $course            = LP()->global['course'];
                            $lessons           = $course->get_curriculum_items( 'lp_lesson' )?count( $course->get_curriculum_items( 'lp_lesson' ) ) : 0;
                            $students_enrolled = $course->get_users_enrolled();
                            $instructor        = $course->get_instructor();
                            $instructor_link   = $course->get_instructor_html();
                            $instructor_id     = $course->get_id();
                            $meta              = get_post_meta( $post->ID );
                                        
                            $featured = isset($meta['_lp_featured'][0]) ? $meta['_lp_featured'][0] : '';
                            //fw_print(get_class_methods($course));  
                      ?>
                      <div class="col-lg-4 col-md-6">
                        <div class="feature-course-item-2">
                              
                              <?php 
                                  echo wp_kses_post($cat_with_link);
                              ?>
                              <h4 class="title"><a href="<?php echo esc_url($course->get_permalink()); ?>"> <?php echo esc_html(get_the_title()); ?> </a></h4>
                              <div class="fcf-bottom">
                                  <a class="bisy-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_book_alt"></i> <?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','bisy-essential'); ?></a>
                                  <a class="bisy-students" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_profile"></i> <?php echo esc_html($students_enrolled); ?> </a>
                              </div>
                              <?php if( $settings['image_type'] == 'feature' ): ?>
                              
                                <?php if(has_post_thumbnail()): ?>
                                    <div class="fcf-thumb">
                                      <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_id(),'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                    </div>
                                <?php endif; ?>

                              <?php elseif($settings['image_type'] == 'course'): ?>  

                                  <?php  $course_image = bisy_meta_option( get_the_id(), 'course_image','','bisy_lp_course_options');  ?>
                                  <?php if( isset($course_image['url']) && $course_image['url'] !=''): ?>
                                    <div class="fcf-thumb">
                                      <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                    </div>
                                  <?php endif; ?>

                              <?php elseif($settings['image_type'] == 'icon'): ?>  

                                  <?php  $course_image = bisy_meta_option( get_the_id(), 'course_icon','','bisy_lp_course_options');  ?>
                                  <?php if( isset($course_image['url']) && $course_image['url'] !=''): ?>
                                    <div class="fcf-thumb">
                                      <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                    </div>
                                  <?php endif; ?>
                                  
                              <?php endif; ?>
                              <div class="hover-course">
                                  <div class="course-price">
                                      <?php if($course->is_free()): ?>
                                          <?php echo esc_html__('free','bisy-essential'); ?>
                                      <?php else: ?>
                                          
                                          <?php if( $course->has_sale_price() ): ?> 
                                            <?php echo $course->get_price_html(); ?> 
                                          <?php endif; ?>
                                          <span> <?php echo $course->get_origin_price_html(); ?> </span>   

                                      <?php endif; ?>
                                    
                                  </div>
                                  <?php 
                                      $dir          = learn_press_user_profile_picture_upload_dir();
                                      $user         = get_user_by( 'id', $instructor->get_id());
                                      $pro_link     = get_user_meta($user->ID,'_lp_profile_picture',true);
                                      $base_url     = isset($dir['baseurl'])?$dir['baseurl']:'';
                                      $profile_link = $base_url.'/'.$pro_link;
        
                                  ?>
                                  <div class="author">
                                    <img src="<?php echo esc_url( get_avatar_url( $instructor->get_id() ) ); ?>">
                                    <?php  echo wp_kses_post($instructor_link) ?>
                                  </div>
                                  <?php if( function_exists( 'learn_press_get_course_rate' ) && $settings['course_rating_show'] =='yes' ): ?>
                                        <?php
                                            $course_rate_res = learn_press_get_course_rate( $post->ID, false );
                                            $course_rate     = $course_rate_res['rated'];
                                            $total           = $course_rate_res['total'];

                                        ?>
                                        <div class="ratings">
                                             <?php foreach (range(1, 5) as $hnumber): ?>
                                                <i class="icon_star <?php echo esc_attr($hnumber<=$course_rate?'active':'inactive'); ?>"></i>
                                              <?php endforeach; ?>
                                          <span><?php echo $course_rate; ?> (<?php echo sprintf( __( '%s Reviews', 'bisy-essential' ), $total ); ?>)</span>
                                        
                                        </div>
                                  <?php endif; ?>
                            
                              </div>
                        </div>
                      </div>
                  <?php endwhile; wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>
            <?php if($settings['layout'] =='tabs'): ?> 
              
                <!-- Feature Course Start -->
                <section class="feature-course-section">
                    <div class="container">
                        <div class="row">
                        <?php if($settings['heading_top_title'] !='' || $settings['heading_title'] !=''): ?>
                            <div class="col-lg-5 col-md-12">
                               
                                    <h2 class="sec-title">
                                        <?php if( $settings['heading_top_title'] !='' ): ?>
                                        <span><?php echo esc_html( $settings['heading_top_title'] ); ?></span> 
                                        <?php endif; ?>
                                        <?php echo esc_html( $settings['heading_title'] ); ?>
                                    </h2>
                                       
                            </div>
                            <?php endif; ?>
                            <div class="col-md-12 col-lg-<?php echo esc_attr($settings['heading_top_title'] !='' || $settings['heading_title'] !=''?'7':'12'); ?>">
                                <ul class="shaf-filter">
                                    <li class="active" data-group="all"><?php echo esc_html__( 'All','bisy-essential' ); ?></li>
                                   
                                    <?php	
                                          foreach((array)$cat_id_tab as $key=> $tacat_id):
                                            if($key==$limit_tab){
                                              break;
                                            }

                                          $category =  get_term($tacat_id);
                                          
                                        ?>
                                        <li data-group="<?php echo esc_attr($category->slug); ?>"><?php echo esc_html($category->name); ?> </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="row shafull-container">
                              <?php

                                  while ( $the_query->have_posts() ) : $the_query->the_post();

                                      $category_groups      = [];
                                      $terms                = get_the_terms( $post->ID, 'course_category' );
                                      $cat                  = '';
                                      $cat_with_link        = '';
                                      $single_category_name = '';
                                  
                                      if(is_array($terms)):

                                        foreach($terms as $tkey=>$term):
                                          $cat.= $term->slug.' ';
                                          $category_groups[] = $term->slug;
                                          $single_category_name =  $term->name;
                                        endforeach;

                                      endif; 

                                      $cat_with_link     = bisy_course_cageory_by_id($post->ID);
                                      $course            = LP()->global['course'];
                                      $lessons           = $course->get_curriculum_items( 'lp_lesson' )? count( $course->get_curriculum_items( 'lp_lesson' ) ) : 0;
                                      $students_enrolled = $course->get_users_enrolled();
                                      $instructor        = $course->get_instructor();
                                      $instructor_link   = $course->get_instructor_html();
                                      $instructor_id     = $course->get_id();
                                      $meta              = get_post_meta( $post->ID );
                                      $featured          = isset($meta['_lp_featured'][0]) ? $meta['_lp_featured'][0] : '';
                                      
                                     
                                          
                              ?>
                                <div class="col-lg-4 col-md-6 shaf-item" data-groups='<?php echo json_encode($category_groups); ?>'>
                                    <div class="feature-course-item">
                                        <div class="flipper">
                                            <div class="front">
                                                <?php if( $settings['image_type'] == 'feature' ): ?>
                                  
                                                  <?php if(has_post_thumbnail()): ?>
                                                      <div class="fcf-thumb">
                                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_id(),'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                      </div>
                                                  <?php endif; ?>

                                                <?php elseif($settings['image_type'] == 'course'): ?>  

                                                    <?php  $course_image = bisy_meta_option( get_the_id(), 'course_image','','bisy_lp_course_options');  ?>
                                                    <?php if( isset($course_image['url']) && $course_image['url'] !=''): ?>
                                                      <div class="fcf-thumb">
                                                        <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                      </div>
                                                    <?php endif; ?>

                                                <?php elseif($settings['image_type'] == 'icon'): ?>  

                                                    <?php  $course_image = bisy_meta_option( get_the_id(), 'course_icon','','bisy_lp_course_options');  ?>
                                                    <?php if(isset($course_image['url']) && $course_image['url'] !=''): ?>
                                                      <div class="fcf-thumb">
                                                        <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                      </div>
                                                    <?php endif; ?>
                                                    
                                                <?php endif; ?>
                                                <p class="c-cate"> <?php echo esc_html($single_category_name); ?> </p>
                                                <h4 class="title"> <?php echo esc_html(get_the_title()); ?> </h4>
                                                <div class="fcf-bottom">
                                                    <a class="bisy-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_book_alt"></i><?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','bisy-essential'); ?></a>
                                                    <a class="bisy-students" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_profile"></i><?php echo esc_html($students_enrolled); ?></a>
                                                </div>
                                            </div>
                                            <div class="back">
                                              

                                                  <?php if( $settings['back_image_type'] == 'feature' ): ?>
                              
                                                    <?php if(has_post_thumbnail()): ?>
                                                        <div class="fcf-thumb">
                                                          <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_id(),'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                        </div>
                                                    <?php endif; ?>

                                                  <?php elseif($settings['back_image_type'] == 'course'): ?>  

                                                      <?php  $course_image = bisy_meta_option( get_the_id(), 'course_image','','bisy_lp_course_options');  ?>
                                                      <?php if( isset($course_image['url']) && $course_image['url'] !=''): ?>
                                                        <div class="fcf-thumb">
                                                          <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                        </div>
                                                      <?php endif; ?>

                                                  <?php elseif($settings['back_image_type'] == 'icon'): ?>  

                                                      <?php  $course_image = bisy_meta_option( get_the_id(), 'course_icon','','bisy_lp_course_options');  ?>
                                                      <?php if( isset($course_image['url']) && $course_image['url'] !=''): ?>
                                                        <div class="fcf-thumb">
                                                          <img src="<?php echo esc_url($course_image['url']); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                        </div>
                                                      <?php endif; ?>
                                                      
                                                  <?php endif; ?>
                                             
                                                  <?php 
                                                      echo wp_kses_post($cat_with_link);
                                                  ?>
                                              
                                                <h4 class="title"><a href="<?php echo esc_url($course->get_permalink()); ?>"><?php echo esc_html(get_the_title()); ?></a></h4>
                                                <?php if( function_exists( 'learn_press_get_course_rate' ) && $settings['course_rating_show'] =='yes' ): ?>
                                                      <?php
                                                          $course_rate_res = learn_press_get_course_rate( $post->ID, false );
                                                          $course_rate     = $course_rate_res['rated'];
                                                          $total           = $course_rate_res['total'];
                       
                                                      ?>
                                                      <div class="ratings">
                                                      <?php foreach (range(1, 5) as $hnumber): ?>
                                                        <i class="icon_star <?php echo esc_attr($hnumber<=$course_rate?'active':'inactive'); ?>"></i>
                                                      <?php endforeach; ?>
                                                        <span><?php echo esc_html($course_rate); ?> (<?php echo sprintf( __( '%s Reviews', 'bisy-essential' ), $course_rate ); ?>)</span>
                                                      
                                                      </div>
                                                <?php endif; ?>
                                                <div class="course-price">

                                                      <?php if($course->is_free()): ?>
                                                          <?php echo esc_html__('free','bisy-essential'); ?>
                                                      <?php else: ?>
                                                          
                                                          <?php if( $course->has_sale_price() ): ?> 
                                                            <?php echo $course->get_price_html(); ?> 
                                                          <?php endif; ?>
                                                          <span> <?php echo $course->get_origin_price_html(); ?> </span>  

                                                      <?php endif; ?>

                                                </div>
                                                 <?php 
                                                      $dir          = learn_press_user_profile_picture_upload_dir();
                                                      $user         = get_user_by( 'id', $instructor->get_id());
                                                      $pro_link     = get_user_meta($user->ID,'_lp_profile_picture',true);
                                                      $base_url     = isset($dir['baseurl'])?$dir['baseurl']:'';
                                                      $profile_link = $base_url.'/'.$pro_link;
                        
                                                  ?>
                                                <div class="author">
                                                  <img src="<?php echo esc_url( get_avatar_url( $instructor->get_id() ) ); ?>">
                                                  <?php  echo wp_kses_post($instructor_link) ?>
                                                </div>
                                                <div class="fcf-bottom">
                                                    <a class="bisy-lesson" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_book_alt"></i><?php echo esc_html($lessons); ?> <?php echo esc_html__('Lessons','bisy-essential'); ?></a>
                                                    <a class="bisy-students" href="<?php echo esc_url($course->get_permalink()); ?>"><i class="icon_profile"></i><?php echo esc_html($students_enrolled); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             <?php endwhile; wp_reset_postdata(); ?>
                        </div>
                    </div>
                </section>
                <!-- Feature Course End -->

            <?php endif; ?>
         <?php
          endif;
         ?>
       <?php

         
      }
  
      
    }
   
    public function course_list(){
      if(!defined('LP_COURSE_CPT')){
        return [];
      }
      $args = array(

        'post_type'   => 'lp_course',
        'orderby' => 'post_date', 
        'order' => 'DESC',
        'post_status'  => 'publish',
        'posts_per_page' => -1
                  
        );  

        $lp_course = get_posts( $args ); 
        $course_list = [];
       
        foreach ($lp_course as $postdata) {
            setup_postdata( $postdata );
            $course_list[$postdata->ID] = [$postdata->post_title];
         
        }
      
        return $course_list;
    }

 

}