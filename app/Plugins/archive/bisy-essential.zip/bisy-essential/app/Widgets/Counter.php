<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Counter extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-counter';
    }

    public function get_title() {
        return esc_html__( 'Bisy Counter', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Counter settings', 'bisy-essential'),
            ]
        );
         
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bisy-essential' ),
					'style2' => esc_html__( 'Style 2', 'bisy-essential' ),
					'style3' => esc_html__( 'Style 3', 'bisy-essential' ),
				],
			]
		);
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'bisy-essential' ),
				'description' => esc_html__( 'Use \n for new line . for style 2' , 'bisy-essential' ),
				'label_block' => true,
			]
		);
     
		$repeater->add_control(
			'list_number', [
				'label'      => esc_html__( 'Number', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '250' , 'bisy-essential' ),
				'show_label' => true,
			]
        );
        
        $repeater->add_control(
			'list_number_type', [
				'label'      => esc_html__( 'Symbol', 'bisy-essential' ),
				'type'       => \Elementor\Controls_Manager::TEXT,
				'default'    => esc_html__( '+' , 'bisy-essential' ),
				'show_label' => false,
			]
		);

        $repeater->add_control(
            'list_icon',
            [
                'label' => esc_html__( 'Choose Icon', 'bisy-essential' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );
  
        $repeater->add_control(
            'content_s_color', [

                'label'     => esc_html__( 'Title Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} p' => 'color: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}}.funfact-item-2 p' => 'color: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}}.funfact-item-3 p' => 'color: {{VALUE}};',
           
                ],
            ]
        );

        $repeater->add_control(
            'content_number_color', [

                'label'     => esc_html__( 'Number Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}} h2' => 'color: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}}.funfact-item-2 h2' => 'color: {{VALUE}};',
                '{{WRAPPER}} {{CURRENT_ITEM}}.funfact-item-3 h2' => 'color: {{VALUE}};',
           
                ],
            ]
        );

        $repeater->add_group_control(
            \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'iconinner_s_background',
                    'label'    => esc_html__( 'Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
                ]
            );
        
        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Counter List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 

 
        $this->add_responsive_control(
			'content_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .funfact-item' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .funfact-item-2' => 'text-align: {{VALUE}};',
                     '{{WRAPPER}} .funfact-item-3' => 'text-align: {{VALUE}};',
                  

				],
			]
        );//Responsive control end
        $this->end_controls_section();
       
       
        //Title Style Section
		$this->start_controls_section(
			'section_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .funfact-item p' => 'color: {{VALUE}};',
                            '{{WRAPPER}} .funfact-item-2 p' => 'color: {{VALUE}};',
                            '{{WRAPPER}} .funfact-item-3 p' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .funfact-item p,{{WRAPPER}} .funfact-item-2 p,{{WRAPPER}} .funfact-item-3 p',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                    
                        'selectors'  => [
                            '{{WRAPPER}} .funfact-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-2 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-3 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

         //Title Style Section
		$this->start_controls_section(
			'section_content_style', [
				'label' => esc_html__( 'Number', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'content_color', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                          '{{WRAPPER}} .funfact-item h2 span' => 'color: {{VALUE}};',
                          '{{WRAPPER}} .funfact-item-2 h2 span' => 'color: {{VALUE}};',
                          '{{WRAPPER}} .funfact-item-3 h2 span' => 'color: {{VALUE}};',
                       
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                        
                        'selector' => '{{WRAPPER}} .funfact-item h2 span,{{WRAPPER}} .funfact-item-2 h2 span,{{WRAPPER}} .funfact-item-3 h2 span',
                    ]
                );

                $this->add_control(
                    'content_tag_color', [

                        'label'     => esc_html__( 'Symbol Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .funfact-item h2' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .funfact-item-2 h2' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'content_tag_typho',
                        'label'    => esc_html__( 'Symbol Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .funfact-item h2,{{WRAPPER}} .funfact-item-2 h2',
                    ]
                );

                $this->add_responsive_control(
                    'content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .funfact-item h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-3 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .funfact-item h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-3 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section('bisy_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

                $this->add_responsive_control(
                    '_item_content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .funfact-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        ],
                        'separator' => 'before',
                    ]
                );
                
                $this->add_responsive_control(
                    '_item_content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .funfact-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            
                        ],
                        'separator' => 'before',
                    ]
                );   

                $this->add_responsive_control(
                    '_item__box_border_radius',
                    [
                        'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%' ],
                        'selectors' => [
                            '{{WRAPPER}} .funfact-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            '{{WRAPPER}} .funfact-item-3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                            
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => '_item_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .funfact-item,{{WRAPPER}} .funfact-item-2,{{WRAPPER}} .funfact-item-3',
                        ]
                );

                $this->add_control(
                    'border2_popover_toggle',
                    [
                        'label' => esc_html__( 'Hover Border', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                        'label_off' => esc_html__( 'Default', 'bisy-essential' ),
                        'label_on' => esc_html__( 'Over Top Color', 'bisy-essential' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                        
                    ]
                );

                $this->start_popover();
                $this->add_control(
                    'item_border_top_color_border', [

                        'label'     => esc_html__( 'Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .funfact-item:hover' => 'box-shadow: 0px -2px 0px 0px {{VALUE}}',
                        '{{WRAPPER}} .funfact-item-2:hover' => 'box-shadow: 0px -2px 0px 0px {{VALUE}}',
                    
                        ],
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'item_border__top_box_shadow',
                        'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .funfact-item:hover,{{WRAPPER}} .funfact-item-2:hover',
                    ]
                );

                $this->end_popover();

               


        $this->end_controls_section();

        $this->start_controls_section('bisy_icon_section',
            [
            'label' => esc_html__( 'Image Icon', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [ 'style' => ['style2'] ],
            ]
        );

        $this->add_control(
            'thumbnail_bg_color', [

                'label'     => esc_html__( 'Background Color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                  '{{WRAPPER}} .funfact-item-2 .fact-thumb' => 'background: {{VALUE}};',
              
               
                ],
            ]
        );

        $this->end_controls_section();

        

        $this->start_controls_section('bisy_main_section',
                [
                'label' => esc_html__( 'Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );

                    $this->add_group_control(
                        \Elementor\Group_Control_Background:: get_type(),
                            [
                                'name'     => 'main_section_before_background',
                                'label'    => esc_html__( 'Background', 'bisy-essential' ),
                                'types'    => [ 'classic', 'gradient', 'video' ],
                                'selector' => '{{WRAPPER}} .main-section:before',
                            ]
                        );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
		$list  = $settings['list'];
	    
    ?>
        <?php if($settings['style'] == 'style1'): ?>
            <div class="fact-wrapper main-section">
                <?php foreach($list as $item): ?>
                    <div class="funfact-item elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?>">
                        <?php if( $item['list_icon']['url'] !='' ): ?> 
                            <img src="<?php echo esc_url($item['list_icon']['url']); ?>" alt="<?php echo esc_attr($item['list_title']); ?>">
                        <?php endif; ?>
                        <?php if( $item['list_number'] !='' ): ?>
                            <h2><span data-counter="<?php echo esc_attr($item['list_number']); ?>" class="timer"> <?php echo esc_html($item['list_number']); ?> </span><?php echo esc_html($item['list_number_type']); ?></h2>
                        <?php endif; ?>
                        <?php if( $item['list_title'] !='' ): ?>
                            <p><?php echo esc_html($item['list_title']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>   

         <?php if($settings['style'] == 'style2'): ?>
            <div class="fact-wrapper main-section">
                 <?php foreach($list as $item): ?>
                    <div class="funfact-item-2 elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?>">
                        <?php if( $item['list_icon']['url'] !='' ): ?> 
                            <div class="fact-thumb">
                                <img src="<?php echo esc_url($item['list_icon']['url']); ?>" alt="<?php echo esc_attr($item['list_title']); ?>">
                            </div>
                        <?php endif; ?>
                        <?php if( $item['list_number'] !='' ): ?>
                            <h2><span data-counter="<?php echo esc_attr($item['list_number']); ?>" class="timer"><?php echo esc_attr($item['list_number']); ?></span>+</h2>
                        <?php endif; ?>
                        <?php if( $item['list_title'] !='' ): ?>
                            <p><?php echo str_replace(['\n'],['<br/>'],$item['list_title']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>  

        <?php if($settings['style'] == 'style3'): ?>
            <div class="main-section">
                <div class="container">
                    <div class="row">
                            <?php foreach($list as $item): ?>
                                <div class="col-lg-3 col-md-6">
                                    <div class="funfact-item-3 elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) ?>">
                                        <?php if( $item['list_icon']['url'] !='' ): ?> 
                                            <img src="<?php echo esc_url($item['list_icon']['url']); ?>" alt="<?php echo esc_attr($item['list_title']); ?>">
                                        <?php endif; ?>
                                        <h2><span data-counter="<?php echo esc_attr($item['list_number']); ?>" class="timer"><?php echo esc_attr($item['list_number']); ?></span></h2>
                                        <?php if( $item['list_title'] !='' ): ?>
                                        <p> <?php echo esc_html($item['list_title']); ?> </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>    
                    </div>
                </div>
            </div>
        <?php endif; ?>  

    <?php  

    }
    
    protected function _content_template() { }
}