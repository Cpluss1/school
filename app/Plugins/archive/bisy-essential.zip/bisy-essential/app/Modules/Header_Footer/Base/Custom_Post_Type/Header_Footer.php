<?php
/**
 * @package  Appscres-essential
 */
namespace BisyEssential\Modules\Header_Footer\Base\Custom_Post_Type;

use BisyEssential\Api\Callbacks\Custom_Post;
use Carbon_Fields\Container;
use Carbon_Fields\Field;


class Header_Footer extends Custom_Post
{

    public $name         = 'Header Footers';
    public $menu         = 'Header Footer';
    public $textdomain   = '';
    public $posts        = array();
    /*
    * plublic_query true for 
    * elementor support 
    */
    public $public_quary = true;
    public $slug         = 'header-footer';
    public $search       = true;

	public function register() {

        $this->textdomain = 'bisy-essential';
        $this->posts      = array();
       
        add_action( 'init', array( $this, 'create_post_type' ) );
       
        add_filter('save_post_qheader-footer', array( $this, 'update_template' ), 10,3 );
       
        add_action( 'carbon_fields_register_fields', [ $this,'metabox_options'] );

    }
    public function metabox_options(){
        
        Container::make( 'post_meta', 'Settings' )
            ->where( 'post_type', '=', 'qheader-footer' )
            ->add_fields( array(
                Field::make( 'select', 'qhf_template_type', esc_html__( 'Style/ Position','bisy-essential' ) )
                ->set_options( array(
                    'header' => esc_html__( 'Header', 'bisy-essential' ),
                    'footer' => esc_html__( 'Footer', 'bisy-essential' ),
                   
                ) ),
              
                 
            ));
    }
    public function create_post_type(){

        if( !current_user_can('manage_options') ){
            return;
        }
        
        $this->init( 'qheader-footer', $this->name, $this->menu, array( 'menu_icon' => 'dashicons-text-page',
            'supports'            => array( 'title'),
            'rewrite'             => array( 'slug' => $this->slug ),
            'exclude_from_search' => $this->search,
            'has_archive'         => false,                            // Set to false hides Archive Pages
            'publicly_queryable'  => $this->public_quary,
            'hierarchical'        => false,
        ) 

       );

       $this->register_custom_post();
       $this->add_elementor_editor_support();
    }
    /* keep public_query true
    * @return void
    */ 
    public function add_elementor_editor_support() {
	   
		add_post_type_support( 'qheader-footer', 'elementor' );
		
    }

    public function update_template( $post_id,$post ,$update ){
      
        if($update):

            if(isset($_POST['page_template'])):

                $template = $_POST['page_template'];

                if(get_post_type($post_id) =='qheader-footer'):
                    update_post_meta( $post_id, '_wp_page_template', $template );
                endif;
                
            endif;

        else:

            update_post_meta( $post_id, '_wp_page_template', 'elementor_canvas' );

        endif;  
     
      
    }

    public function get_template_display_option(){

        $post_types       = get_post_types();

		$post_types_unset = array(
			'attachment'          => 'attachment',
			'revision'            => 'revision',
			'nav_menu_item'       => 'nav_menu_item',
			'custom_css'          => 'custom_css',
			'customize_changeset' => 'customize_changeset',
			'oembed_cache'        => 'oembed_cache',
			'user_request'        => 'user_request',
			'wp_block'            => 'wp_block',
			'elementor_library'   => 'elementor_library',
			'btf_builder'         => 'btf_builder',
			'elementor-hf'        => 'elementor-hf',
			'elementor_font'      => 'elementor_font',
			'elementor_icons'     => 'elementor_icons',
			'wpforms'             => 'wpforms',
			'wpforms_log'         => 'wpforms_log',
			'acf-field-group'     => 'acf-field-group',
			'acf-field'           => 'acf-field',
			'booked_appointments' => 'booked_appointments',
			'wpcf7_contact_form'  => 'wpcf7_contact_form',
			'scheduled-action'    => 'scheduled-action',
			'shop_order'          => 'shop_order',
			'shop_order_refund'   => 'shop_order_refund',
			'shop_coupon'         => 'shop_coupon',
        );
        
        $diff             = array_diff( $post_types, $post_types_unset );
        
		$default          = array(
			'all'       => esc_html__( 'All', 'bisy-essential'),
			'blog'      => esc_html__( 'Blog Page' , 'bisy-essential'),
			'archive'   => esc_html__( 'Archive Page' , 'bisy-essential'),
			'post'      => esc_html__( 'Post Page' , 'bisy-essential'),
			'page'      => esc_html__( 'Page Page' , 'bisy-essential'),
			'author'    => esc_html__( 'Author Page' , 'bisy-essential'),
			'tags'      => esc_html__( 'Tags Page' , 'bisy-essential'),
			'category'  => esc_html__( 'Category Page' , 'bisy-essential'),
			'search'    => esc_html__( 'Search Page' , 'bisy-essential'),
			'not_found' => esc_html__( '404 Page' , 'bisy-essential'),
        );
        
		$options   = array_merge( $default, $diff );

        return $options;
    }
   
}