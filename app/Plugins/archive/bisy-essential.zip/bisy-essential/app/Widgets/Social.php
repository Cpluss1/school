<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Social extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-social';
    }

    public function get_title() {
        return esc_html__( 'Bisy Social', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-share-alt";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Social Settings', 'bisy-essential'),
            ]
        );

            $this->add_control(
                    'title', [
                        'label'       => esc_html__( 'Heading', 'bisy-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXT,
                        'default'     => esc_html__( 'Follow Us' , 'bisy-essential' ),
                        'label_block' => true,
                    ]
            );
      
            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'list_title', [
                    'label'       => esc_html__( 'Title', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => esc_html__( 'List Title' , 'bisy-essential' ),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'list_website_link',
                [
                    'label'       => esc_html__( 'Link', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => esc_html__( 'https://your-link.com', 'bisy-essential' ),
                    
                ]
            );

            $repeater->add_control(
                'list_icon',
                [
                    'label'   => esc_html__( 'Icon', 'bisy-essential' ),
                    'type'    => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value'   => 'fas fa-star',
                        'library' => 'solid',
                    ],
                ]
            );
    
            $repeater->add_control(
                'list_color',
                [
                    'label'     => esc_html__( 'Color', 'bisy-essential' ),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} i'          => 'color: {{VALUE}}',
                        '{{WRAPPER}} {{CURRENT_ITEM}} svg path'   => 'fill: {{VALUE}}',
                        '{{WRAPPER}} {{CURRENT_ITEM}} svg g path' => 'fill: {{VALUE}}',
                    ],
                ]
            );

            $repeater->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                [
                    'name'     => 'social_input_section_background2',
                    'label'    => esc_html__( 'Background', 'bisy-essential' ),
                    'types'    => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
                ]
            );

            $this->add_control(
                'list',
                [
                    'label'       => esc_html__( 'Social List', 'bisy-essential' ),
                    'type'        => \Elementor\Controls_Manager::REPEATER,
                    'fields'      => $repeater->get_controls(),
                    'title_field' => '{{{ list_title }}}',
                ]
            );


   
        $this->add_responsive_control(
			'title_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left' => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
           
                'selectors' => [
                     '{{WRAPPER}} .ab-social ' => 'text-align: {{VALUE}};',

				],
			]
        );//Responsive control end
        $this->end_controls_section();

        $this->start_controls_section('bisy_style_heading_title_section',
            [
            'label' => esc_html__( 'Title', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
     
                $this->add_control(
                'heading_title_color',
                    [
                        'label'   => esc_html__('Color', 'bisy-essential'),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .ab-social h5'   => 'color: {{VALUE}};',
                        ],
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'post_title_typography',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                    
                        'selector' => '{{WRAPPER}} .ab-social h5',
                        
                    ]
                );

                $this->add_responsive_control(
                'heading_title_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                        '{{WRAPPER}} .ab-social h5'       => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        
                        ],
                    ]
                );

                $this->add_responsive_control(
                'heading_title_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                            '{{WRAPPER}} .ab-social h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                    ]
                );

        $this->end_controls_section();
  
        //Title Style Section
		$this->start_controls_section(
			'section_social_style', [
				'label' => esc_html__( 'Social', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Icon Color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .ab-social a i' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .ab-social a svg path' => 'fill: {{VALUE}};',
                        '{{WRAPPER}} .ab-social a svg g path' => 'fill: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                     
                        'selector' => '{{WRAPPER}} .ab-social i',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .ab-social a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors'  => [
                            '{{WRAPPER}} .ab-social a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_responsive_control(
                    'social_borders__radius',
                    [
                       'label'      => esc_html__( 'Border radius', 'bisy-essential' ),
                       'type'       => Controls_Manager::DIMENSIONS,
                       'size_units' => [ 'px'],
                       'selectors'  => [
                          
                          '{{WRAPPER}} .ab-social a'      => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                      
                          
                       ],
                    ]
                 );

        $this->end_controls_section();

        
        $this->start_controls_section('bisy_box_inner_main_section',
                [
                'label' => esc_html__( 'Box', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
           
            
            $this->add_responsive_control(
                'box_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .ab-social' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'box_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .ab-social' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );

        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

		$settings  = $this->get_settings();
	 
        
       
    ?>
              
                <div class="ab-social">
                    <?php if($settings['title'] !=''): ?>
                        <h5> <?php echo esc_html($settings['title']); ?> </h5>
                    <?php endif; ?>
                    <?php foreach($settings['list'] as $item): ?>  
                        <?php $list_website_link =  $item['list_website_link']; ?>
                        <a
                            rel="<?php echo esc_attr($list_website_link['nofollow']=='on'?'nofollow':'follow'); ?>" 
                            target="<?php echo esc_attr($list_website_link['is_external']=='on'?'_blank':'_self'); ?>"
                            class="single_social elementor-repeater-item-<?php echo esc_attr($item['_id']); ?>"
                            href=" <?php echo esc_url($list_website_link['url']); ?>">
                            <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </a>
                    <?php endforeach; ?> 
                </div>
    <?php  

    }
    
    protected function _content_template() { }
}