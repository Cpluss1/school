<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Custom_Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

class Testimonial extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-testimonial';
    }

    public function get_title() {
        return esc_html__( 'Bisy Testimonial', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fas fa-quote-left";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() { 

     
   
    $this->start_controls_section('section_tab',
         [
            'label' => esc_html__('Contents', 'bisy-essential'),
         ]
      );

      
    

      $this->add_responsive_control(
			'content_align', [
				'label'   => esc_html__( 'Content Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
             
           'selectors' => [
              '{{WRAPPER}} blockquote' => 'text-align: {{VALUE}};',
              
         
				],
			]
        );//Responsive control end

     
		
      $this->add_control(
			'testimonial',
			[
				'label'       => esc_html__( 'Testimonial', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => esc_html__( 'Default testimonial', 'bisy-essential' ),
				'placeholder' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing', 'bisy-essential' ),
			]
      );
      
     

      $this->add_control(
			'client_name',
			[
				'label'       => esc_html__( 'Client name', 'bisy-essential' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Shuvas Chandra', 'bisy-essential' ),
				'placeholder' => esc_html__( 'Type your client name here', 'bisy-essential' ),
			]
      );

      $this->end_controls_section();

    
      $this->start_controls_section('bisy_content_style_section',
         [
            'label' => esc_html__( 'Content Style', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
         ]
      );
     
   
               $this->add_responsive_control('box_padding_n',
                  [
                     'label'      => esc_html__( 'Testimonial Padding', 'bisy-essential' ),
                     'type'       => Controls_Manager::DIMENSIONS,
                     'size_units' => [ 'px' ],
                     
                     'selectors' => [
                        '{{WRAPPER}} blockquote p' => 'padding-left: {{LEFT}}{{UNIT}};padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}}; padding-right:{{RIGHT}}{{UNIT}};',
                     
                     ],
                  ]
               );
 
      
               $this->add_control(
                  'testimonial_color',
                     [
                        'label'     => esc_html__('Testimonial color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} blockquote p' => 'color: {{VALUE}};',
                        ],
                     ]
               );

               $this->add_group_control(
                  Group_Control_Typography:: get_type(),
                  [
                     'name'     => 'testimonial_typho',
                     'label'    => esc_html__( 'Testimonial Typography', 'bisy-essential' ),
                   
                     'selector' => '{{WRAPPER}} blockquote p',
                  ]
               );

               $this->add_control(
                  'client_color',
                     [
                        'label'     => esc_html__('Client color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} blockquote cite' => 'color: {{VALUE}};',
                           
                        ],
                     ]
               );

               
               $this->add_control(
                  'client_hover_color',
                     [
                        'label'     => esc_html__('Client Hover color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} blockquote:hover cite' => 'color: {{VALUE}};',
                           
                        ],
                     ]
               );

               $this->add_group_control(
                  Group_Control_Typography:: get_type(),
                  [
                     'name'     => 'client_typho',
                     'label'    => esc_html__( 'Client Typography', 'bisy-essential' ),
                   
                     'selector' => '{{WRAPPER}} blockquote cite',
                  ]
               );

               $this->add_control(
                  'box_left_icon_color',
                     [
                        'label'     => esc_html__('Left Icon color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} blockquote:before' => 'color: {{VALUE}};',
                        ],
                     ]
               );

               $this->add_control(
                  'box_right_icon_color',
                     [
                        'label'     => esc_html__('Right Icon color', 'bisy-essential'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                           '{{WRAPPER}} blockquote:after' => 'color: {{VALUE}};',
                        ],
                     ]
               );

               $this->add_responsive_control('client_margin_n',
               [
                  'label'      => esc_html__( 'Client Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%' ],
                  
                  'selectors' => [
                     '{{WRAPPER}} blockquote cite' => 'margin-left: {{LEFT}}{{UNIT}};margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}}; margin-right:{{RIGHT}}{{UNIT}};',
                  ],
               ]
            );

           
      $this->end_controls_section();  

    
      $this->start_controls_section(
			'section_box_item_style', [
				'label' => esc_html__( 'Box Item', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			  ]
      ); 

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'section_box_item_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} blockquote',
               ]
            );

            $this->add_responsive_control(
               'box_item_margin',
               [
                  'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} blockquote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                       
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_item_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} blockquote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                        ],
                  ]
            );

            $this->add_control(
               'border_box_item_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} blockquote' => 'border-radius: {{VALUE}}px;',
                      
                  ],
               ]
            );  

              
            $this->add_control(
               'box_border_color',
                  [
                     'label'     => esc_html__('Border color', 'bisy-essential'),
                     'type'      => Controls_Manager::COLOR,
                     'default'   => '',
                     'selectors' => [
                        '{{WRAPPER}} blockquote' => 'box-shadow: -4px 0px 0px 0px {{VALUE}};',
                     ],
                  ]
            );

            $this->add_group_control(
               \Elementor\Group_Control_Box_Shadow::get_type(),
               [
                  'name' => 'box_item_box_shadow',
                  'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                  'selector' => '{{WRAPPER}} blockquote',
               ]
            );

         

      $this->end_controls_section(); 


      $this->start_controls_section('bisy_main_section_section',
            [
            'label' => esc_html__( 'Section', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            ]
      );

            $this->add_group_control(
               \Elementor\Group_Control_Background:: get_type(),
               [
                  'name'     => 'section_background',
                  'label'    => esc_html__( 'Background', 'bisy-essential' ),
                  'types'    => [ 'classic', 'gradient', 'video' ],
                  'selector' => '{{WRAPPER}} .main-section',
               ]
            );
  
            $this->add_responsive_control(
               'box_margin',
               [
                  'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                  'type'       => Controls_Manager::DIMENSIONS,
                  'size_units' => [ 'px','%'],
                  'selectors'  => [
                        '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                  ],
               ]
            );

            $this->add_responsive_control(
               'box_padding',
                  [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px','%'],
                        'selectors'  => [
                           '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                  ]
            );

            $this->add_control(
               'border_radius',
                  [
                        'label' => esc_html__( 'Border radius', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::NUMBER,
                        'min'   => 0,
                        'max'   => 200,
                        'step'  => 1,
                        
                        'selectors' => [
                           '{{WRAPPER}} .main-section' => 'border-radius: {{VALUE}}px;',
                  ],
               ]
            );  
      $this->end_controls_section();
   }
   protected function render(){

     $settings         = $this->get_settings();
    
    ?>
     

         <div class="main-section">
            <blockquote>
               <?php echo wpautop( $settings['testimonial'] ); ?>
               <cite>Indigo Violet</cite>
            </blockquote>
         </div>
           
   
         
   <?php  
   }
}  