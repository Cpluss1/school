<?php
namespace BisyEssential\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;


if ( ! defined( 'ABSPATH' ) ) exit;


class Features extends Widget_Base {


    public $base;

    public function get_name() {
        return 'bisy-feature-box';
    }

    public function get_title() {
        return esc_html__( 'Bisy Feature box', 'bisy-essential' );
    }

    public function get_icon() { 
        return "fa fa-trophy";
    }

    public function get_categories() {
        return [ 'bisy-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Feature Box', 'bisy-essential'),
            ]
        );
    
                $repeater = new \Elementor\Repeater();

                $repeater->add_control(
                    'list_title', [
                        'label'       => esc_html__( 'Title', 'bisy-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXT,
                        'default'     => esc_html__( 'Design & Development' , 'bisy-essential' ),
                        'description' => esc_html__( 'Use \n for new line break.' , 'bisy-essential' ),
                        'label_block' => true,
                    ]
                );
        
                $repeater->add_control(
                    'list_content', [
                        'label'      => esc_html__( 'Content', 'bisy-essential' ),
                        'type'       => \Elementor\Controls_Manager::TEXTAREA,
                    ]
                );
            
                $repeater->add_control(
                    'list_image',
                    [
                        'label' => esc_html__( 'Choose shape', 'bisy-essential' ),
                        'type'  => \Elementor\Controls_Manager::MEDIA,
                    ]
                );

                $repeater->add_control(
                    'list_button_text', [
                        'label'       => esc_html__( 'Button Text', 'bisy-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXT,
                        'default'     => esc_html__( 'Design & Development' , 'bisy-essential' ),
                        'label_block' => true,
                    ]
                );

                $repeater->add_control(
                    'list_button_link', [
                        'label'       => esc_html__( 'Button Link', 'bisy-essential' ),
                        'type'        => \Elementor\Controls_Manager::TEXT,
                        'default'     => '#',
                        'label_block' => true,
                    ]
                );
        
		$this->add_control(
			'list',
			[
				'label'   => esc_html__( 'Feature List', 'plugin-domain' ),
				'type'    => \Elementor\Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				
				'title_field' => '{{{ list_title }}}',
			]
		);
 

 
        $this->add_responsive_control(
			'feature_item_title_align', [
				'label'   => esc_html__( 'Alignment', 'bisy-essential' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [

               'left'		 => [
                  
                  'title' => esc_html__( 'Left', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-left',
               
               ],
				'center'	     => [
                  
                  'title' => esc_html__( 'Center', 'bisy-essential' ),
                  'icon'  => 'fa fa-align-center',
               
               ],
			   'right'	 => [

						'title' => esc_html__( 'Right', 'bisy-essential' ),
						'icon'  => 'fa fa-align-right',
                  
					],
				'justify'	 => [

						'title' => esc_html__( 'Justified', 'bisy-essential' ),
						'icon'  => 'fa fa-align-justify',
                  
					],
				],
               'default' => 'center',
            
                'selectors' => [
                     '{{WRAPPER}} .feature-item' => 'text-align: {{VALUE}};',
                    

				],
			]
        );//Responsive control end
        $this->end_controls_section();

       
		$this->start_controls_section(
			'section_feature_title_style', [
				'label' => esc_html__( 'Title', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'title_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'title_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .title',
                    ]
                );

                $this->add_responsive_control(
                    'title_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'title_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_feature_content_style', [
				'label' => esc_html__( 'Content', 'bisy-essential' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                
			]
        );
                $this->add_control(
                    'feature_content_color', [

                        'label'     => esc_html__( 'Title color', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}}  .content' => 'color: {{VALUE}};',
                        ],
                    ]
                );
                
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'     => 'feature_content_typho',
                        'label'    => esc_html__( 'Typography', 'bisy-essential' ),
                      
                        'selector' => '{{WRAPPER}} .content',
                    ]
                );

                $this->add_responsive_control(
                    'work_content_section_margin',
                    [
                        'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        
                        'selectors'  => [
                            '{{WRAPPER}} .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );
                $this->add_responsive_control(
                    'work_content_section_padding',
                    [
                        'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                       
                        'selectors'  => [
                            '{{WRAPPER}} .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                           
                        ],
                        'separator' => 'before',
                    ]
                );

        $this->end_controls_section();

        
        $this->start_controls_section('bisy_item_box_inner_main_section',
                [
                'label' => esc_html__( 'Item box', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_padding',
                [
                    'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                      
                        '{{WRAPPER}} .feature-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                '_item_content_section_margin',
                [
                    'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                    'type'       => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors'  => [
                        '{{WRAPPER}} .feature-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );   

            
            $this->add_responsive_control(
                'item__box_border_radius',
                [
                    'label'     => esc_html__( 'Border Radius', 'bisy-essential' ),
                    'type'      => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .feature-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        
                    ],
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => '_item_section_background',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient', 'video' ],
                        'selector' => '{{WRAPPER}} .feature-item',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'item__box_shadow',
                        'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .feature-item',
                    ]
                );
               
        $this->end_controls_section();

        $this->start_controls_section('bisy_image_box_inner_main_section',
                [
                'label' => esc_html__( 'Image', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
                  
                   
                    $this->add_responsive_control(
                        'icon_box_section_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                    
                            'selectors'  => [
                                '{{WRAPPER}} .feature-item img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                               
                            ],
                            'separator' => 'before',
                        ]
                    );

                    $this->add_responsive_control(
                        'shape_left_line_pos_top',
                        [
                            'label' => esc_html__( 'Top Position', 'bisy-essential' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => -500,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            
                            'selectors' => [
                            
                                '{{WRAPPER}} .feature-item img' => 'top: {{SIZE}}{{UNIT}};',
                            ],
                           
                        ]
                    );
                    $this->add_responsive_control(
                        'shape_left_line_pos_left',
                        [
                            'label' => esc_html__( 'Left Position', 'bisy-essential' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => -500,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            
                            'selectors' => [
                            
                                '{{WRAPPER}} .feature-item img' => 'left: {{SIZE}}{{UNIT}};',
                            ],
                           
                        ]
                    );

        $this->end_controls_section();

        $this->start_controls_section('button_section',
        [
            'label' => esc_html__( 'Button', 'bisy-essential' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
       );
       
        $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'app_price_button_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                    'selector' => '{{WRAPPER}} .bisylms-btn-3',
                    
                ]
        );

        $this->add_control('box_button_text_color',
                [
                'label'     => esc_html__( 'Button text color', 'bisy-essential' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bisylms-btn-3' => 'color: {{VALUE}};',
                                
                    ],
                ]
            );
      
                $this->add_group_control(
                    Group_Control_Typography:: get_type(),
                    [
                        'name'   => 'box_button_text_typography',
                        'label'  => esc_html__( 'Typhography', 'bisy-essential' ),
                        'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                        'selector' => '{{WRAPPER}} .bisylms-btn-3',
                    ]
                );

                $this->add_control('box_button_text_hover_color',
                    [
                    'label'     => esc_html__( 'Button text hover', 'bisy-essential' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                            '{{WRAPPER}} .bisylms-btn-3:hover' => 'color: {{VALUE}};',
                        
                                            
                            ],
                    ]
                );
   
                
                $this->add_control('box_button_bg_color',
                [
                        'label'     => esc_html__( 'Button background', 'bisy-essential' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                        '{{WRAPPER}} .bisylms-btn-3' => 'background: {{VALUE}};',
                        
                        
                                    
                        ],
                    ]
                );

                $this->add_control(
                    'box_button_hv_bg_colors_heading',
                    [
                        'label' => esc_html__( 'Hover Background color', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                    [
                        'name'     => 'box_button_hv_bg_colors',
                        'label'    => esc_html__( 'Background', 'bisy-essential' ),
                        'types'    => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .bisylms-btn-3:hover',
                    ]
                );

                $this->add_control(
                    'box_button_border_hv_bg_colors_heading',
                    [
                        'label' => esc_html__( 'Hover border', 'bisy-essential' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'box_button_border_hv_bg_colors',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .bisylms-btn-3:hover',
                    ]
                );
     

                $this->add_responsive_control(
                    'label_border_radius',
                    [
                        'label'     => esc_html__( 'Button Border Radius', 'bisy-essential' ),
                        'type'      => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .bisylms-btn-3' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        
                        ],
                        'separator' => 'before',
                    ]
                );

                $this->add_group_control(
                    \Elementor\Group_Control_Border::get_type(),
                    [
                        'name' => 'pricing_btn_borders',
                        'label' => esc_html__( 'Border', 'bisy-essential' ),
                        'selector' => '{{WRAPPER}} .bisylms-btn-3',
                    ]
                );
                
                $this->add_responsive_control(
                        'pricing_boxs_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .bisylms-btn-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    
                    $this->add_responsive_control(
                        'pricing_boxs_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors'  => [
                                '{{WRAPPER}} .bisylms-btn-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                
        $this->end_controls_section();

    

        $this->start_controls_section('bisy_main_section',
                [
                'label' => esc_html__( 'Section', 'bisy-essential' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );
            
                    $this->add_group_control(
                    \Elementor\Group_Control_Background:: get_type(),
                        [
                            'name'     => 'main_section_background',
                            'label'    => esc_html__( 'Background', 'bisy-essential' ),
                            'types'    => [ 'classic', 'gradient', 'video' ],
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        
                    $this->add_responsive_control(
                    'section_box_margin',
                        [
                            'label'      => esc_html__( 'Margin', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                    'section_box_padding',
                        [
                            'label'      => esc_html__( 'Padding', 'bisy-essential' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px','%'],
                            'selectors'  => [
                                '{{WRAPPER}} .main-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                
                            ],
                        ]
                    );
                    $this->add_group_control(
                        \Elementor\Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'main_section_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'bisy-essential' ),
                            'selector' => '{{WRAPPER}} .main-section',
                        ]
                    );
        $this->end_controls_section();
    } //Register control end

    protected function render( ) { 

        $settings = $this->get_settings();
        $list     = $settings['list'];
    ?>
           <section class="feature-section main-section">
            <div class="container">
                <div class="row">
                    <?php foreach($list as $item): ?>
                        <div class="col-md-6">
                            <div class="feature-item">
                                 <?php if( $item['list_image']['url'] !='' ): ?>
                                <img src="<?php echo esc_url($item['list_image']['url']); ?>" alt="<?php echo esc_attr($item['list_title']); ?>">
                                 <?php endif; ?>
                                <h4 class="title"> <?php echo str_replace( ['\n'],['<br/>'],$item['list_title'] ); ?> </h4>
                                <?php if($item['list_content'] !=''): ?>
                                <p class="content"> <?php echo esc_html($item['list_content']); ?> </p>
                                <?php endif; ?>
                                <a href="<?php echo esc_url($item['list_button_link']); ?>" class="bisylms-btn-3"> <?php echo esc_html($item['list_button_text']); ?> </a>
                            </div> 
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php  

    }
    
    protected function _content_template() { }
}