<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {
  
    //
    // Create a Category filter widget
    //
    CSF::createWidget( 'bisy_essential_course_category_filter', array(
      'title'       => esc_html__('Bisy Course Category Filter','bisy-essential'),
      'classname'   => 'about-widget',
      'description' => esc_html__('Bisy Course Category','bisy-essential'),
      'fields'      => array(
  
        array(
          'id'      => 'title',
          'type'    => 'text',
          'title'   => esc_html__('Title','bisy-essential'),
        ),

        array(
          'id'      => 'limit',
          'type'    => 'text',
          'title'   => esc_html__('limit','bisy-essential'),
        ),
        array(
          'id'      => 'enable_price_filter',
          'type'    => 'switcher',
          'title'   => esc_html__('Enable Price Filter','bisy-essential'),
        ),

        array(
          'id'      => 'price_filter_title',
          'type'    => 'text',
          'title'   => esc_html__('Price Title','bisy-essential'),
          'default'   => esc_html__('Price Filter','bisy-essential'),
        ),
  
      )
    ) );
     
    if( ! function_exists( 'bisy_essential_course_category_filter' ) ) {
      function bisy_essential_course_category_filter( $args, $instance ) {
        $course_cat     = bisy_get_post_category('course_category',true);
        
        if(!is_array($course_cat)){
           return;
        }

        if(!$course_cat){
          return;
        }

        echo $args['before_widget'];
       
        if ( ! empty( $instance['title'] ) ) {
          echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        

        ?>
           
          
            <ul>
                <?php foreach($course_cat as $key => $item): ?>  
                  <li><a class="<?php echo esc_attr(get_queried_object_id() == $item->term_id?'active':''); ?>" href="<?php echo esc_url(get_category_link($item)); ?>"> <?php echo esc_html($item->name); ?> </a></li>
                 <?php if($instance['limit'] > 0 && ++$key == $instance['limit']): ?>
                   <?php break; ?>
                 <?php endif; ?>
                  <?php endforeach; ?>
            </ul>
            

        <?php
  
        echo $args['after_widget'];

        if(!$instance['enable_price_filter']){
           return;
        }  
        ?>
            <aside class="widget widget-filter">
                <h3 class="widget-title"> <?php echo esc_html($instance['price_filter_title']); ?> </h3>
                <form action="<?php echo esc_url($_SERVER['REQUEST_URI']) ?>" method="get" class="clearfix">
                  <div class="price-filter">
                      <ul>
                          <li>
                              <input type="radio" checked="checked" id="all" name="course-price-filter" value="all">
                              <label for="all">
                                  <?php echo esc_html__('All','bisy-essential'); ?>
                              </label>
                          </li>
                          <li>
                              <input type="radio" id="premium" name="course-price-filter" value="premium">
                              <label for="premium">
                                  <?php echo esc_html__(' Premium Courses','bisy-essential'); ?>
                              </label>
                          </li>
                          <li>
                              <input type="radio" id="free" name="course-price-filter" value="free">
                              <label for="free">
                                  <?php echo esc_html__('Free Courses','bisy-essential'); ?>
                              </label>
                          </li>
                      </ul>
                      <button type="submit"> <?php echo esc_html__('Filter Results','bisy-essential'); ?></button>
                  </div>
                </form>
            </aside>
        <?php
  
      }
    }
  
  }
  